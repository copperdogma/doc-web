This unsupported text member exists to prove explicit blocked routing on the bounded mixed-archive grouped-image slice.
