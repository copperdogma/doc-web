# Argon literal qualification fixtures v1

This folder contains an independently authored synthetic corpus for the proposed
Story 245 source-only table reader qualification. It has eight new pages: native
text N1–N3, image-only R1–R3, and held source-uncertainty cases A1–A2. The
material is synthetic and contains no real people, private records, copyrighted
source documents, provider answers, or downstream Ingester inputs.

The source table response golds use the maintained exact shape:

```json
{"source_table_count": 1, "tables": [{"bbox": [0, 0, 1, 1], "html": "<table>...</table>", "uncertain_cells": []}]}
```

Gold HTML encodes the characters visible in the source and structural ownership
using the maintained `table` / `tr` / `th` / `td` markup with positive spans.
HTML escaping is representation only: e.g. `&amp;` corresponds to a printed
ampersand. Empty cells and dash characters remain separate. N3 and R3 each have
two tables; every page is at or below 40 cell slots. A1 records the single
vertical-stroke cell as uncertain between `K8l4` and `K814`. A2 marks the
abraded Reading cell uncertain with no candidate alternatives. Neither hold gold
asserts hidden author intent as visible truth.

## Regeneration

Run from the repository root with the workspace Python that has ReportLab,
Pillow, pdf2image, Poppler and the project renderer dependencies:

```sh
python benchmarks/fixtures/argon-literal-qualification-v1/generate_fixture.py
```

Render all sources through the maintained 300-DPI composited-PNG module:

```sh
python modules/extract/extract_pdf_images_capped_v1/main.py \
  --pdf benchmarks/fixtures/argon-literal-qualification-v1/source/native.pdf \
  --outdir benchmarks/fixtures/argon-literal-qualification-v1/build/render-native \
  --dpi-cap 300 --baseline-dpi 300 --min-dpi 300 --sample-count 0 \
  --image-format png --start 1 --end 3
python modules/extract/extract_pdf_images_capped_v1/main.py \
  --pdf benchmarks/fixtures/argon-literal-qualification-v1/source/raster.pdf \
  --outdir benchmarks/fixtures/argon-literal-qualification-v1/build/render-raster \
  --dpi-cap 300 --baseline-dpi 300 --min-dpi 300 --sample-count 0 \
  --image-format png --start 1 --end 3
python modules/extract/extract_pdf_images_capped_v1/main.py \
  --pdf benchmarks/fixtures/argon-literal-qualification-v1/source/holds.pdf \
  --outdir benchmarks/fixtures/argon-literal-qualification-v1/build/render-holds \
  --dpi-cap 300 --baseline-dpi 300 --min-dpi 300 --sample-count 0 \
  --image-format png --start 1 --end 2
```

Copy the numbered outputs to `renders/{N1,N2,N3,R1,R2,R3,A1,A2}.png` in page
order. `manifest.json` records the exact source, gold, generator, renderer and
lossless page-render SHA-256 values plus the renderer settings and dependencies.
`corpus.json` is the compact eight-case index derived from that manifest; it
lists each case's source PDF/page, gold, render, density, table/cell/span counts,
uncertainty count and gold/render hashes. To rebuild the manifest after
rendering, run `python seal_manifest.py`, then regenerate `corpus.json` from the
manifest's `pages` records using the same field mapping shown in its cases.

The source geometry is US Letter at a fixed 300-DPI final render (2550 × 3300
pixels). Native pages retain searchable text as supporting provenance. Raster
and hold PDFs contain only a page image; the source-only reader receives the
composited PNG. No crop, OCR, or native text enters the gold.
