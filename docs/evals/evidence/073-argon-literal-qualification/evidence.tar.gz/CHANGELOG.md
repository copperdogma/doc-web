## [2026-10-13-02] — Opt-in native literal reader qualification (Story 253)

### Added
- Explicit Google Argon source-only reader and hash-bound native receipt reuse
  through the real CLI/driver, with provider-aware bundle verification.
- Locked per-POST budget reservations, raw native bytes before parse, exact
  identity and standard Astra service tier for the bounded qualification.
- Independent frozen source panel and sealed progressive Attempt073 evidence.
  N1 preserves ten clear cells for both readers; Argon misses the mandatory
  ambiguity hold on A1. Stop after five POSTs; no promotion or default change.
- Four offline three-page exports and four holds verify integration separately
  from provider quality. Live complete-batch exports and repeats are unmeasured.

## [2026-10-13-01] — Five decision-model evaluations (Attempt 070)

### Added
- Compare five typed consistency classifiers with fresh GPT-4.1 and actual
  confidence-gated fallbacks. Solar shows a bounded batch quality/cost signal
  with latency and uncertainty holds; no automatic promotion is qualified.
- Record the independent crop-safety stop: Clef and fresh GPT-5.5 both accepted
  a source-confirmed clipped seal. ScaleDown two-image transport is blocked;
  Liquid direct access is absent. Preserve unmeasured coverage and defaults.
- Retain exact execution snapshots, a lossless public/synthetic receipt archive,
  closed separate spend ledgers, source review and focused offline validation.

## [2026-10-08-02] — Continuing strategic reviewers and fresh milestones

### Changed
- Reuse a separate continuing reviewer for repeated strategic checkpoints and
  request a fresh independent assessment at consequential milestones. Preserve
  model selection, cadence, read-only scope, messaging authority and budgets;
  keep cache and cost savings as unmeasured hypotheses.

## [2026-10-08-01] — Source-faithful offline manual continuation (Story 251)

### Added
- Opt-in native PDF catalog illustration recovery with explicit source geometry,
  protected crop preservation, held decisions and pixel/provenance receipts.
- Append-only offline continuation helper and recipe overlay that preserve the
  original run, stage graph and paid extraction/planning artifacts.

### Fixed
- Place source illustrations beside table descriptions without removing literal
  transcription; preserve hard line breaks when discovering source URLs.
- Resolve and validate numeric TOC links using their complete source row, printed
  page evidence and block provenance, retaining ambiguity and wrong-target guards.
- Qualify fresh driver artifacts with source-pixel/sampling and text preservation
  checks, 24 passing conformance checks, and 711 affected offline tests.

## [2026-10-07-02] — Related-document reference resolution (Story 250)

### Added
- Opt-in offline `doc-web resolve-set` CLI/Python capability for explicit sets
  of already-converted bundles, with exact source-backed heading links,
  inspectable ambiguity/edition holds and portable derivative receipts.
- Driver recipe/adapter, safe repeat/resume publication, source preservation
  and static resource checks, installed-package proof and independent consumer
  acceptance. Bare exact identifiers are eligible within declared related sets.

### Changed
- Shared reference helpers now ship in the `doc_web` package; existing local
  resolver policy is preserved. Add tinycss2 for static CSS dependency checks.

## [2026-10-07-01] — Haiku 5.5 task value evaluation (Story 249)

### Added
- Evaluated Haiku 5.5 across detector, independent crop safety, public handwriting and synthetic consistency with three thinking configurations. Retained current models; Attempt068 records exact failures, fresh comparisons, cost and source provenance.

## [2026-10-06-06] — Experimental disagreement warning (Story 248)

### Added
- Preserve low-confidence candidate/planner disagreement as an advisory review
  warning in the default-off Perplexity sidecar, leaving authority unchanged.
- Saved-response and real-driver offline proof; no new inference or activation.

## [2026-10-06-05] — Offline disagreement review policy (Story 247)

### Added
- Replay saved synthetic native answers with a pure disagreement-to-review rule.
- Preserve one observed warning as review: false-clean1→0, reviews0→1;
  exact classification remains2/3. Zero new inference/spend; defaults unchanged.

## [2026-10-06-04] — Perplexity runtime shadow safety screen (Story 246)

### Added
- Isolated default-off synthetic shadow evaluation with observed source evidence,
  real-driver coverage/invariance checks and bounded native spend receipts.
- Stop/no-promotion result: correct low-confidence Decider warning falls back to
  inherited planner false-clean; five calls USD0.02588316, no unresolved spend.
- Preserve unmeasured coverage and source-reviewed failures; runtime defaults unchanged.

## [2026-10-06-03] — Literal table evidence and uncertainty gate (Story 245)

### Added
- Add an opt-in bounded PDF recipe with lossless source rendering, literal OCR,
  independent source-only table review, typed evidence and a final export gate.
- Preserve initial OCR and report source-located disagreements or ambiguity;
  qualify only exact complete table agreement with no reported uncertainty.
- Include portable report/qualification hashes and separate original physical
  page identity in bundle provenance.

### Fixed
- Preserve safe table spans and literal entities during OCR sanitization.
- Compare captions and rendered text boundaries without glyph normalization;
  block malformed, hidden, stale or mismatched qualification evidence.
- Prevent reviewed output path collisions and preserve early crop prerequisites.
- Read explicit current/total printed folios without treating bare fractions as
  page numbers.

### Verified
- Frozen fresh native/image-only confirmations preserve all 36 accepted cells;
  an identical-glyph case flags both ambiguous cells and holds before export.
- Original equipment diagnostic preserves `r2l3` across 57 exact cells and stays
  explicitly unqualified where the independent reader reports uncertainty.
- Current applicable checks:1,644 passed, one skipped; full-suite dependency and
  pre-existing test-isolation limits remain recorded in the validation note.
- Four independent semantic rubrics and current driver rebuilds pass. Attempt
  062 retains rejected full-transcription adoption; no universal OCR, whole-book
  fidelity or default-model promotion is claimed.

## [2026-10-06-02] — Runtime agent staffing and event waits

### Changed
- Reserve the strongest eligible runtime model and maximum supported thinking
  for strategic loop review; size ordinary workers to risk and coordination
  cost, and collect delegated results with completion events.
- Preserve local authority, approval gates, verifier stops and frozen eval
  configuration. Record Alignment055 adoption and proportional validation in
  `docs/agent-staffing-and-event-waits.md`.

## [2026-10-06-01] — Mistral Large4 maintained evaluation (Story244)

### Added
- Record fresh public detector, repaired safety and handwriting comparison under
  USD11; forty paid responses settle at USD0.27457617, with exact custody and
  reconstruction limits. Keep current defaults: candidate clips logo artwork,
  false-safes an incomplete seal and loses literal handwriting fidelity.
- Preserve independent source review, strict contracts, matched driver inputs,
  original/fixed safety labels, and tested cross-process dispatch accounting.

## [2026-10-05-02] — Reconcile local evaluation notes and dependency lock

### Fixed
- Preserve historical metadata-only follow-through notes outside Story207 YAML front matter and disambiguate their report from Ox Alpha Attempt028.

### Added
- Track the pre-existing dependency resolution with the configured seven-day cutoff; all72 package versions remain unchanged and the reconciled lock passes the current uv offline check.

## [2026-10-05-01] — Optional source-grounded reference links (Story 243)

### Added
- Add default-off `--resolve-references` for final chapter, Marker and native Office bundles, covering explicit printed pages, labelled sections/paragraphs/figures/tables/footnotes, HTTP(S) URLs, contents and indices.
- Emit typed resolution reports with source wording, location, target evidence and explicit missing/ambiguous decisions; preserve printed labels separately from scan identity.

### Fixed
- Validate existing and serialized links before manifest sealing; rebind source IDs with exact occurrence authority, preserving text, inline markup and provenance.
- Preserve logical reading order when printed page numbers repeat or reset.
- Restore complete source-authored prefixed section identities with both flag settings; keep “noted” as prose, abstain on foreign or unestablished document scope, and share explicit cues across coordinated labels.
- Require source heading/index authority and retain dotted/duplicate abstention; avoid repeated scope parsing and whole-block rescans.

### Verified
- Consumer repair continuation:604 affected tests, fresh driver/static inspection, independent27 control passages/34 assertions, original34 existing links restored both flags and12 valid staged packages. Fresh30/34 references resolve; four compact dice mappings stay unsupported. Zero provider calls; Attempt060 retains failed candidate history and bounded acceptance.
- Fresh driver on/off builds and rendered inspection, 386 focused tests, independent synthetic12/12 and Freeway491/491 admitted reference checks; zero wrong targets within scored controls and zero provider calls. Historical OCR/coverage limits remain explicit.
- Final matched-semantics cache comparison measures14.03%synthetic/11.52%Deathtrap resolver gains with exact output parity; no whole-pipeline speed claim. Attempt059 records bounds and the diminishing-returns stop.

## [2026-10-04-02] — Preserve planner-owned figures and source page identity

### Fixed
- Export critical planner rectangles as lossless source crops without destructive trim, masks, implicit safety margins or rescue calls; reject out-of-source pixel bounds.
- Accept fully reviewed empty essential-graphics plans only with exhaustive page coverage and no unresolved/essential/useful targets.
- Keep catalog codes and body dice ranges out of printed folios and physical-spread metadata; require independent corroboration before inferring printed numbers.

### Verified
- Linked Ingester Story036 native refinements preserve eight complete rules figures,20 events pages and607 text blocks; independent source inspection and241 affected tests pass. Repairs make no new provider calls, and the portable consumer passes12/12 isolated-copy checks. Attempt058 records exact evidence identities. Story226's broader qualification remains In Progress; no detector, model or cost/speed promotion.

## [2026-10-04-01] — Research before reinvention

### Changed
- Add bounded problem-class research and periodic strategy checkpoints to agent
  workflows, preserving owner reuse boundaries, verification stops, and budgets.

## [2026-10-03-03] - Set experiment and loop-review decision rules

### Changed
- Add end-to-end impact estimates to eval triage, predeclared experiment and uncertainty rules to eval improvement, and follow-through/opportunity-cost checks to loop reviews.

## [2026-10-03-02] - Preserve visible source color in crop metadata (Story226 continuation)

### Fixed
- Classify visible source channel differences conservatively, preventing balanced/sparse color and paper tint from being marked grayscale or receiving a grayscale transparency derivative.
- Repair a stale custody test's preview coordinate basis while preserving its native rectangle assertion and runtime geometry guards.

### Changed
- Cached32-page proof preserves all95 PNG bytes, RGBA arrays, ICC profiles and crop bounds;92 incorrect color flags change.111 affected controls and independent source comparison pass with zero provider calls. Existing p005 crop-quality hold remains; Story226 stays In Progress.

## [2026-10-03-01] - Preserve critical artwork and speed lossless native crops (Story226 continuation)

### Fixed
- Veto prose-band trimming across connected foreground and require a detached background separator, preserving artwork already inside planner rectangles.

### Changed
- Reuse one immutable selected-page BGR decode within a crop invocation and encode PNGs at lossless compression level3.

### Verified
- Actual cached32-page driver replays retain95 native figures, restoring17 previously shortened rectangles without losing old visible pixels. Independent3+3comparisons show11.915% local crop-time reduction for page-local decode reuse, then20.608% for lossless PNG encoding in its separate window; gains are not additive or whole-game claims.
- All95 decoded RGBA/ICC/geometry/manifest rows remain exact during the PNG comparison; storage grows8.725%, within the frozen25% cap.79 affected controls and independent56 crop controls pass. Story226 remains In Progress; p005 planner excess-background/full-manual qualification holds remain.
- Public attempts054–056 preserve private execution proofs after remote main allocated global053. No provider calls or cheaper-model adoption.

## [2026-10-01-01] — Consolidate agent instructions and explain decision models

### Added
- Add a portable decision-model guide and compact AGENTS.md entry point for
  choosing between code, bounded semantic judgments and language generation,
  preserving owner evaluation verdicts, privacy and enablement gates.

### Changed
- Remove the root CLAUDE.md bridge after verified native AGENTS.md loading;
  preserve Claude skill-discovery links and any scoped AGENTS instructions.

## [2026-09-30-09] - Bind critical crops to selected source coordinates

### Fixed
- Validate planner source/basis dimensions and scale critical pixel bounds into selected high-resolution images with explicit source/transform provenance; reject downsampling.
- Project semantic coverage into that verified source basis, rejecting inconsistent metadata without raw-coordinate fallback or threshold changes.

### Verified
- Full public zero-API V10 retains101source-exact crops/91HTMLfigures;22native/12package checks pass and ruletext/citations remain exact.75native/41consumer/25producer controls pass. Published32sampled source images and101crop bytes are bound; original/old/protected evidence remains unchanged. Rendered PDF sampling only; Story226 stays In Progress for broader semantic and embedded-byte qualification.

## [2026-09-30-08] - Preserve decoded source-page pixels (Story226 continuation)

### Fixed
- Save decoded RGB native/rendered PDF pages and retained normalized images as lossless PNG instead of JPEG95; use TIFF for decoded CMYK pages to preserve all four channels and record output encoding.

### Verified
- Four RGB regressions fail on base; the final candidate passes all eight RGB/CMYK, fast/fallback, normalized/unscaled encoding cases and30 affected tests in9.07s. Real native and public Ingester FINAL runs produce identical16spreads/32logicalpages with unchanged dimensions/mapping and0model calls. Sampled page5 preserves19,665,625RGB pixels exactly against an independent render; a separate128×96 CMYK native driver preserves all12,288 pixels across four channels. Existing published output and maximum embedded-pixel qualification remain explicit limitations.

## [2026-09-30-07] - Preserve planned zero-figure decisions in semantic HTML (Story 226)

### Fixed
- Preserve explicit empty/decorative critical-graphics decisions through crop fallback so unplanned OCR crops do not appear on pages where the planner selected no figures.
- Run existing unresolved-image cleanup on no-crop pages, while preserving plain HTML without image placeholders, already resolved images, semantic captions, and reminder callouts.

### Verified
- Public zero-API V8 refinement passes22/22 native conformance checks with101 planner-target crops, no fallback crops on pages25/31, no unresolved image placeholders, and exact text/citation equivalence. The bundle remains `needs_review`; no human approval or maintained detector score changed.
- Root-owned package revision008 passes12/12 contract checks with840 included files,841 resources and zero new calls; review holds and83 open issues remain.
- V6's 21/22 semantic failure and V7's pre-publication runtime-hash stop remain recorded. Story226 stays In Progress pending broader visual and maximum-pixel qualification.

## [2026-09-30-06] - Preserve planned critical rule figures (Story 226)

### Fixed
- Preserve complete visual-planner targets through dense, card-panel, rule-panel, gap-count and layout-band subdivision; untargeted fallback segmentation remains available.
- Retain small critical targets in mixed count-limited batches instead of letting fallback fragments replace them.

### Verified
- Zero-API native partial driver preserves 101 distinct planned figures and the connected page 10 board;22 structural checks pass. Six page 25 fallback crops remain, with title loss on the final two explicitly unqualified.
- Recorded independent native source replay and 377 current-main focused checks, with explicit restored ignored-fixture context, without changing maintained detector scores or model defaults.

## [2026-09-30-05] - Complete actual Cam-reviewed public pilot publication

### Added
- Cam's explicit confirmation of both exact pilot crops and complete3-page inventory, with bound non-synthetic trusted-local authority. Historical drafts and preapproval evidence preserved.
- Offline-only4-stage release/build driver publishes both byte-exact crops once and retains page3; no additional native calls/default changes. Initial path/loader preflight failure preserved, corrected fresh driver and rendered artifact inspection pass. Scoped landing authorized.

## [2026-09-30-04] - Exercise approved two-case Sol native pilot (Attempt049)

### Added
- Exactly2 public synthetic live receipts through the opt-in medium safety adapter: both pass with source-compatible reasons, conservativeUS$0.013025/unknown0 under US$0.50/max2. No retries, fallback or default changes.
- Fresh frozen custody, pending all-page review HTML and unfilled real-operator templates. Every proposal remains held for actual operator source assertions; exposed smoke is not representative quality/promotion proof. Historical offline validation stays immutable.

## [2026-09-30-03] - Wire opt-in Sol crop proposals behind source review (Story242)

### Added
- Pinned native Sol medium/4096/high strict safety proposer with offline replay default, raw receipts, explicit capped single-send live mode and retained unknown reservations. All candidate passes/fails still require explicit local operator review; native failures cannot publish.
- Safe actual-source custody preparation, complete-page pending display and operator-owned initialization/finalization templates. Guided crop provenance now records the actual native source/geometry without changing crop pixels or defaults.
- Public synthetic proposal→review→release→HTML driver proof and342 focused regressions, including operational failures and custody aliases. Zero provider calls; no automatic promotion. Operator runbook proposes a separately authorized two-request US$0.50 public smoke pilot.

## [2026-09-30-02] - Add offline opt-in crop review gate (Story241)

### Added
- Explicit trusted-local review of every crop proposal, complete source inventory, source/crop display, append-only review decisions and deterministic reviewed release. Synthetic replay fixtures cover saved S3 pass and a labelled S4 false fail; no Cam approvals are invented.
- Opted-in chapter publication verifies original evidence twice and stages exact approved visuals; missing/stale/conflicting/unresolved decisions, incomplete inventory, unsafe paths and output aliases hold publication while preserving source/crops. Defaults and model routes stay unchanged.
- Focused custody/bypass/recrop/real-driver regressions, operator runbook and source-safe validation evidence. Zero API spend; live model promotion remains deferred.

## [2026-09-30-01] - Measure repaired page-safety contract (Story240)

### Added
- Source-backed6/6 screens for Luna medium, Sol6.1 medium and maintained GPT5.5, with exact receipts and all six fresh diagram pairs frozen before inference.
- Campaign-specific pre-call126000 golden correction; historical golden and047 evidence preserved.

### Fixed
- Eval guard closes on quota/duplicate sends; restored-credit continuation disables scheduler retries. Source-confirmed seal-label repair transparently rejudges saved outputs: Sol22/22 plus freshphysical5/5, uncertaintypolicy miss remains; Luna/GPTfalse-rejectstops.71 aggregate attempts and all unknown reserves retained; no runtime/default changed.

## [2026-09-29-01] - Evaluate GPT-6.1 Sol on maintained Doc Web gates (Story 239)

### Added
- Recorded exact direct Responses access and a fresh 13-page detector win over
  Gemini 3 Flash, with source-checked seal and signature localization.
- Preserved the source-confirmed page-context false-safe, two actual-driver LOC
  handwriting misses, all 36 complete paid receipts, and a verified offline
  reproducibility archive. Safety and OCR defaults remain unchanged.

### Changed
- Added eval-only GPT-6.1 OCR Responses compatibility and bounded transport
  reservation guards. No runtime default changed.

## [2026-09-29-02] - Compare safety thinking levels (Story 240)

### Added
- Frozen medium/prior-setting page-safety evidence: both medium candidates and fresh GPT5.5 false-safe the neighboring portrait. Full22 remains unmeasured; no reliable fresh safety winner, runtime unchanged.
- Exact seven receipts, closed $0.0694776 ledger, lossless reconstruction and prompt-contract concern for source-backed review before another paid run.

### Changed
- Prepared generic page-safety boundary/neighbor and uncertainty instructions for review, preserving legitimate compound visuals. Offline rendering checks only; revised prompt behavior is unmeasured and Story240 remains In Progress.

## [2026-09-28-01] - Evaluate Sonnet 5.5 detector and handwriting (Story 238)

### Added
- Recorded exact native Sonnet 5.5 access, the Image011 detector contract stop,
  and an independent source-reviewed LOC OCR comparison against fresh Gemini 3.7.
  Neither OCR arm clears 0.99; runtime roles, C5 residue and blocked Story 191 remain.
- Preserved complete metered receipts, explicit quarantined custody-fault accounting,
  frozen execution snapshots and a reproducibility archive with 36 focused checks.

### Changed
- Added narrow Sonnet OCR transport compatibility and eval-only SDK retry control.
  No runtime default changed.

## [2026-09-27-01] - Repeat GPT-6 image gates (Story 237)

### Added
- Fresh GPT-6 image rerun evidence (Attempt 044): Sol leads the 13-case detector
  comparison; Sol/Luna safety and publication gates remain failed. All calls
  cost an estimated $0.42295715, and the current runtime remains unchanged.
- Scoped reservation guards and exact-envelope detector replay allow bounded
  caption recovery while preserving failed responses and their billed usage.

## [2026-09-26-03] - Qualify GPT-6 Luna crop runtime seam (Story 236)

### Added
- Recorded paired same-input four-page owner driver artifacts and 42 complete
  provider responses. Luna retained the bounded detector benchmark lead but its
  page-12 raw crop clipped the seal/signatures and included printed labels, so
  Gemini remains the runtime detector. The fresh Gemini control also retained
  some officer labels; C5 remains open. Attempt 043 cost an estimated
  $0.181080085, bringing the combined campaign to $0.382724960/$3.00.

### Changed
- Added optional strict GPT-6 detector reasoning and split Gemini caption
  routing, with fail-closed Gemini finish/identity checks and raw-response
  retention. Maintained recipes and defaults remain unchanged.

## [2026-09-26-02] - Compare GPT-6 Sol and Luna crop gates (Story 235)

### Added
- Recorded exact direct Responses qualification, fresh 13-page detector
  comparison with Gemini 3 Flash, and independent page-context safety screens.
  Luna led bounded detector quality and cost, but both candidates made a
  source-confirmed false-safe page judgment; runtime defaults and C5 residue
  remain unchanged. All calls cost an estimated $0.201645 under the $3 cap.

### Changed
- The OpenAI Responses eval adapter preserves complete raw envelopes and prices
  cache-write tokens separately. The crop coverage summary now identifies
  Luna's bounded detector score as production-unqualified.

## [2026-09-26-01] - Measure Opus 5.5 crop and page-context gates

### Added
- Recorded direct Anthropic Opus 5.5 medium native/adapter qualification and the
  public-fixture detector and independent page-context safety results. The
  detector missed its full 13-case contract and quality target; page context
  made a source-confirmed false-safe judgment. Total all-call cost was
  $0.352940 under the $2 cap. Runtime defaults and C5 residue remain unchanged.

## [2026-09-22-01] - Record MiMo V2.6 crop transport stop

### Added
- Preserve both candidate checkpoint attempts, reasoning-control mismatch, six shared-pool capacity failures, seven protected envelopes, and the runner retry defect. No crop score or incumbent comparison was obtained.

## [2026-09-21-02] - Add opt-in JEV consistency shadow routing (Story 234)

### Added
- Preserve unclassified event notes and source-context uncertainty in planner
  inputs/outputs; surface exact convention contradictions and retain review
  uncertainty through dependent shadow routing without automatic variant repair.
- Observed six anonymized structural variants with the full planner and native
  JEV shadow; preserved outputs and identified contradictory conventions plus a
  compaction blind spot. Seven calls cost$0.03386839; keep shadow opt-in.
- Default-off, bounded JEV shadow beside the document planner, with explicit
  uncertainty, deterministic layout veto, existing-planner fallback and atomic
  privacy-minimized diagnostics. Authoritative outputs remain unchanged.
- Owner runtime-key documentation and26affected tests; real synthetic driver
  verification in disabled/enabled/provider-failure modes with zero provider calls.

## [2026-09-21-01] - Compare JEV document consistency routing (Story 233)

### Added
- Independently reviewed synthetic five-class comparison, exact native evidence,
  cost ledger, real JEV/GPT-4.1 fallback and separate deterministic baselines.
- Relative result: cascade33/40 versus GPT29/40,54.64% cheaper on the narrow task;
  conditional shadow candidate with layout guards. Runtime defaults unchanged.

## [2026-09-19-01] - Defer Qwen3.8-Omni-Flash crop evaluation

### Changed
- Recorded the approved detector evaluation's zero-spend direct Alibaba access
  stop and Cam's explicit deferral. Capability remains unmeasured; future work
  requires explicit reopening after eligible access exists, with no automatic
  retry or runtime-default change.

## [2026-09-13-03] - Unify close-out and landing guidance

### Changed
- Replaced the repository-specific close-out wrapper with the shared
  `/finish-and-push` skill and a concise Doc Web validation runbook.
- Retired `/check-in-diff` and routed active close-out callers through the
  unified skill while preserving historical story and changelog records.
- Made proportional validation authoritative for close-out handoffs, including
  input-based evidence reuse and focused checks for isolated tooling changes.

## [2026-09-13-02] - Record inconclusive Qwen3.8 Flash crop retry

### Added
- Added bounded OpenRouter Qwen3.8 Flash qualification and crop-evaluation
  support with exact provider attribution, strict schema checks, spend guards,
  protected raw evidence, and focused regression coverage.

### Changed
- Recorded that Alibaba access now works, while normalized-coordinate contract
  failures and shared-pool capacity on the corrected integer arm leave full
  detector capability incomplete; crop defaults and safety gates remain
  unchanged.

### Fixed
- Kept nested JSON campaign results ignored so raw request/response evidence
  cannot enter a normal staging set accidentally.

## [2026-09-13-01] - Reject DeepSeek V4.1 Flash crop detector

### Changed
- Recorded recovered strict vision access followed by the source-verified
  Image011 localization failure (0.5551). Kept crop defaults and stopped before
  the full detector suite; reported $0.002773768 generation spend separately
  from the initial capacity error's unresolved charge exposure.
- Added bounded, closed-run-safe evaluation helpers and durable evidence manifests.

## [2026-09-06-01] - Screen exact Qwen3.8 Max 0902 crop detector

### Changed
- Qualified exact Alibaba/OpenRouter strict vision access, then stopped on the
  unchanged seal/signatures grouping failure. Recorded $0.013964 total spend
  and explicit unmeasured full-suite/safety limits; retained all model defaults.

## [2026-09-05-02] - Reject GPT-6 Astra page-context promotion

### Added
- Added a frozen one-case page-context task for the authoritative
  `page-122-001` neighboring-portrait differentiator.

### Changed
- Stopped Astra medium after it falsely passed the neighboring-portrait crop;
  kept GPT-5.5 Responses as the recorded `22/22` page-context provider and left
  all crop runtime defaults unchanged.

## [2026-09-05-01] - Measure GPT-6 Astra crop reasoning frontier

### Changed
- Qualified exact first-party GPT-6 Astra strict image transport and recorded
  fresh low-through-max reasoning calibration. Low and medium both passed the
  complete `13/13` maintained detector, with medium setting a new bounded
  quality high of `0.980392`; production adoption remains deferred because the
  conditional page-context safety gate could not fit within the approved cap.

## [2026-09-04-01] - Defer GPT-6 Astra crop challenger until account access

### Changed
- Recorded an owner-wrapped authenticated `gpt-6-astra` access stop before
  inference: exact model retrieval returned `404 model_not_found`, so crop
  capability remains unmeasured, spend stayed at `$0.00`, and all maintained
  prompts, goldens, providers, and runtime defaults remain unchanged.

## [2026-09-01-01] - Reject Claude Fable 5.1 crop challenger

### Changed
- Recorded exact first-party Fable 5.1 transport qualification and its failed
  maintained detector gate: one quarantined bbox contract error, aggregate
  `0.870015`, and `$0.731890` detector spend, with the page-context gate and
  maintained crop defaults left unchanged.

## [2026-08-26-01] - Reject Ox Alpha drift rerun

### Changed
- Recorded the force-fresh Ox Alpha crop rerun at 12/13 and 0.880846, below its
  August 22 result, while retaining the strict-route block and unchanged
  downstream promotion gates.

## [2026-08-25-01] - Reject Terra runtime promotion

### Added
- Added an exact production-recipe Terra parity fixture and contract test.

### Changed
- Kept Gemini 3 Flash as the Onward detector after Terra retained printed
  captions below both page-122 portraits despite leading the bounded detector
  benchmark and recovering the extra page-12 signature.
- Replaced the obsolete held-out prerequisite in the crop runbook with the
  authoritative hand-authored-golden selection policy.

## [2026-08-22-01] - Reject Ox Alpha crop challenger

### Added
- Added a bounded Ox Alpha crop evaluation with exact-model attribution,
  retained diagnostic evidence, and regression coverage for safe response
  retention and wrapper-only JSON cleanup.

### Changed
- Recorded Ox Alpha's `13/13`, `0.9151` diagnostic detector result, below the
  `0.95` gate and `0.9703` incumbent, while keeping the maintained crop
  defaults unchanged.

## [2026-08-14-01] - Restore authoritative crop golden selection

### Changed
- Restored the hand-authored crop goldens as the authoritative bounded model-selection surface and removed the unnecessary 12-case held-out prerequisite, while preserving strict provenance validation and the full-pass runtime-promotion gate.

## [2026-08-13-01] - Audit Gemini 3.7 crop evaluation validity

### Added
- Added a tracked Gemini 3.7 Flash evaluation, strict detector/provider configurations, an eval-only handwriting recipe, and source-backed provenance for the maintained crop regression surfaces.
- Added a fail-closed frozen-result regrader and adversarial coverage for duplicate rows, partition drift, calibration/held-out overlap, and ineligible selection claims.

### Changed
- Reclassified the exposed crop corpora as calibration and production-safety regression evidence, blocking model-winner claims until a balanced source-page-independent held-out slice is frozen before provider calls.
- Recorded Gemini 3.7's `13/13` integer detector result, valid `39/40` crop-safety veto, unmeasured page-context capability, and below-bar handwriting results without changing runtime defaults.

## [2026-08-12-01] - Reject Grok 4.6 crop challenger

### Added
- Added a tracked Grok 4.6 evaluation attempt covering authenticated OpenRouter/xAI transport, the frozen 13-case detector, visual source review, spend, and the progressive-gate decision.

### Changed
- Hardened the generic OpenRouter vision adapter to enforce per-request ZDR and deny provider data collection while retaining strict schemas, exact model/provider attribution, disabled fallbacks, terminal-state checks, and reported usage/cost.
- Recorded Grok 4.6's below-target `11/13`, `0.8414` detector result and preserved its unmeasured 22-case page-context capability; maintained crop defaults, prompts, scorers, and goldens remain unchanged.

## [2026-08-05-01] - Reject Qwen3.8 Max crop challenger

### Added
- Added a fail-closed OpenRouter vision adapter that pins Qwen3.8 Max to Alibaba, preserves multimodal input, enforces strict task schemas, and verifies served identity, terminal completion, usage, and reported cost.
- Added a tracked Qwen3.8 Max evaluation attempt covering transport qualification, the frozen 13-case detector, manual source inspection, spend, and the progressive-gate decision.

### Changed
- Changed the eval registry and owning crop story logs to record Qwen3.8 Max's below-target `12/13`, `0.9411` detector result and preserve the unmeasured 22-case page-context capability.
- Kept `gemini-3-flash-preview` as the maintained Onward crop detector and GPT-5.5 as the maintained page-context validator; no runtime default, prompt, scorer, or golden changed.

## [2026-08-03-01] - Qualify Luna crop value without weakening production fidelity (Story 231)

### Added
- Added a strict, attributable OpenAI Responses crop-vision route for GPT-5.6 Luna, production-parity Gemini/Luna comparison recipes, and regression coverage that keeps challenger parameters aligned with the maintained runtime.
- Added a tracked Luna price-refresh evaluation showing a `13/13`, `0.9650` detector result with materially lower cost and latency than the fresh Gemini control.

### Changed
- Reused and adapted the CineForge `evaluate-model` workflow for doc-web's decision surfaces, progressive gates, provider contracts, and evidence ownership.
- Kept `gemini-3-flash-preview` as the maintained Onward crop detector and GPT-5.5 as the independent page-context validator after source inspection found Luna included printed captions in two page-122 crops despite better count, cost, and latency.

### Fixed
- Hardened the OpenAI eval adapter and production crop route to reject incomplete, wrong-model, usage-invalid, malformed, or non-positive-area responses before scoring or artifact emission.

## [2026-07-25-01] - Reject Claude Opus 5 crop challenger

### Added
- Added focused fail-closed coverage for Anthropic strict schemas, exact served-model attribution, terminal completion, usage evidence, and lossless multimodal normalization.
- Added a tracked Claude Opus 5 evaluation attempt covering transport qualification, the frozen 13-case detector, manual failure classification, and the progressive-gate decision.

### Changed
- Changed the direct Anthropic benchmark adapter to support provider-native task schemas while locally enforcing unsupported crop-coordinate constraints.
- Changed the eval registry and owning crop story logs to record Opus 5's below-target `0.8922` detector result and preserve the unmeasured 22-case page-context capability, maintained providers, and runtime defaults.

## [2026-07-22-04] - Requalify Kimi K3 evaluation transport

### Added
- Added a force-fresh `/evaluate-model` attempt recording the predeclared K3 comparison, current first-party contract, zero-spend credential blocker, and exact unblock condition.
- Added focused coverage for served-model attribution, terminal-state enforcement, strict detector/page-context schemas, malformed output, and lossless multimodal prompt normalization.

### Changed
- Changed the direct Moonshot benchmark adapter to fail closed unless K3 returns the exact requested model, a normal terminal choice, valid usage evidence, and locally validated strict JSON.
- Changed the eval registry and owning crop story logs to record direct Moonshot authentication failure followed by successful exact-model OpenRouter qualification and fresh scored comparisons: K3 beat Gemini 3 Flash on detector mean quality but failed the hard page-context gate `21/22` versus GPT-5.5's `22/22`, so maintained crop defaults remain unchanged.
- Changed the repo environment wrapper and Kimi adapter to support a repo-scoped exact OpenRouter route with normalized reasoning, required strict parameters, disabled fallbacks, and attributable provider/model evidence.

## [2026-07-22-03] - Preserve table-rescue usage instrumentation

### Added
- Added focused regression coverage for recursively converting SDK usage objects and nested values into JSON-native report data.

### Fixed
- Fixed `table_rescue_html_loop_v1` report generation so Pydantic-style OpenAI usage objects no longer fail JSONL serialization after a successful rescue call.

## [2026-07-22-02] - Record blocked Kimi K3 launch-day evaluation

### Added
- Added focused tests for the Moonshot PromptFoo provider's K2.6/K3 request and pricing contracts.
- Added a tracked Kimi K3 launch-day attempt covering authenticated model visibility and blocked inference smokes.

### Changed
- Changed the bounded Moonshot provider to support K3's always-reasoning API contract, model-specific pricing, and bounded retry behavior while preserving K2.6 compatibility.
- Changed the eval registry to record K3 as not yet adoptable because launch-day Moonshot overload prevented a quality measurement.

## [2026-07-22-01] - Re-run Grok 4.5 through `/evaluate-model`

### Added
- Added a self-contained `/evaluate-model` skill that resolves natural-language briefs, verifies current provider contracts and live access, repairs invalid eval transport before scoring, runs bounded fair comparisons, inspects failures, and records scoped adoption evidence.
- Added a portable bounded skill-pilot summary covering first-party research, live exact-model/native/contract/parity probes, a fresh incumbent comparison, visual failure classification, and the bounded high-reasoning retry, with a byte-exact scored-adapter snapshot, hashes, and safe regeneration commands for ignored raw evidence.

### Changed
- Changed `/evaluate-model` to recognize natural force-fresh/reproducibility intent without weakening safety or fairness gates, distinguish audit-only work, apply a default `$5` all-provider spend ceiling, qualify materially different task contracts independently, and classify a skipped later surface as not measured.
- Changed the direct xAI Responses benchmark adapter to select and validate strict detector or page-context schemas, require the expected served-model identity, retain requested and served metadata, and reject lossy prompt normalization, incomplete, provider-error, wrong-model, schema-invalid, or malformed-envelope/usage HTTP 200 responses before subject scoring while preserving valid cost evidence.
- Changed the eval registry and owning crop story logs to preserve the fresh detector `11/13`, `0.7667` no-adoption result while classifying the skipped page-context capability as not measured and keeping all maintained crop defaults unchanged.

## [2026-07-21-01] - Reject Gemini 3.6 Flash and Gemini 3.5 Flash-Lite challengers

### Added
- Added a portable bounded eval attempt covering exact-ID access, maintained crop detection and validation gates, and real `driver.py` handwriting artifacts for both new GA Gemini models.
- Added a strict Gemini structured-output contract for the Flash-Lite detector challenger, using unambiguous integer `0-1000` bounding boxes with focused configuration coverage.

### Changed
- Changed the handwriting transcription scorer to disable `SequenceMatcher` autojunk so long repetitive OCR near-matches are measured honestly, with focused regression coverage.
- Corrected the initial Flash-Lite detector classification: API-enforced JSON raised it from `8/13`, `0.6427` to `12/13`, `0.8988`, but one manually confirmed bounding-box miss still keeps it below the maintained detector.
- Changed the eval registry and methodology state to preserve the no-adoption result while keeping all maintained crop and OCR model choices unchanged and Story 191 blocked.

## [2026-07-20-02] - Reject Unlimited-OCR challenger (Story 230)

### Added
- Added a bounded exact-weight Unlimited-OCR benchmark harness with raw page/grounding provenance, transport validation, whole-case Onward scoring, corrected real-handwriting scoring, and a precommitted dual-model value gate.
- Added a portable eval attempt covering official-BF16 public-sample parity, all nine Onward candidate arms, the Barney/Alverson screen, manual artifact inspection, and the final no-adoption decision.

### Changed
- Changed the eval registry, methodology state, scout record, and generated methodology views to preserve Unlimited-OCR as negative evidence while keeping the maintained OCR paths and blocked Story 191 boundary unchanged.

## [2026-07-20-01] - Reject Grok 4.5 crop challenger

### Added
- Added a direct xAI Responses promptfoo provider with multimodal normalization, reasoning control, reported usage/cost capture, and focused transport tests.
- Added a tracked Grok 4.5 attempt covering live API verification, the maintained detector run, manual failure classification, and a bounded high-reasoning retry.

### Changed
- Changed the eval registry and methodology graph to record Grok 4.5 as non-adoptable after it missed the maintained detector quality target; the page-context gate remained ladder-gated.

## [2026-07-11-01] - Record GPT-5.6 eval challenger

### Added
- Added a bounded OpenAI Responses promptfoo provider so GPT-5.6 Sol, Terra, and Luna challenger runs can use image prompts with explicit Responses content normalization.
- Added a tracked GPT-5.6 tier-sweep attempt covering the maintained detector and page-level crop deletion gate.

### Changed
- Changed the eval registry and methodology graph to record GPT-5.6 Terra as a detector challenger but preserve the no-adoption decision because the page-context gate failed the required quality contract.

## [2026-06-30-01] - Record Claude Sonnet 5 eval challenger

### Added
- Added a tracked Claude Sonnet 5 challenger attempt covering the maintained detector and page-level crop deletion gate.

### Changed
- Changed the eval registry and methodology graph to close the Sonnet 5 item with a no-adoption decision.

## [2026-06-09-01] - Record Claude Fable 5 eval challenger

### Added
- Added a tracked Claude Fable 5 challenger attempt covering the page-level crop deletion gate.

### Changed
- Changed the bounded Anthropic promptfoo provider so frontier challenger runs can override token prices for correct result-artifact cost accounting.
- Changed the eval registry and inbox to close the Fable 5 item with a no-adoption decision.

## [2026-05-28-01] - Record Claude Opus 4.8 eval challenger

### Added
- Added a bounded Claude Opus 4.8 promptfoo provider so Anthropic challenger runs can omit unsupported sampling parameters while preserving the repo's multimodal benchmark prompts.
- Added a tracked Opus 4.8 challenger attempt covering the detector, page-context deletion gate, xhigh failed-case retries, and the corrected Barney/Alverson handwritten OCR screen.

### Changed
- Changed the Anthropic OCR client to use adaptive thinking/high effort and omit `temperature` for `claude-opus-4-8`.
- Changed the eval registry and inbox to close the Opus 4.8 item with a no-adoption decision.

## [2026-05-25-01] - Record Photon image-processing scout

### Added
- Added Scout 015 evaluating `silvia-odwyer/photon` against doc-forge's current image-processing, OCR handoff, and crop-runtime tools.

### Changed
- Changed the scout index to record the no-adoption recommendation for Photon, parking it only as a possible future browser-side preview/edit reference.

## [2026-05-20-02] - Record Gemini 3.5 Flash eval challenger

### Added
- Added a tracked Gemini 3.5 Flash challenger attempt covering detector, crop-validation, page-context, and bounded handwritten OCR screens.

### Changed
- Changed the eval registry, generated methodology graph, and attempt notes to close the Gemini 3.5 Flash item with a no-adoption decision.

## [2026-05-20-01] - Record Kimi K2.6 eval challenger

### Added
- Added a bounded promptfoo provider for Moonshot `kimi-k2.6` so model-refresh runs can test Kimi with image inputs through the direct Moonshot API.
- Added a tracked Kimi K2.6 challenger attempt covering `image-crop-extraction` and the page-level crop deletion gate.

### Changed
- Changed the eval registry, crop story logs, generated methodology graph, README benchmark key docs, and inbox to close the Kimi K2.6 item with a no-adoption decision.

## [2026-05-06-02] - Harden preview bundle portability and mixed-PDF OCR fallback

### Added
- Added a mixed text-layer/image-only PDF fixture to prove sampled PDF pages after page 1 can use deterministic single-page OCR fallback.
- Added manifest file-safety metadata so portable preview snapshots declare which bundle-local files are safe to persist and replay.

### Fixed
- Fixed preview PDF sampling so image-only sampled pages are rasterized with `pdftoppm -singlefile` and OCRed without leaking Poppler filename assumptions to consumers.
- Fixed scan-heavy PDF preview OCR so fallback work honors the remaining preview budget and reports `preview_ocr_budget_exhausted` partial/deferred coverage instead of causing load-sensitive hard preview timeouts.
- Fixed deferred PDF preview metadata so empty OCR fallback produces unique skipped-page rows with the sampled-page failure reason preserved.
- Fixed preview manifest validation so unsafe source refs, non-portable file paths, missing replay-required rows, unsafe replay claims, and portable-marked debug/private/cache-local rows are rejected.
- Fixed preview cache identity and sidecars so replay identity uses source hash/ref, parser/OCR settings, page count, bundle fingerprint, and doc-web version/ref instead of local source paths or filenames.
- Fixed the cache identity contract so `cache/cache_identity.json` validates as `doc_web_cache_identity_v1` and is exposed through `doc-web contract --json` schema versions and preview contract fingerprinting.
- Fixed cache identity privacy validation so direct schema/CLI checks reject colon-form storage/source references and partial/malformed `sha256:` fingerprint/cache-key strings while valid `sha256:<hex>` identity values remain allowed.
- Fixed cache identity validation so stale `identity_fingerprint` values are rejected, display-label path exemptions are limited to `source_identity.source_display_label`, embedded donor filenames are rejected, and valid colon-form content-hint model IDs remain allowed.
- Fixed cache identity fingerprinting so integer and float content-hint timeout inputs normalize to the same runtime identity.
- Fixed preview content-hint cache identity so default `auto` mode records the resolved effective mode and AI fallback reasons are portable instead of raw exception text.
- Fixed the module CLI entrypoint so `python -m doc_web.cli contract --json` works alongside `python -m doc_web contract --json`.
- Fixed manifest validation so required replay file paths must use their expected roles instead of validating when mislabeled as generic assets.
- Fixed manifest/cache schema validation so extra undeclared private fields are rejected and optional non-replay status sidecars do not block portable replay snapshots.
- Fixed manifest `asset_roots` validation so portable preview manifests reject absolute paths, URI/storage refs, drive-prefixed paths, backslashes, parent traversal, and empty asset-root entries.
- Fixed PDF/DOCX metadata sanitization so local source paths, storage refs, donor filenames including punctuated filename references, and donor filename stems from source-authored title/creator metadata or DOCX title paragraphs cannot enter manifest-declared portable safe files.
- Fixed PDF content hints so missing `/Title` metadata stays null in structural facts instead of using the generic display fallback as a trusted title.
- Fixed portable preview `run_id` handling so caller-provided path-like or embedded source-filename-shaped run IDs are rejected before manifest/provenance/metadata safe files are written.
- Fixed portable preview image-directory metadata plus PDF/image OCR-error rows so persisted safe files use page refs and portable error classes instead of source names or paths.
- Fixed preview CLI timeout/failure JSON so the reported status path is bundle-relative, the failed status row preserves the specific timeout or PDF rasterization failure reason, and the payload does not leak the local output directory.

## [2026-05-06-01] - Record GPT-5.5 Instant eval challenger

### Added
- Added a bounded promptfoo Responses provider for the `chat-latest` alias so model-refresh runs can test GPT-5.5 Instant with image inputs without changing maintained provider lists.
- Added a tracked GPT-5.5 Instant challenger attempt covering `image-crop-extraction`, the page-level crop deletion gate, and the cheap content-hint preview seam.

### Changed
- Changed the eval registry, crop/preview story logs, generated methodology graph, and inbox to close the GPT-5.5 Instant item with a no-adoption decision.
- Changed the `/improve-eval` skill so future eval handoffs end with an explicit adoption recommendation and yes-ready closeout step instead of verification status.

## [2026-05-04-01] - Add fast doc-web preview bundle mode (Story 228)

### Added
- Added `doc-web preview` for latency-bound, non-final preview bundles with normal bundle files, preview metadata, progress status, cache identity, and preview-to-full selector mapping.
- Added bounded preview support for text-layer PDFs, scan-heavy/deferred PDFs, DOCX, and image directories with fast OCR sampling and high-level content hints.

### Changed
- Extended the runtime contract, schemas, validator, Dossier handoff docs, README, and runbook with explicit preview schema versions, status vocabulary, coverage states, and consumer guidance.

### Fixed
- Fixed preview timeout handling so tiny explicit timeouts emit a failed status artifact and JSON error instead of a traceback.
- Fixed the installable preview path so it no longer depends on repo-local `modules.common` imports.

## [2026-04-30-02] - Land graphics-heavy rulebook semantic HTML path (Story 226)

### Added
- Added a graphics-heavy imposed-PDF recipe with logical page-order inference, critical graphics planning, graphic-manual normalization, and semantic manual conformance validation for short visual manuals/rulebooks
- Added a visual inspect loop skill and preserved Story 226 source-vs-output QA artifacts for manual crop, sectioning, and semantic-capture review loops

### Changed
- Changed chapter building, heading portioning, guided crop extraction, and page-number extraction so graphic-designed manuals can keep source-pixel rule figures near their semantic anchors while suppressing decorative or text-only visual clutter

### Fixed
- Fixed the Story 226 pilot defects found during manual review, including imposed page ordering, page-break-driven sectioning, text-contaminated crops, over/under-cropped rule diagrams, broad catalog grouping, and figure/prose anchoring regressions

## [2026-04-30-01] - Harden Gemini SDK API-version defaults (Story 227)

### Added
- Added shared Gemini SDK API-version configuration with an explicit `v1beta` default, a bounded `DOC_WEB_GEMINI_API_VERSION` override, and focused unit coverage for the default, `v1`, and invalid-version paths.

### Changed
- Changed the shared Gemini vision client and direct benchmark helper clients to pass explicit `google-genai` `http_options`, preserving the current beta-channel behavior ahead of the February 2027 SDK default switch.
- Changed Story 227 and the generated methodology views so the completed Gemini API-version hardening work is recorded as closed.

### Tested
- `python -m pytest tests/test_google_client.py -q`
- `PYTHONDONTWRITEBYTECODE=1 make methodology-check`
- `make lint`
- `git diff --check`
- `make test`

## [2026-04-17-02] - Land Digital Peter comparison benchmark close-out (Story 225)

### Added
- Added a bounded Digital Peter historical-handwriting comparison record with explicit slice IDs, annotation-derived truth reconstruction, and inspected benchmark summaries that keep the corpus as comparison-only evidence rather than an implicit maintained eval lane

### Changed
- Changed Story 225 and the generated methodology views so the handwritten backlog now records the Digital Peter result as completed negative benchmark evidence, with Story 215 remaining the only named follow-up if lawful Washington access appears

## [2026-04-17-01] - Land grouped mixed-input image OCR boundary and packaging guidance (Story 224)

### Added
- Added a checked-in `mixed-archive-images-mini` ZIP probe, a checked-in `mixed-folder-images-mini` source-native folder probe, and focused grouped-image regression coverage for the bounded shared-parent image-member continuation on both maintained mixed-input entry surfaces

### Changed
- Changed `archive_route_members_v1` and the maintained mixed ZIP/folder recipes so grouped image members now launch one bounded `images_dir` child run on both ZIP and direct-folder entry, continue that grouped child run through `ocr_ai`, and preserve inspectable grouped provenance without altering PDF-member launch behavior
- Changed README, RUNBOOK, fixture metadata, coverage truth, methodology state, generated story views, and Story 224 wording so the maintained mixed-input claim now includes the bounded grouped image-member continuation to the first `page_html_v1` artifact on one ZIP probe and one direct-folder probe
- Changed AGENTS, methodology guidance, and triage/create/build skill rules so behavior-class support expands through representative proofs instead of fragmenting into new `format × container × entry-surface` stories by default

### Fixed
- Fixed the bounded mixed-folder image-member dead end where shared-parent `.png` members on source-native folder entry previously stamped as unsupported instead of launching the maintained `images_dir` lane

## [2026-04-16-04] - Launch bounded mixed PDF-member handoff seam (Story 223)

### Added
- Added focused ZIP and direct-folder regression coverage for the shared approved-handoff launch contract on the bounded mixed-input PDF-member seam

### Changed
- Changed the maintained mixed-archive and mixed-folder recipes so their checked-in born-digital PDF member probes now launch the bounded born-digital PDF child run after writing the approved plan and handoff artifacts
- Changed the bounded mixed-input truth surfaces in README, RUNBOOK, methodology state, coverage metadata, fixture metadata, and Story 223 so they now claim the first inspected approved-plan-to-launched-PDF continuation on the checked-in ZIP and direct-folder probes

### Fixed
- Fixed `archive_route_members_v1` so launchable approved handoffs no longer collapse to `pdf_member_handoff_blocked:None` before the downstream born-digital PDF recipe starts
- Fixed the maintained born-digital PDF recipe wiring by removing the stale hard-coded Marker container override that still pointed at an old worktree mount

## [2026-04-16-03] - Finish anti-fragmentation hardening and folder parity close-out (Stories 190, 223)

### Changed
- Changed the shared story-progression guidance, triage/create/build skill contracts, and methodology reference surfaces so same-surface parity, later-state progression, and codification work now default to expansion or consolidation instead of fragmenting into new stories
- Changed the maintained mixed-folder routing proof so the direct-folder PDF member now stops at an inspectable approved-handoff dry-run artifact chain, bringing the direct-folder lane up to the same bounded approved-handoff surface already proven for the ZIP lane
- Changed Story 190 and Story 223 close-out state plus the generated methodology views so the backlog and graph now reflect both completed lines honestly

### Tested
- `make skills-check`
- `make methodology-check`
- `python -m pytest tests/test_methodology_graph.py -q`
- `make lint`
- `make test`
- `python driver.py --recipe configs/recipes/recipe-mixed-folder-routing-mvp.yaml --input-folder testdata/mixed-folder-pdf-mini --run-id validate-story223-mixed-folder-20260416 --allow-run-id-reuse --force`
- `python validate_artifact.py --schema archive_member_manifest_v1 --file output/runs/validate-story223-mixed-folder-20260416/01_folder_members_manifest_v1/archive_members_manifest.jsonl`
- `python validate_artifact.py --schema archive_member_route_v1 --file output/runs/validate-story223-mixed-folder-20260416/02_archive_route_members_v1/archive_member_routes.jsonl`
- `python validate_artifact.py --schema intake_plan_v1 --file output/runs/validate-story223-mixed-folder-20260416-member-001-recipe-intake-contact-sheet/05_confirm_plan_v1/overview_plan_final.jsonl`
- `python validate_artifact.py --schema intake_handoff_v1 --file output/runs/validate-story223-mixed-folder-20260416/02_archive_route_members_v1/pdf_member_handoffs/member-001/intake_handoff.jsonl`

## [2026-04-16-02] - Land mixed-archive approved-handoff seam (Story 223)

### Added
- Added a bounded ZIP-only PDF-member approved-handoff continuation on the maintained mixed-archive lane, including a member-local `intake_handoff_v1` sidecar and focused fixture coverage for the new route/handoff contract

### Changed
- Changed `archive_route_members_v1`, shared intake-plan helpers, the mixed-archive ZIP recipe, and `archive_member_route_v1` so ZIP-contained born-digital PDF members now stop at an inspectable approved-handoff artifact instead of only a recommendation artifact, without widening direct-folder parity or final maintained PDF launch claims
- Changed README, RUNBOOK, fixture metadata, coverage truth, methodology state, generated story views, and Story 223 wording so the maintained mixed-input claim now matches the bounded ZIP-only PDF-member approved-handoff seam

### Tested
- `make lint`
- `make test`
- `python driver.py --recipe configs/recipes/recipe-mixed-archive-zip-routing-mvp.yaml --input-zip testdata/mixed-archive-pdf-mini.zip --run-id story223-impl-r1 --allow-run-id-reuse --output-dir output/runs --force`
- `python validate_artifact.py --schema archive_member_route_v1 --file output/runs/story223-impl-r1/02_archive_route_members_v1/archive_member_routes.jsonl`
- `python validate_artifact.py --schema intake_handoff_v1 --file output/runs/story223-impl-r1/02_archive_route_members_v1/pdf_member_handoffs/member-001/intake_handoff.jsonl`
- `python validate_artifact.py --schema intake_plan_v1 --file output/runs/story223-impl-r1-member-001-recipe-intake-contact-sheet/05_confirm_plan_v1/overview_plan_final.jsonl`
- `make methodology-compile`

## [2026-04-16-01] - Land mixed-folder PDF-member seam (Story 222)

### Added
- Added a checked-in `mixed-folder-pdf-mini` source-native fixture plus focused route and fixture tests for the first bounded direct-folder born-digital PDF-member recommendation continuation on the maintained mixed-input lane

### Changed
- Changed `archive_route_members_v1` so bounded folder-contained PDF members now launch the same nested `recipe-intake-contact-sheet.yaml` recommendation-only run already proven for ZIP-contained PDF members, recording the emitted `intake_plan_v1` artifact as `first_downstream_artifact` without widening approved handoff or final-recipe auto-launch
- Changed README, RUNBOOK, fixture metadata, coverage truth, methodology state, generated story views, and Story 222 wording so the maintained mixed-input claim now matches the bounded direct-folder PDF-member recommendation seam

### Tested
- `python -m ruff check modules/ tests/`
- `python -m pytest tests/`
- `find modules -name '*.pyc' -delete`
- `python driver.py --recipe configs/recipes/recipe-mixed-folder-routing-mvp.yaml --input-folder testdata/mixed-folder-pdf-mini --run-id story222-mixed-folder-pdf-mini-close-r1 --allow-run-id-reuse --force`
- `python validate_artifact.py --schema archive_member_manifest_v1 --file output/runs/story222-mixed-folder-pdf-mini-close-r1/01_folder_members_manifest_v1/archive_members_manifest.jsonl`
- `python validate_artifact.py --schema archive_member_route_v1 --file output/runs/story222-mixed-folder-pdf-mini-close-r1/02_archive_route_members_v1/archive_member_routes.jsonl`
- `python validate_artifact.py --schema intake_plan_v1 --file output/runs/story222-mixed-folder-pdf-mini-close-r1-member-001-recipe-intake-contact-sheet/05_confirm_plan_v1/overview_plan_final.jsonl`
- `make methodology-compile`

## [2026-04-13-01] - Land mixed-archive PDF-member seam (Story 221)

### Added
- Added a checked-in `mixed-archive-pdf-mini` ZIP fixture plus focused route tests for the first bounded ZIP-only PDF-member recommendation continuation on the maintained mixed-archive lane
- Added a committed non-office direct-entry boundary probe corpus so maintained `mixed-archive` and `mixed-folder` entry kinds stay covered in the recommendation-only and approved-handoff scope harnesses

### Changed
- Changed `archive_route_members_v1` so ZIP-contained PDF members now launch a nested `recipe-intake-contact-sheet.yaml` run, record the emitted `intake_plan_v1` artifact as `first_downstream_artifact`, and surface the member-local maintained PDF recommendation without widening folder parity or final-recipe auto-launch
- Changed README, RUNBOOK, fixture metadata, coverage truth, methodology state, generated story views, and eval registry wording so the maintained mixed-input claim now matches the bounded ZIP-only PDF-member recommendation seam and the refreshed direct-entry boundary metadata

### Fixed
- Fixed non-office direct-entry boundary classification so `mixed-archive` and `mixed-folder` now report `direct_explicit_recipe_only` instead of the stale `unsupported_input_kind` bucket in the maintained benchmark harnesses

### Tested
- `python -m ruff check modules/ tests/`
- `python -m pytest tests/`
- `find modules -name '*.pyc' -delete`
- `python driver.py --recipe configs/recipes/recipe-mixed-archive-zip-routing-mvp.yaml --input-zip testdata/mixed-archive-pdf-mini.zip --run-id story221-mixed-archive-pdf-mini-close-r1 --allow-run-id-reuse --force`
- `python validate_artifact.py --schema archive_member_manifest_v1 --file output/runs/story221-mixed-archive-pdf-mini-close-r1/01_archive_unpack_manifest_v1/archive_members_manifest.jsonl`
- `python validate_artifact.py --schema archive_member_route_v1 --file output/runs/story221-mixed-archive-pdf-mini-close-r1/02_archive_route_members_v1/archive_member_routes.jsonl`
- `python validate_artifact.py --schema intake_plan_v1 --file output/runs/story221-mixed-archive-pdf-mini-close-r1-member-001-recipe-intake-contact-sheet/05_confirm_plan_v1/overview_plan_final.jsonl`
- `make methodology-compile`
- `make methodology-check`

## [2026-04-12-04] - Clear Onward row-semantic note placement (Story 220)

### Added
- Added a story-scoped structured genealogy repair lane, validation recipe, and regression coverage for the maintained Onward row-semantic note-placement seam
- Added a separate manual eval entry for the maintained row-semantic decision surface so it stays distinct from the stale pure-format consistency-planning eval

### Changed
- Changed planner target augmentation and shared OCR routing so the bounded repair path can widen the relevant chapter-009 page cluster and use `gpt-4.1` chat completions when `gpt-5` Responses scopes are unavailable
- Changed Story 219 and Story 220 documentation plus the generated methodology views so the blocked pure-format lane and the now-closed row-semantic follow-up both reflect maintained-lane truth

### Fixed
- Fixed maintained Onward child-note placement so `chapter-009.html` and `chapter-022.html` no longer leave child-note text in `DIED` while `chapter-023.html` remains conformant

### Tested
- `python -m ruff check modules/ tests/`
- `python -m pytest tests/`
- `python driver.py --recipe configs/recipes/story-220-onward-genealogy-row-semantic-note-placement-validate.yaml --run-id story220-onward-row-semantic-r7 --allow-run-id-reuse --force`
- `make methodology-compile`
- `make methodology-check`

## [2026-04-12-03] - Land mixed-folder direct-entry seam (Story 218)

### Added
- Added a bounded mixed-folder entry surface with `input_folder` / `--input-folder`, `folder_members_manifest_v1`, `recipe-mixed-folder-routing-mvp.yaml`, and a checked-in four-member fixture that proves source-native member inventory and per-member launch or block outcomes
- Added focused smoke coverage for the direct-folder seam and fixture metadata for the checked-in mixed-folder probe

### Changed
- Changed the shared intake routing seam, run labeling, coverage matrix, methodology state, generated story views, and operator docs so the maintained mixed-input proof now includes one explicit source-native folder lane beside the existing ZIP-only lane

### Fixed
- Fixed the mixed-folder close-out drift by counting Story 218 in the intake/routing audit memory and by documenting that clean repeated proof runs need a fresh parent `run_id` once nested child runs already exist

### Tested
- `make lint`
- `make test`
- `python driver.py --recipe configs/recipes/recipe-mixed-folder-routing-mvp.yaml --input-folder testdata/mixed-folder-mini --run-id story218-mixed-folder-validate-A-20260412 --force`
- `python validate_artifact.py --schema archive_member_manifest_v1 --file output/runs/story218-mixed-folder-validate-A-20260412/01_folder_members_manifest_v1/archive_members_manifest.jsonl`
- `python validate_artifact.py --schema archive_member_route_v1 --file output/runs/story218-mixed-folder-validate-A-20260412/02_archive_route_members_v1/archive_member_routes.jsonl`

## [2026-04-12-02] - Close receipt-only LOC rescue probe (Story 217)

### Added
- Added a bounded receipt-only probe summary artifact for LOC asset `367466` so the current-pass baseline, control, and frozen `gpt-5.4` variants are captured with exact params, run ids, ratios, and failure modes

### Changed
- Changed Story 217 and the generated methodology/story views so the receipt-only LOC seam now records the completed negative decision and keeps Story 191 blocked

### Fixed
- Fixed the remaining ambiguity from Story 216 by proving that prompt/entry variants on the same receipt image still do not materially clear the handwritten receipt seam

### Tested
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`
- `make methodology-compile`
- `make methodology-check`

## [2026-04-12-01] - Refresh LOC proof and bounded screen (Story 216)

### Added
- Added shared-output retry/reuse and bounded direct-image challenger support to the LOC George Washington benchmark helper so Story 216 can refresh the fixed three-asset slice and screen one stronger subject model without touching the maintained OCR runtime
- Added focused regression coverage for the helper's new parser defaults, transient-failure retry classification, and case-failure summaries

### Changed
- Changed Story 216 and the generated methodology/story views so the handwritten benchmark line now records the refreshed shared-root proof, the bounded `gpt-5.4` screen outcome, and the explicit decision to keep Story 191 blocked

### Fixed
- Fixed the proof-refresh failure mode where transient provider-demand errors could abort the first shared-root OCR case before any fresh comparison artifacts were written

### Tested
- `python scripts/spikes/loc_gw_benchmark.py --out-root /Users/cam/Documents/Projects/doc-web/output/runs/story216-loc-gw-proof-refresh-r1 --instrument --max-attempts 2 --candidate-model gpt-5.4 --candidate-retry-model gpt-5.2`
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`
- `make lint`
- `make methodology-compile`
- `make methodology-check`

## [2026-04-11-05] - Add LOC George Washington benchmark slice (Story 214)

### Added
- Added a story-local `scripts/spikes/loc_gw_benchmark.py` helper that fetches the public LOC ZIP, materializes the bounded three-asset George Washington slice, and reruns the maintained handwritten rescue recipe as comparison-only evidence
- Added targeted regression coverage for the LOC helper's dataset selection, transcript normalization, and official-source defaults

### Changed
- Changed Story 214 and the generated methodology/story views so the blocked handwritten OCR line now carries a public English longhand comparison surface with explicit artifact-backed negative evidence
- Changed Story 215 and the generated methodology/story views so the Washington Database path is preserved as an explicit access blocker instead of an implied ready follow-up

### Fixed
- Fixed benchmark packaging drift by recording image-entry OCR as the canonical LOC comparison surface and keeping PDF wrappers opt-in only

### Tested
- `python scripts/spikes/loc_gw_benchmark.py --instrument --max-attempts 2`
- `python -m pytest tests/test_loc_gw_benchmark.py -q`
- `make lint`
- `make test`
- `make methodology-compile`
- `make methodology-check`

## [2026-04-11-04] - Fix non-TOC front-matter replay (Story 213)

### Changed
- Changed non-TOC chapter assembly so source-only front-matter heading portions resolve by `source_pages` and remain fallback pages in mixed paginated documents instead of claiming the first printed chapter page

### Fixed
- Fixed memoir-style duplicate opening replay in `doc-web` chapter output and preserved the full opening continuation paragraph once

### Tested
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`
- `make lint`
- `make methodology-compile`
- `make methodology-check`
- `python driver.py --recipe /tmp/story213-memoir-non-toc.yaml --run-id rolland-alain-memoir-r01 --allow-run-id-reuse --start-from portionize_headings`

## [2026-04-11-03] - Add loop-verify coordination skill

### Added
- Added a shared `/loop-verify` skill for bounded parallel verify-and-fix loops that rerun the full scope until an entire round returns no more real issues

### Changed
- Regenerated the synced Gemini command wrapper surface so `loop-verify` is invocable through doc-web's local skill tree

## [2026-04-11-02] - Benchmark bounded DiEm handwriting slice (Story 212)

### Added
- Added a story-local `scripts/spikes/diem_htr_benchmark.py` helper that fetches a bounded `DiEm HTR` slice, materializes PAGE/ALTO-backed truth artifacts under `output/runs/`, and reruns the maintained image-entry handwritten rescue recipe as comparison-only evidence
- Added targeted regression coverage for the DiEm helper's XML extraction, retry detection, env policy, and image-only default

### Changed
- Changed Story 212 and the generated methodology/story views so the handwritten benchmark line now records the exact DiEm slice, current negative benchmark outcome, and the explicit `Washington Database` follow-up

### Fixed
- Fixed the helper/story contract drift by documenting that the canonical DiEm decision surface is image-entry OCR by default and that the helper requires local `huggingface_hub`, parquet, `Pillow`, and `pypdf` support

### Tested
- `python scripts/spikes/diem_htr_benchmark.py --help`
- `pytest -q tests/test_diem_htr_benchmark.py`
- `make lint`
- `make test`
- `make methodology-compile`
- `make methodology-check`

## [2026-04-11-01] - Scout historical handwriting eval sources (Story 211)

### Added
- Added Scout 014 for degraded-handwriting and historical-script eval sources, with a primary-source comparison of `DiEm HTR`, `Digital Peter`, `Saint Gall`, `Washington`, and `HTR-United`
- Added Story 212 as the bounded follow-up benchmark slice for `DiEm HTR`

### Changed
- Changed Story 211, `docs/scout.md`, and the generated methodology/story views so the blocked handwritten line now has one explicit next benchmark move instead of an open-ended “find more sources” note

### Tested
- `make methodology-compile`
- `make methodology-check`
- `make lint`
- `make test`

## [2026-04-10-14] - Widen degraded scanned-prose proof surface (Story 210)

### Added
- Added a repo-owned visibly degraded synthetic scanned-prose fixture at `testdata/scanned-prose-degraded.pdf` plus deterministic degraded rendering controls in `testdata/generate_scanned_prose_fixture.py`

### Changed
- Changed the scanned-prose smoke coverage, testdata docs, runbook guidance, coverage matrix, and story/methodology views so the bounded `scanned-pdf-prose` claim now includes one rougher synthetic degraded slice instead of only the pristine clean fixture

### Fixed
- Fixed the earlier over-strong degraded-fixture claim by strengthening the synthetic preset until the committed asset actually looks degraded, then re-proving the OCR lane against that rougher file instead of preserving the old metrics by inertia

### Tested
- `python -m pytest tests/`
- `make lint`
- `make methodology-compile`
- `make methodology-check`

## [2026-04-10-13] - Add page-context crop deletion gate (Story 209)

### Added
- Added a new page-context crop deletion-gate benchmark surface with a tracked 22-case overlap corpus, supporting source-page fixtures, and a portable proof note for Story 209

### Changed
- Changed the crop benchmark helper, scorer, registry, runbook, benchmark catalog, and story/methodology views so the bounded crop-only C5 surface is distinct from the broader page-context deletion gate

### Fixed
- Fixed the repo's C5 proof gap by recording an honest current-page-context decision surface instead of implying the 40-crop validator alone justified runtime simplification

### Tested
- `make lint`
- `make test`
- `make methodology-compile`
- `make methodology-check`

## [2026-04-10-12] - Make triage phase-driven by default

### Changed
- Changed the main `triage`, `triage-stories`, and `triage-evals` skills so methodology phase now creates default action pressure instead of defaulting to `no-op` when the repo still has a bounded `converge`, `climb`, or meaningful `hold` move available.
- Changed triage guidance so `converge` explicitly targets residue deletion or simplification, `climb` targets bounded advancement toward `hold`, and `no-op` is reserved for lines that are truly blocked, exhausted, or not yet falsifiable.

### Tested
- `make skills-check`

## [2026-04-10-11] - Close GLM-OCR benchmark line (Story 208)

### Added
- Added the bounded Story 208 GLM-OCR benchmark harness and story-local benchmark artifacts for the corrected handwritten blocker pair plus the Marie-Louise table-heavy seam

### Changed
- Changed Story 208, the eval registry, and the methodology state/generated views so the GLM-OCR benchmark is recorded as completed negative evidence rather than an open stronger-OCR lead

### Fixed
- Fixed the earlier over-broad runtime claim by distinguishing the repo's Rosetta `x86_64` Python limitation from the host's native `arm64` SDK path, then proving the fuller official SDK control still does not beat the incumbent seam

### Tested
- `make test`
- `make lint`
- `make methodology-compile`
- `make methodology-check`

## [2026-04-10-10] - Compile triage actionability into methodology graph

### Added
- Added methodology-graph regression coverage that proves eval descriptions and explicit `retry_when` metadata survive compilation into the generated graph.

### Changed
- Changed triage guidance plus Gemini triage wrappers to rely on compiled actionability metadata instead of ad hoc retry inference when deciding what is actionable now.
- Changed the methodology graph compiler and generated graph so stories, evals, and compromises now expose reusable actionability summaries and retry posture for triage.

### Fixed
- Fixed methodology graph coverage so eval descriptions and structured retry metadata are preserved consistently in the compiled output.

## [2026-04-10-08] - Record GLM-OCR scout handoff

### Changed
- Changed `docs/inbox.md` to preserve the Conductor Scout 018 GLM-OCR follow-up locally, including the date-corrected benchmark framing and the recommendation to test it first against Story 191's LOC handwritten pair plus one table-heavy scanned-page seam.

## [2026-04-10-07] - Harden skill sync wrapper checks

### Changed
- Tightened `scripts/sync-agent-skills.sh` so wrapper sync now fails on missing
  `user-invocable` frontmatter, mismatched Gemini wrapper content, or stale
  extra wrappers instead of only checking wrapper presence.
- Declared `format-gap-analysis` as an explicit invocable skill so its Gemini
  wrapper description comes from the skill's real frontmatter instead of the
  fallback placeholder text.
 
## [2026-04-10-09] - Refresh crop proof truth surfaces (Story 207)

### Added
- Added a tracked crop-proof refresh note under `docs/evals/attempts/` so the canonical C4 references now point at durable in-repo evidence instead of an ignored local promptfoo result file

### Changed
- Changed the crop coverage matrix, eval registry, runbook, and spec so `scanned-pdf-tables` and `image-directory-scans` now share one honest maintained `illustration_extraction` contract anchored to the fresh `0.9703` proof refresh
- Changed Story 207 and the generated methodology views so the crop proof-surface reconciliation is recorded as completed with current repo-wide validation

### Fixed
- Fixed the stale `0.9` versus `0.9678` crop-proof drift across the canonical truth surfaces
- Fixed the methodology compiler blind spot by validating coverage-row `score_sources` against their eval score and measured date

### Tested
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`
- `make methodology-compile`
- `make methodology-check`

## [2026-04-10-05] - Add AGENTS quick routing guidance

### Changed
- Added a concise AGENTS quick-route block so common requests like
  `prioritize`, `build/fix`, and `measure/benchmark/improve` now point directly
  to `docs/methodology/state.yaml`, `docs/stories/`, and
  `docs/evals/registry.yaml`.

## [2026-04-10-06] - Refresh C2 intake eval truth surfaces

### Changed
- Changed the C2 eval registry records for `auto-book-type-detection` and `approved-intake-handoff` so both surfaces now point at fresh 2026-04-10 reruns on current `HEAD`, with updated story linkage and explicit notes that newer direct-entry families remain outside the recommendation-only and approved-handoff automation lanes

### Fixed
- Fixed stale eval-truth drift where the registry still reflected pre-`web-page` / `epub` / `email-eml` / `email-mbox` evidence even though the direct-entry seams and boundary helpers had already moved on

### Tested
- `python benchmarks/scripts/run_auto_book_type_detection_eval.py --output benchmarks/results/auto-book-type-detection-improve-eval-20260410.json --run-root output/runs/auto-book-type-detection-improve-eval-20260410`
- `python benchmarks/scripts/run_approved_intake_handoff_eval.py --output benchmarks/results/approved-intake-handoff-improve-eval-20260410.json --run-root output/runs/approved-intake-handoff-improve-eval-20260410`

## [2026-04-10-04] - Repair remaining Onward genealogy fragmentation (Story 206)

### Changed
- Changed the shared Onward genealogy merge and final chapter build path so reviewed hard-case generation headings are absorbed into subgroup rows and the final written chapter HTML receives the same genealogy normalization as the helper-level path
- Changed the reviewed-golden validator and rerun fallback rules so over-fragmented regressions are flagged, while high-similarity structural simplifications no longer force the pipeline back toward noisier handoff shapes

### Fixed
- Fixed the remaining Story 206 regression where `chapter-011.html` and related reviewed hard-case chapters could still ship as many fragmented tables even after the earlier maintained-proof lane passed
- Fixed the validator blind spot that allowed reviewed-golden over-fragmentation to pass silently on the maintained Onward proof

### Tested
- `make lint`
- `make test`
- `python driver.py --recipe /tmp/story206-onward-proof.yaml --run-id story206-onward-proof-r10 --allow-run-id-reuse --start-from validate_final --force`

## [2026-04-10-02] - Land inbox capture with validated close-out work

### Changed
- Changed `/check-in-diff` so `docs/inbox.md` is treated as expected user
  capture during audit and staging instead of being flagged as unrelated drift
- Changed `/finish-and-push` so normal inbox capture rides along with the
  validated landing set by default unless the user explicitly excludes it

## [2026-04-10-03] - Restore maintained Onward full-book fidelity (Story 206)

### Changed
- Changed the maintained Onward PDF recipe, TOC portionizer, chapter builder, genealogy validator, and rerun lane so the shared full-book proof no longer replays early pages from dense same-page TOC entries and the reviewed-golden hard cases are validated against the real maintained structural bar
- Changed Story 206 and the generated methodology views so the regression recovery now closes against fresh repo-wide checks and a current shared-PDF proof run instead of a partially closed implementation note

### Fixed
- Fixed the TOC/build seam that misclassified ordinary genealogy tables as TOC pages and replayed the same early source page across multiple generated chapters
- Fixed the genealogy-table merge and rerun fallback behavior that was collapsing reviewed-golden heading/table structure across later Onward chapters while still passing the old validator

### Tested
- `make test`
- `make lint`
- `python driver.py --recipe /tmp/story206-onward-proof.yaml --run-id story206-onward-proof-r7 --force`

## [2026-04-10-01] - Add bounded mixed-archive ZIP seam (Story 205)

### Added
- Added a maintained ZIP-only mixed-archive routing lane with a checked-in recipe, two new intake modules, a repo-owned fixture pair, and focused regression coverage for the first honest `mixed-archive` slice
- Added stamped archive-member manifest and route schemas so archive-relative member identity, downstream run ids, and blocked outcomes stay inspectable end to end

### Changed
- Changed `driver.py`, `RunConfig`, shared intake routing helpers, the coverage matrix, README, runbook, story metadata, and methodology state so the repo now documents the exact bounded `input_zip` support surface honestly
- Changed Story 205 close-out records so the landed ZIP seam is treated as completed bounded evidence rather than an active roadmap promise

### Fixed
- Fixed the archive-route output-path bug that surfaced in the first real proof run by resolving driver-style relative artifact paths correctly before stamping

### Tested
- `make lint`
- `make methodology-check`
- `make test`
- `python driver.py --recipe configs/recipes/recipe-mixed-archive-zip-routing-mvp.yaml --input-zip testdata/mixed-archive-mini.zip --run-id validate-story205-mixed-archive-zip --allow-run-id-reuse --force`

## [2026-04-09-05] - Refresh methodology roadmap truth surfaces (Story 204)

### Changed
- Changed the authored methodology roadmap, active-focus framing, generated story index, and compiled graph so the current planning surfaces reflect the real open lines instead of stale active campaigns and stale audit-memory state
- Changed the methodology story closeout record so Story 204 closes against the refreshed state/graph/index truth model with explicit validation evidence

### Fixed
- Fixed methodology validation drift by rejecting any active roadmap campaign that only references terminal-status stories, with focused regression coverage for that guardrail

## [2026-04-09-04] - Add bounded MBOX direct-entry seam (Story 203)

### Added
- Added a maintained plain-text `.mbox` direct-entry runtime lane with a checked-in recipe, new intake and bundle modules, a repo-owned two-message fixture pair, and focused recipe smoke coverage for the first honest `email-mbox` slice
- Added provenance regression coverage that proves repeated message text no longer collides across archive messages and still maps one-to-one back to inspected intake rows

### Changed
- Changed `driver.py`, `RunConfig`, direct-entry boundary helpers, the coverage matrix, README, runbook, and testdata docs so `email-mbox` is documented honestly as a bounded maintained direct explicit-recipe lane
- Changed generated methodology surfaces and Story 203 metadata so the validated `.mbox` seam closes cleanly against ADR-002 without widening into attachments, threading, `.msg`, or mixed archives

### Fixed
- Fixed the archive provenance ambiguity in the `.mbox` lane by replacing repeated upstream element ids with deterministic archive-scoped ids while preserving the native Unstructured id in metadata for debugging

### Tested
- `python -m pytest tests/test_email_mbox_intake_recipe.py tests/test_email_intake_recipe.py tests/test_doc_web_cli_contract.py -q -k 'email or mbox_smoke'`
- `make lint`
- `make methodology-check`
- `make test`
- `python driver.py --recipe configs/recipes/recipe-email-mbox-html-mvp.yaml --input-mbox testdata/email-mbox-mini.mbox --run-id validate-story203-mbox-pass4 --allow-run-id-reuse --force`

## [2026-04-09-03] - Add bounded EML direct-entry seam (Story 202)

### Added
- Added a maintained plain-text `.eml` direct-entry runtime lane with a checked-in recipe, new intake and bundle modules, one repo-owned fixture pair, and focused recipe smoke coverage for the first honest `email-eml` slice
- Added clean-venv install proof for the `.[driver,email]` extra on the supported single-message `.eml` lane

### Changed
- Changed `driver.py`, `RunConfig`, direct-entry boundary helpers, the coverage matrix, README, runbook, and testdata docs so `email-eml` is documented honestly as a bounded maintained direct explicit-recipe lane
- Changed generated methodology surfaces and Story 202 metadata so the completed seam closes against ADR-002 instead of leaving the decision link implicit

### Fixed
- Fixed the packaging/runtime gap for `.eml` partitioning by exposing an explicit repo-local `email` extra and preserving subject/from/to metadata through the bounded pageless `doc-web` bundle path without fabricated page anchors

### Tested
- `make test`
- `make lint`
- `make methodology-check`
- `git diff --check`
- `python driver.py --recipe configs/recipes/recipe-email-eml-html-mvp.yaml --input-eml testdata/email-eml-mini.eml --run-id validate-story202-eml --allow-run-id-reuse --force`

## [2026-04-09-02] - Port Storybook blocked-story lifecycle hardening

### Changed
- Changed `create-story`, `build-story`, and the story template so blocked stories now explicitly keep the visible `## Plan` aligned with the unblock path or blocker reassessment work instead of stale "proceed now" prose
- Changed the local scout history to record Storybook commits `6d1b5a6` and `ccdda3f` plus the doc-web-specific adaptation decision to keep canonical blocker truth in story body sections rather than migrate it into frontmatter

### Tested
- `make methodology-compile`
- `make methodology-check`
- `make skills-check`
- `python -m pytest tests/test_methodology_graph.py -q`
- `git diff --check`

## [2026-04-09-01] - Add bounded EPUB direct-entry seam (Story 201)

### Added
- Added a maintained EPUB direct-entry runtime lane with a checked-in recipe, new intake and bundle modules, a repo-owned fixture set, and focused recipe smoke coverage for the first honest `epub` slice
- Added clean-venv install proofs for the `.[driver,epub]` extra and the supported `requirements.txt` runtime path

### Changed
- Changed `driver.py`, `RunConfig`, the coverage matrix, methodology state/graph surfaces, README, runbook, and testdata docs so EPUB is documented honestly as a bounded maintained direct explicit-recipe lane
- Changed intake-boundary helpers and tests so recommendation-only intake and approved handoff block EPUB explicitly at scope instead of treating it as an unknown or unsupported family

### Fixed
- Fixed the runtime/install gap for EPUB partitioning by pinning the maintained `unstructured[epub]` dependency surface, documenting the `pandoc` precondition, and preserving the first chapter through an EPUB-specific bundle transform instead of reusing the DOCX title split

### Tested
- `make test`
- `python -m ruff check modules/ tests/`
- `python -m pytest tests/test_run_config.py tests/test_intake_plan_utils.py tests/test_auto_book_type_detection_benchmark.py tests/test_approved_intake_handoff_benchmark.py`
- `python -m pytest tests/test_epub_intake_recipe.py tests/test_doc_web_cli_contract.py -k 'epub'`
- `make lint`
- `python driver.py --recipe configs/recipes/recipe-epub-html-mvp.yaml --input-epub testdata/epub-mini.epub --run-id story201-epub-mini --allow-run-id-reuse --force`

## [2026-04-08-06] - Add bounded web-page direct-entry seam (Story 200)

### Added
- Added a maintained checked-HTML web-page recipe, intake module, snapshot fixture pair, and focused smoke coverage for the first honest `web-page` direct-entry slice

### Changed
- Changed `driver.py`, `RunConfig`, the coverage matrix, README, runbook, and generated methodology surfaces so `web-page` is now documented honestly as a bounded maintained direct explicit-recipe lane
- Changed intake-boundary helpers and tests so recommendation-only intake and approved handoff block `web-page` explicitly at scope instead of treating it as a vague unsupported family

### Fixed
- Fixed the intake/runtime gap for checked HTML snapshots by reusing the existing `page_html_v1` to `doc-web` path instead of leaving `web-page` unowned in the coverage inventory

### Tested
- `make test`
- `make lint`
- `python driver.py --recipe configs/recipes/recipe-web-page-html-mvp.yaml --input-html testdata/web-page-mini.html --run-id story200-web-page-validate --allow-run-id-reuse --force`
- `python validate_artifact.py --schema page_html_v1 --file output/runs/story200-web-page-validate/01_web_page_html_intake_v1/pages_html.jsonl`
- `python validate_artifact.py --schema doc_web_bundle_manifest_v1 --file output/runs/story200-web-page-validate/output/html/manifest.json`
- `python validate_artifact.py --schema doc_web_provenance_block_v1 --file output/runs/story200-web-page-validate/output/html/provenance/blocks.jsonl`
- `python benchmarks/scripts/run_auto_book_type_detection_eval.py --corpus /tmp/story200-validate-web-page-boundary-corpus.json --output /tmp/story200-validate-auto-book-type-web-page.json --run-root /tmp/story200-validate-auto-book-type-run`
- `python benchmarks/scripts/run_approved_intake_handoff_eval.py --corpus /tmp/story200-validate-web-page-boundary-corpus.json --output /tmp/story200-validate-approved-handoff-web-page.json --run-root /tmp/story200-validate-approved-handoff-run`

## [2026-04-08-05] - Harden methodology graph/state contract (Story 199)

### Changed
- Changed the methodology compiler, regression tests, eval registry, live runbooks, skills, wrappers, and scout/history docs so the repo now uses one explicit state/graph methodology contract instead of stale build-map/manual-index guidance or heuristic eval-lineage scraping
- Changed Story 187 and the migration audit record so their remaining-warning language is explicitly historical rather than a false current-state claim

### Fixed
- Fixed all 11 current eval records to carry explicit lineage metadata (`story_refs`, `category_refs`, `compromise_refs`) consumed directly by the compiler
- Fixed active-surface drift across AGENTS, setup/eval runbooks, cross-CLI skill wrappers, helper scripts, ADRs 001-003, and the named scout-history surfaces so the current methodology package compiles cleanly under the widened guardrail

### Tested
- `./scripts/sync-agent-skills.sh`
- `make methodology-compile`
- `make methodology-check`
- `python -m pytest tests/test_methodology_graph.py -q`
- `python -m ruff check scripts/methodology_graph.py tests/test_methodology_graph.py`
- `make skills-check`
- `git diff --check`
- `make lint`
- `make test`

## [2026-04-08-04] - Remove stale crop/build image residue on reused run roots (Story 198)

### Changed
- Changed the guided crop runtime and HTML publisher so full reruns now prune image files that are no longer present in the refreshed illustration manifest
- Changed Story 198, the generated methodology graph, and the story index to record the same-seam stale-file fix and close the deletion story honestly

### Fixed
- Fixed reused Onward crop/build runs leaving stale `page-<n>-*.jpg` files in both `03_crop_illustrations_guided_v1/images/` and `output/html/images/` after the manifest stopped referencing them
- Fixed regression coverage so resumed crop/build runs now fail tests if unmanifested image files survive

### Tested
- `python -m py_compile modules/extract/crop_illustrations_guided_v1/main.py modules/build/build_chapter_html_v1/main.py`
- `python -m pytest tests/test_crop_runtime_recipe_contract.py tests/test_crop_illustrations_guided_v1.py tests/test_build_chapter_html.py -q`
- `make lint`
- `make test`
- `find modules/extract/crop_illustrations_guided_v1 modules/build/build_chapter_html_v1 -name "*.pyc" -delete`
- `scripts/run_driver_monitored.sh --recipe configs/recipes/recipe-onward-images-html-mvp.yaml --run-id onward-full-audit-20260318-r1 --output-dir /Users/cam/Documents/Projects/codex-forge/output/runs -- --instrument --allow-run-id-reuse --input-images /Users/cam/Documents/Projects/codex-forge/input/onward-to-the-unknown-images --start-from crop_illustrations --end-at crop_illustrations --keep-downstream`
- `scripts/run_driver_monitored.sh --recipe configs/recipes/recipe-onward-images-html-mvp.yaml --run-id onward-full-audit-20260318-r1 --output-dir /Users/cam/Documents/Projects/codex-forge/output/runs -- --instrument --allow-run-id-reuse --input-images /Users/cam/Documents/Projects/codex-forge/input/onward-to-the-unknown-images --start-from build_chapters`

## [2026-04-08-03] - Establish bounded PPTX direct-entry seam (Story 197)

### Added
- Added a maintained PPTX direct-entry runtime lane with a checked-in recipe, new intake and bundle modules, and focused recipe smoke coverage on the repo-owned `pptx-mini` fixture
- Added clean-venv install proofs for the `.[driver,pptx]` extra and the supported `requirements.txt` runtime path

### Changed
- Changed the CLI, run config, office-native bundle helpers, coverage matrix, runbook, README, eval registry, and generated methodology surfaces so PPTX is now documented honestly as a bounded maintained direct explicit-recipe lane
- Changed office-boundary helpers and benchmark expectations so `docx`, `xlsx`, and `pptx` all block at scope with the same `direct_explicit_recipe_only` policy instead of leaving PPTX as a runtime-seam special case

### Fixed
- Fixed stale install guidance by aligning `requirements.txt`, runtime error messaging, and docs with the actual maintained PPTX dependency surface

### Tested
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`
- `python -m pytest -q tests/test_doc_web_cli_contract.py -k "extra_supports_repo_owned or requirements_txt_supports_pptx"`
- `python -m pytest -q tests/test_pptx_intake_recipe.py`
- `python validate_artifact.py --schema doc_web_bundle_manifest_v1 --file output/runs/story197-pptx-proof-20260408/output/html/manifest.json`
- `python validate_artifact.py --schema doc_web_provenance_block_v1 --file output/runs/story197-pptx-proof-20260408/output/html/provenance/blocks.jsonl`

## [2026-04-08-02] - Widen born-digital PDF proof surface (Story 196)

### Added
- Added a maintained born-digital benchmark corpus, scorer, runner, and focused tests so the repo can rerun the bounded passing slice and comparison-only local cases from one checked-in harness
- Added a reproducible repo-owned book-like handbook fixture plus a generator so the maintained book-like born-digital lane is no longer proved only by `tbotb-mini`

### Changed
- Changed the `born-digital-pdf` coverage row, eval registry, runbook, README, testdata docs, methodology graph, and story index so the family now records a bounded `passing` surface across four repo-owned maintained cases

### Fixed
- Fixed the born-digital benchmark test to load its corpus through the checked-in runner default instead of a machine-specific absolute checkout path

### Tested
- `pytest tests/test_born_digital_pdf_benchmark.py -q`
- `python benchmarks/scripts/run_born_digital_pdf_eval.py --output benchmarks/results/born-digital-pdf-story196-validate-20260408b.json --run-root output/runs/story196-born-digital-benchmark-validate-20260408b`
- `make lint`
- `make methodology-compile`
- `make methodology-check`
- `make test`

## [2026-04-08-01] - Clean legacy story drift and audit memory (Story 195)

### Added
- Added Story 195 to record the methodology cleanup that retired stale legacy active-story drift and refreshed architecture-audit memory

### Changed
- Changed legacy story metadata so stale uncategorized FF/gamebook stories no longer appear as active default-queue work, including normalizing Story 017 from the non-canonical `Complete` status to `Done`
- Changed methodology audit-memory notes and recent-story references for methodology tooling, intake and routing, and doc-web runtime so the current office-line truth surfaces reflect Stories 193 through 195

### Fixed
- Fixed the generated methodology graph and story index so they no longer report any uncategorized non-done stories after the cleanup

### Tested
- `make methodology-compile`
- `make methodology-check`
- `make lint`
- `make test`

## [2026-04-07-01] - Make office intake boundary explicit (Story 194)

### Added
- Added a rerunnable office-boundary probe corpus plus shared scope-blocking helper coverage for the maintained recommendation-only and approved-handoff intake harnesses

### Changed
- Changed the maintained intake benchmark and approved-handoff harnesses so `docx`, `xlsx`, and `pptx` boundary probes now return explicit scope rows instead of failing later inside the contact-sheet builder
- Changed the story, methodology graph, story index, README, runbook, and eval registry so maintained office support is documented honestly as direct explicit-recipe entry outside recommendation-only intake automation

### Fixed
- Fixed confirmed handoff for direct-entry office recipes to report `direct_entry_recipe_outside_confirmed_handoff_scope:*` instead of the generic `unsupported_recommended_recipe:*` bucket

### Tested
- `make lint`
- `pytest tests/test_auto_book_type_detection_benchmark.py tests/test_approved_intake_handoff_benchmark.py tests/test_intake_plan_utils.py`
- `make test`
- `python benchmarks/scripts/run_auto_book_type_detection_eval.py --corpus benchmarks/input/office-intake-boundary-corpus.json --output benchmarks/results/auto-book-type-detection-story194-office-boundary.json --run-root output/runs/story194-auto-book-type-detection-office-boundary`
- `python benchmarks/scripts/run_approved_intake_handoff_eval.py --corpus benchmarks/input/office-intake-boundary-corpus.json --output benchmarks/results/approved-intake-handoff-story194-office-boundary.json --run-root output/runs/story194-approved-intake-handoff-office-boundary`
- `make methodology-compile`
- `make methodology-check`

## [2026-04-04-09] - Widen XLSX proof slice and refresh PPTX blocker (Story 193)

### Added
- Added two supported repo-owned XLSX fixtures (`xlsx-multi-sheet`, `xlsx-two-tables`) plus a bounded unsupported merged-title / formula probe, and widened XLSX smoke coverage across the supported slice

### Changed
- Changed the XLSX coverage matrix, repo docs, generated methodology graph, and generated story index so `xlsx` now records a bounded passing slice while `pptx` cites a fresh blocked import seam on the current checkout

### Fixed
- Fixed XLSX fixture generation so merged-range probes serialize faithfully from checked-in source JSON before the boundary probe is used as canonical evidence

### Tested
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`
- `python driver.py --recipe configs/recipes/recipe-xlsx-html-mvp.yaml --input-xlsx testdata/xlsx-merged-formula.xlsx --run-id story193-xlsx-merged-formula-probe-20260404 --allow-run-id-reuse --force`
- `make methodology-compile`

## [2026-04-04-08] - Stop triage from reopening blocked lines

### Changed
- Changed `/triage` and `/triage-stories` so blocked active lines with unmet unblock conditions downgrade to health flags instead of resurfacing as recommended next actions on continuity alone
- Changed `/triage-evals`, Story 190, Story 191, and the migration runbook so consumed retry triggers stay exhausted, stale pre-block implementation plans no longer override blocker evidence, and sibling repos have a copy-paste prompt for the same regression

### Tested
- `make methodology-compile`
- `make methodology-check`
- `make skills-check`
- `git diff --check`

## [2026-04-05-01] - Record failed handwritten subject-model retry

### Changed
- Changed the handwritten eval registry, Story 191 blocker evidence, and generated methodology graph so the fresh 2026-04-05 bounded `new-subject-model` retry is recorded explicitly instead of remaining as unpublished terminal evidence
- Changed the handwritten blocker record to keep Story 191 honestly `Blocked`: fresh maintained rescue reruns reproduced the current Barney and corrected-scope Alverson floor, `gpt-5.4-pro` produced empty OCR artifacts on the current path, and `gemini-3.1-pro-preview` did not beat the maintained rescue lane on both real fixtures

### Tested
- `python scripts/discover-models.py --check-new`
- `python benchmarks/scripts/run_handwritten_notes_eval.py --transcript testdata/handwritten-notes-barney-real.txt --images testdata/handwritten-notes-barney-real-images --pdf testdata/handwritten-notes-barney-real.pdf --fixture-id handwritten-notes-barney-real --image-recipe configs/recipes/recipe-images-ocr-html-handwritten-notes-gemini-rescue.yaml --pdf-recipe configs/recipes/recipe-pdf-ocr-html-handwritten-notes-gemini-rescue.yaml --image-case-id image-handwritten-rescue --pdf-case-id pdf-handwritten-rescue --output benchmarks/results/handwritten-notes-improve-eval-20260405-barney-baseline.json`
- `python benchmarks/scripts/run_handwritten_notes_eval.py --transcript testdata/handwritten-notes-alverson-real.txt --images testdata/handwritten-notes-alverson-real-images --pdf testdata/handwritten-notes-alverson-real.pdf --fixture-id handwritten-notes-alverson-real --image-recipe configs/recipes/recipe-images-ocr-html-handwritten-notes-gemini-rescue.yaml --pdf-recipe configs/recipes/recipe-pdf-ocr-html-handwritten-notes-gemini-rescue.yaml --image-case-id image-handwritten-rescue --pdf-case-id pdf-handwritten-rescue --output benchmarks/results/handwritten-notes-improve-eval-20260405-alverson-baseline.json`
- `make methodology-compile`
- `make methodology-check`

## [2026-04-04-07] - Repair handwritten Alverson truth surface (Story 192)

### Added
- Added a focused handwritten transcript-scope regression in `tests/test_handwritten_notes_eval.py` so the repo-owned Alverson fixture cannot silently widen past the checked-in front page again

### Changed
- Changed the Alverson handwritten transcript and fixture docs so the repo-owned benchmark now scores only the visible LOC front page instead of an over-scoped transcript that continued onto the unowned back page
- Changed the handwritten eval registry, coverage matrix, Story 191 blocker record, generated methodology graph, and generated story index so the real handwritten lane is now blocked honestly on OCR quality against the corrected corpus, not on a live source/transcript mismatch

### Tested
- `python benchmarks/scripts/run_handwritten_notes_eval.py --transcript testdata/handwritten-notes-alverson-real.txt --images testdata/handwritten-notes-alverson-real-images --pdf testdata/handwritten-notes-alverson-real.pdf --fixture-id alverson-truth-frontpage --image-recipe configs/recipes/recipe-images-ocr-html-handwritten-notes-gemini-rescue.yaml --pdf-recipe configs/recipes/recipe-pdf-ocr-html-handwritten-notes-gemini-rescue.yaml --image-case-id image-handwritten-rescue --pdf-case-id pdf-handwritten-rescue --output /tmp/alverson-truth-frontpage.json`
- `python benchmarks/scripts/run_handwritten_notes_eval.py --image-recipe configs/recipes/recipe-images-ocr-html-handwritten-notes-gemini-rescue.yaml --pdf-recipe configs/recipes/recipe-pdf-ocr-html-handwritten-notes-gemini-rescue.yaml --image-case-id image-handwritten-rescue --pdf-case-id pdf-handwritten-rescue --output benchmarks/results/handwritten-notes-story192-alverson-frontpage.json`
- `make test`
- `make lint`
- `make methodology-compile`
- `make methodology-check`
- `git diff --check`

## [2026-04-04-06] - Block handwritten LOC closeout on truth-surface evidence

### Changed
- Changed the handwritten eval registry, coverage matrix, fixture docs, generated methodology graph, generated story index, and Story 191 record so the real handwritten lane now blocks honestly instead of implying that another OCR tweak would finish it
- Changed the handwritten story state so Story 191 closes as `Blocked` with explicit blocker evidence: Barney still stays below bar on fresh maintained and stronger direct-model probes, and the checked-in Alverson front-page fixture is now recorded as a source/transcript alignment blocker rather than a clean lower-page OCR miss

### Tested
- `python benchmarks/scripts/run_handwritten_notes_eval.py --image-recipe configs/recipes/recipe-images-ocr-html-handwritten-notes-gemini-rescue.yaml --pdf-recipe configs/recipes/recipe-pdf-ocr-html-handwritten-notes-gemini-rescue.yaml --image-case-id image-handwritten-rescue --pdf-case-id pdf-handwritten-rescue --output benchmarks/results/handwritten-notes-story191-baseline-20260404.json`
- `python driver.py --recipe configs/recipes/recipe-images-ocr-html-handwritten-notes-gemini-rescue.yaml --settings /tmp/story191-gpt5-direct-settings.yaml --input-images testdata/handwritten-notes-barney-real-images --run-id story191-barney-image-gpt5-direct --allow-run-id-reuse --force --end-at ocr_ai`
- `python driver.py --recipe configs/recipes/recipe-pdf-ocr-html-handwritten-notes-gemini-rescue.yaml --settings /tmp/story191-gpt5-direct-settings.yaml --input-pdf testdata/handwritten-notes-barney-real.pdf --run-id story191-barney-pdf-gpt5-direct --allow-run-id-reuse --force --end-at ocr_ai`
- `python driver.py --recipe configs/recipes/recipe-images-ocr-html-handwritten-notes-gemini-rescue.yaml --settings /tmp/story191-gpt5-direct-settings.yaml --input-images testdata/handwritten-notes-alverson-real-images --run-id story191-alverson-image-gpt5-direct --allow-run-id-reuse --force --end-at ocr_ai`
- `python driver.py --recipe configs/recipes/recipe-pdf-ocr-html-handwritten-notes-gemini-rescue.yaml --settings /tmp/story191-gpt5-direct-settings.yaml --input-pdf testdata/handwritten-notes-alverson-real.pdf --run-id story191-alverson-pdf-gpt5-direct --allow-run-id-reuse --force --end-at ocr_ai`
- `python driver.py --recipe configs/recipes/recipe-images-ocr-html-handwritten-notes-gemini-rescue.yaml --settings /tmp/story191-claude-direct-settings.yaml --input-images testdata/handwritten-notes-barney-real-images --run-id story191-barney-image-claude-direct --allow-run-id-reuse --force --end-at ocr_ai`
- `python driver.py --recipe configs/recipes/recipe-images-ocr-html-handwritten-notes-gemini-rescue.yaml --settings /tmp/story191-claude-direct-settings.yaml --input-images testdata/handwritten-notes-alverson-real-images --run-id story191-alverson-image-claude-direct --allow-run-id-reuse --force --end-at ocr_ai`
- `make methodology-compile`
- `make methodology-check`
- `git diff --check`

## [2026-04-04-05] - Finish widened real handwritten proof surface in Story 189

### Added
- Added the second repo-owned real handwritten fixture, `handwritten-notes-alverson-real`, plus widened handwritten corpus and smoke coverage so the maintained rescue seam is measured against two real LOC letter pages instead of one

### Changed
- Changed `ocr_ai_gpt51_v1` so direct OpenAI `gpt-5` vision probes omit unsupported `temperature`, keeping the shared OCR module usable for bounded model comparison work
- Changed the handwritten eval registry, coverage matrix, fixture docs, and story record so the family now closes honestly on the widened five-fixture corpus result: `pass_rate = 0.6`, `overall_min_ratio = 0.496975`, and status remains `has-fixture`

### Tested
- `python -m pytest tests/test_ocr_ai_gpt51_empty_page_recovery.py tests/test_handwritten_notes_eval.py -q`
- `python -m pytest tests/test_handwritten_notes_eval.py tests/test_image_directory_intake_recipe.py tests/test_pdf_intake_recipe.py -q`
- `python -m ruff check modules/extract/ocr_ai_gpt51_v1/main.py tests/test_ocr_ai_gpt51_empty_page_recovery.py tests/test_handwritten_notes_eval.py benchmarks/scripts/run_handwritten_notes_eval.py`
- `python -m ruff check benchmarks/scripts/run_handwritten_notes_eval.py tests/test_handwritten_notes_eval.py tests/test_image_directory_intake_recipe.py tests/test_pdf_intake_recipe.py modules/extract/ocr_ai_gpt51_v1/main.py tests/test_ocr_ai_gpt51_empty_page_recovery.py`
- `python benchmarks/scripts/run_handwritten_notes_eval.py --image-recipe configs/recipes/recipe-images-ocr-html-handwritten-notes-gemini-rescue.yaml --pdf-recipe configs/recipes/recipe-pdf-ocr-html-handwritten-notes-gemini-rescue.yaml --image-case-id image-handwritten-rescue --pdf-case-id pdf-handwritten-rescue --instrument --output benchmarks/results/handwritten-notes-story189-real-expanded.json`

## [2026-04-04-04] - Close problem-first story workflow repair (Story 190)

### Added
- Added a cross-repo migration runbook for problem-first triage, honest story-state transitions, blocked-story recording, and anti-fragmentation workflow adoption

### Changed
- Changed the story-lifecycle skills, repo policy, and methodology reference so triage ranks problems before story shells, `/create-story` can stop on same-line work instead of minting a new ID, `/build-story` can promote or block from evidence, and close-out keeps same-surface work together by default
- Changed the story template, methodology compiler, generated graph, and generated story index so blocked-story truth is canonical and inspectable in both authored story artifacts and compiled planning surfaces

### Tested
- `make lint`
- `make test`
- `make methodology-compile`
- `make methodology-check`
- `make skills-check`
- `python -m pytest tests/test_methodology_graph.py -q`
- `python -m ruff check scripts/methodology_graph.py tests/test_methodology_graph.py`
- `git diff --check`

## [2026-04-04-03] - Close bounded handwritten Barney rescue seam (Story 189)

### Added
- Added bounded maintained handwritten rescue recipes for Barney image-directory and PDF entry, plus handwritten eval-helper instrumentation capture for per-case latency and cost evidence

### Changed
- Changed the maintained handwritten truth surface to record the Gemini rescue seam, the fresh current-tip generic Barney baseline, and the current family status of `has-fixture` instead of broad handwritten `passing`
- Changed the handwritten coverage matrix, generated methodology graph, generated story index, and story record so recipe ownership and validation state now match the inspected Barney rescue evidence

### Tested
- `python benchmarks/scripts/run_handwritten_notes_eval.py --image-recipe configs/recipes/recipe-images-ocr-html-handwritten-notes-gemini-rescue.yaml --pdf-recipe configs/recipes/recipe-pdf-ocr-html-handwritten-notes-gemini-rescue.yaml --image-case-id image-handwritten-rescue --pdf-case-id pdf-handwritten-rescue --instrument --output benchmarks/results/handwritten-notes-story189-handwritten-rescue.json`
- `python benchmarks/scripts/run_handwritten_notes_eval.py --transcript testdata/handwritten-notes-barney-real.txt --images testdata/handwritten-notes-barney-real-images --pdf testdata/handwritten-notes-barney-real.pdf --instrument --output benchmarks/results/story189-barney-generic-current.json`
- `python -m pytest tests/test_handwritten_notes_eval.py tests/test_image_directory_intake_recipe.py tests/test_pdf_intake_recipe.py`
- `python -m ruff check benchmarks/scripts/run_handwritten_notes_eval.py tests/test_handwritten_notes_eval.py tests/test_image_directory_intake_recipe.py tests/test_pdf_intake_recipe.py`
- `make methodology-compile`
- `make methodology-check`
- `make skills-check`
- `make lint`
- `make test`

## [2026-04-04-02] - Backfill legacy methodology metadata (Story 188)

### Added
- Added explicit frontmatter to the remaining canonical legacy story records so the repo's methodology graph now reads authored metadata instead of legacy headers
- Added regression coverage for canonical story discovery and frontmatter-first story/ADR parsing in the methodology compiler tests

### Changed
- Changed the methodology compiler to ignore non-canonical story companion docs and to treat frontmatter as the source of truth for structured story and ADR metadata
- Changed the methodology graph, generated story index, and methodology state to record the completed legacy-metadata cleanup pass alongside the existing graph/state migration campaign

### Tested
- `make methodology-compile`
- `make methodology-check`
- `python -m pytest tests/test_methodology_graph.py -q`
- `python -m ruff check scripts/methodology_graph.py tests/test_methodology_graph.py`
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`
- `git diff --check`

## [2026-04-04-01] - Close methodology graph and state migration (Story 187)

### Added
- Added repo-specific methodology graph migration assets, including structured methodology state, a deterministic graph compiler, a generated story index, archived hand-authored planning snapshots, and the bounded `triage-architecture` lane

### Changed
- Changed AGENTS, methodology docs, setup surfaces, ADR/story templates, and the main planning skills to use graph/state plus the canonical coverage matrix instead of the live hand-authored build map
- Changed the methodology lint contract and certification record so the active-surface checks now cover the full audited consumer set and the phase proof matches the actual migration phases

### Tested
- `make methodology-compile`
- `make methodology-check`
- `make skills-check`
- `python -m pytest tests/test_methodology_graph.py -q`
- `python -m ruff check scripts/methodology_graph.py tests/test_methodology_graph.py`
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`

## [2026-04-03-06] - Close first real handwritten fixture proof surface (Story 186)

### Added
- Added the first repo-owned real handwritten fixture, `handwritten-notes-barney-real`, with its checked-in Barney image, transcript excerpt, PDF wrapper, and focused image-directory/PDF smoke coverage

### Changed
- Changed the handwritten corpus, build map, eval registry, coverage matrix, testdata docs, and story records so `handwritten-notes` now distinguishes the still-passing synthetic slice from the first weak real handwritten checkpoint and remains `has fixture` rather than `passing`

### Tested
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`

## [2026-04-03-05] - Close widened handwritten proof slice (Story 185)

### Added
- Added a third repo-owned handwritten fixture, `handwritten-notes-faded`, plus focused image-directory/PDF smoke coverage so the maintained handwritten proof surface no longer rests on only two synthetic notes

### Changed
- Changed the handwritten fixture generator, corpus metadata, testdata docs, build map, eval registry, coverage matrix, and story records so `handwritten-notes` now reflects a wider but still synthetic three-fixture proof claim

### Tested
- `pytest -q tests/test_handwritten_notes_eval.py tests/test_image_directory_intake_recipe.py tests/test_pdf_intake_recipe.py`
- `python benchmarks/scripts/run_handwritten_notes_eval.py --output benchmarks/results/handwritten-notes-story185-widened.json`
- `make lint`
- `make test`

## [2026-04-03-04] - Close bounded crop runtime simplification (Story 184)

### Added
- Added a maintained-recipe contract test so the bounded Onward lane cannot silently drift back to retry, refine, or validator crop runtime settings

### Changed
- Changed the maintained Onward crop recipe to remove validator, retry, and refine loops from the bounded slice while retaining caption assist and layout trim where the reviewed seal page still needs them
- Changed the crop methodology docs, including the spec, build map, runbook, and story records, so C4 now reflects the current bounded Flash-first state and the passing `0.9678 / 1.0` maintained deletion gate
- Changed chapter building so text-bearing crops suppress immediately adjacent duplicate OCR paragraphs when the crop's own OCR already carries that text in the published figure

### Tested
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`
- `python -m pytest tests/test_build_chapter_html.py -q`
- `scripts/run_driver_monitored.sh --recipe configs/recipes/recipe-onward-images-html-mvp.yaml --run-id onward-full-audit-20260318-r1 --output-dir /Users/cam/Documents/Projects/codex-forge/output/runs -- --instrument --allow-run-id-reuse --input-images /Users/cam/Documents/Projects/codex-forge/input/onward-to-the-unknown-images --start-from crop_illustrations --end-at crop_illustrations --keep-downstream`
- `scripts/run_driver_monitored.sh --recipe configs/recipes/recipe-onward-images-html-mvp.yaml --run-id onward-full-audit-20260318-r1 --output-dir /Users/cam/Documents/Projects/codex-forge/output/runs -- --instrument --allow-run-id-reuse --input-images /Users/cam/Documents/Projects/codex-forge/input/onward-to-the-unknown-images --start-from build_chapters`

## [2026-04-03-03] - Repair maintained crop detector truth surface

### Added
- Added a focused crop benchmark guardrail so repo checks fail if the maintained `image-crop-extraction` task drops the `conservative-count` prompt again

### Changed
- Changed the maintained C4 crop benchmark task, eval registry, build map, runbook, benchmark README, and story record so the official detector surface again includes the winning `conservative-count` prompt and reports the refreshed maintained-task score of `0.918` overall / `1.0` pass rate

### Tested
- `python -m pytest tests/test_crop_benchmark_substrate.py -q`
- `cd benchmarks && promptfoo eval -c tasks/image-crop-extraction.yaml --no-cache --filter-providers 'google:gemini-3-flash-preview' --filter-prompts 'conservative-count' --output results/image-crop-extraction-g3flash-conservative-count-20260403.json -j 1`
- `make lint`
- `make test`
- `cd benchmarks && promptfoo eval -c tasks/image-crop-extraction.yaml --no-cache --filter-providers 'google:gemini-3-flash-preview' --filter-prompts 'conservative-count' --output results/image-crop-extraction-g3flash-conservative-count-20260403-mainlanding.json -j 1`

## [2026-04-03-02] - Close crop benchmark substrate and C5 validation surface (Story 183)

### Added
- Added tracked crop benchmark input fixtures plus focused substrate-integrity test coverage so the maintained crop promptfoo surfaces now run from this repo checkout instead of an external recovery path

### Changed
- Changed the crop truth-surface docs and registry so `crop-validation` is the dedicated bounded C5-linked surface, while `image-crop-extraction` remains the page-level detector-quality surface for C4

### Tested
- `python -m pytest tests/test_crop_benchmark_substrate.py -q`
- `python -m ruff check modules/ tests/`
- `make lint`
- `make test`
- `cd benchmarks && promptfoo eval -c tasks/crop-validation.yaml --no-cache --filter-first-n 1 -j 1 --no-write`

## [2026-04-03-01] - Close handwritten synthetic corpus proof surface (Story 182)

### Added
- Added a second rough synthetic handwritten-notes fixture, corpus metadata, and focused corpus test coverage so the maintained handwritten proof surface no longer rests on one easy synthetic note

### Changed
- Changed the handwritten eval helper to run a multi-fixture corpus with fixture-specific run IDs and updated the build map, eval registry, coverage matrix, testdata docs, and story records to reflect the broader but still synthetic handwritten claim

### Tested
- `pytest tests/test_handwritten_notes_eval.py tests/test_image_directory_intake_recipe.py tests/test_pdf_intake_recipe.py -q`
- `python benchmarks/scripts/run_handwritten_notes_eval.py --output benchmarks/results/handwritten-notes-validate-20260403.json`
- `make lint`
- `make test`

## [2026-04-02-02] - Close maintained layout benchmark proof surface (Story 181)

### Added
- Added the first maintained layout section-splitting benchmark corpus, scorer, runner, and focused benchmark test coverage for the repo-owned DOCX and flat born-digital proof slice

### Changed
- Changed the C3 truth surface in the eval registry, build map, story records, and inbox so Category 3 now has a bounded maintained quality benchmark with challenger comparison instead of an unmeasured planning claim

### Tested
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`
- `python benchmarks/scripts/run_layout_section_splitting_eval.py --output benchmarks/results/layout-section-splitting-story181.json --run-root output/runs/story181-layout-benchmark`

## [2026-04-02-01] - Close repo-owned image-directory handoff proof (Story 180)

### Added
- Added a dedicated approved-intake-handoff corpus that preserves the locked 10-case recommendation-only PDF surface while adding one repo-owned image-directory proof case
- Added focused benchmark coverage for the image-directory recipe's first downstream artifact expectations

### Changed
- Changed the approved-intake-handoff harness default to the dedicated corpus and updated the eval registry, build map, and story records so C2/B10 now reflect one repo-owned measured image-directory handoff case

### Tested
- `make lint`
- `python -m pytest tests/test_approved_intake_handoff_benchmark.py -q`
- `make test`
- `python benchmarks/scripts/run_approved_intake_handoff_eval.py --output benchmarks/results/approved-intake-handoff-story180-validation.json --run-root output/runs/story180-approved-intake-handoff-validation`

## [2026-04-01-04] - Close handwritten-notes proof surface (Story 179)

### Added
- Added the repo-owned synthetic handwritten-notes fixture set, including the checked-in transcript, generator, image-directory assets, and image-only PDF wrapper
- Added a focused handwritten transcription scorer and rerun helper plus cheap image-directory/PDF scan-entry smoke coverage

### Changed
- Updated the build map, eval registry, coverage matrix, testdata docs, and story records so `handwritten-notes` now reflects the bounded synthetic passing slice on the maintained generic OCR lanes

### Tested
- `make lint`
- `make test`
- `python -m pytest tests/test_pdf_intake_recipe.py tests/test_image_directory_intake_recipe.py -q`
- `python benchmarks/scripts/run_handwritten_notes_eval.py --output benchmarks/results/handwritten-notes-validate.json`

## [2026-04-01-03] - Close corpus-wide approved intake handoff proof (Story 178)

### Added
- Added a dedicated corpus-wide approved-handoff benchmark harness and scorer that carry the locked maintained intake corpus through `run_dispatch_v1` and record launch versus explicit non-launch outcomes with first-stage artifact paths
- Added focused benchmark coverage for recipe-first-stage derivation and approved-handoff launch/skip scoring

### Changed
- Updated the C2 eval registry, build map, and story records so the locked 10-document maintained intake PDF corpus now has corpus-wide approved-handoff evidence while image-directory remains an explicit representative residual

### Tested
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`
- `python -m ruff check benchmarks/scorers/approved_intake_handoff.py benchmarks/scripts/run_approved_intake_handoff_eval.py tests/test_approved_intake_handoff_benchmark.py`
- `python benchmarks/scripts/run_approved_intake_handoff_eval.py --output benchmarks/results/approved-intake-handoff-story178.json --run-root output/runs/story178-approved-intake-handoff`

## [2026-04-01-02] - Close flat born-digital proof lane and heading polish (Story 177)

### Added
- Added the repo-owned `flat-born-digital-form-mini` fixture pair and focused fixture coverage so the maintained non-TOC born-digital lane no longer rests on a single repo-owned flat mini PDF

### Changed
- Updated the born-digital build map, coverage matrix, testdata docs, story records, and triage skill wording to reflect the widened proof surface and the single-acceptance prompt

### Fixed
- Fixed flat born-digital final HTML so repeated short in-body headings are demoted after the primary chapter heading and pathological long warning blocks are flattened into emphasis paragraphs on the proven slice

### Tested
- `pytest -q tests/test_build_chapter_html.py tests/test_pdf_intake_recipe.py`
- `make lint`
- `make test`
- `make skills-check`
- `python driver.py --recipe configs/recipes/recipe-born-digital-pdf-non-toc-html-mvp.yaml --input-pdf testdata/flat-born-digital-form-mini.pdf --run-id story177-closeout-form-r2 --output-dir output/runs --force`
- `python validate_artifact.py --schema doc_web_bundle_manifest_v1 --file output/runs/story177-closeout-form-r2/output/html/manifest.json`
- `python validate_artifact.py --schema doc_web_provenance_block_v1 --file output/runs/story177-closeout-form-r2/output/html/provenance/blocks.jsonl`

## [2026-04-01-01] - Close confirmed intake handoff lane (Story 176)

### Added
- Added a maintained confirmed-handoff intake recipe plus stamped `intake_handoff_v1` artifacts for approved plan launches into explicit recipes
- Added the manual `approved-intake-handoff` proof surface and focused coverage for handoff generation, recipe wiring, and `RunConfig.input_images`

### Changed
- Changed `run_dispatch_v1` to consume approved plans directly, record launch metadata, and launch supported image-directory/PDF explicit recipes without manual recipe-path retyping
- Changed `driver.py` and `RunConfig` so image-directory runs now support explicit `--input-images` / `input_images` overrides, including the hardcoded first-stage image-manifest params
- Changed the build map, eval registry, story records, and the `triage` skill so C2 truth reflects the maintained handoff lane and `/triage` ends with a yes/no decision prompt

### Fixed
- Fixed the old dispatch seam by removing `dispatch_hint_v1` and the previous recipe-only launch path that dropped source-input trace
- Fixed missing-recipe, unsupported-input, and missing-source cases so they now emit inspectable non-launch outcomes instead of shelling broken downstream runs

### Tested
- `pytest -q tests/test_intake_plan_utils.py modules/intake/tests/test_intake_chain_e2e.py tests/test_run_config.py tests/test_pdf_intake_recipe.py`
- `make lint`
- `make test`
- `python validate_artifact.py --schema intake_handoff_v1 --file output/runs/story176-image-proof/06_run_dispatch_v1/intake_handoff.jsonl`
- `python validate_artifact.py --schema intake_handoff_v1 --file output/runs/story176-scanned-proof/06_run_dispatch_v1/intake_handoff.jsonl`
- `python validate_artifact.py --schema intake_handoff_v1 --file output/runs/story176-born-proof/06_run_dispatch_v1/intake_handoff.jsonl`

## [2026-03-31-02] - Widen office document proof and add maintained XLSX lane (Story 175)

### Added
- Added a shared office-native bundle emitter, a maintained XLSX recipe plus intake/transform modules, and repo-owned XLSX/PPTX probe fixtures alongside two new DOCX proof fixtures

### Changed
- Widened the maintained DOCX proof surface to three repo-owned fixtures and updated the README, runbook, build map, coverage matrix, testdata docs, and story records to reflect the current office-document reality

### Fixed
- Fixed DOCX bundle splitting so sentence-like top-level `Title` misclassifications no longer create false chapters on the widened supported slice
- Fixed the maintained runtime surface so XLSX is exposed through explicit `driver.py` / `RunConfig` input plumbing instead of hidden recipe-only params

### Tested
- `make lint`
- `make test`
- `python validate_artifact.py --schema doc_web_bundle_manifest_v1 --file output/runs/story175-docx-sections-r2/output/html/manifest.json`
- `python validate_artifact.py --schema doc_web_provenance_block_v1 --file output/runs/story175-docx-sections-r2/output/html/provenance/blocks.jsonl`
- `python validate_artifact.py --schema doc_web_bundle_manifest_v1 --file output/runs/story175-xlsx-mini-r2/output/html/manifest.json`
- `python validate_artifact.py --schema doc_web_provenance_block_v1 --file output/runs/story175-xlsx-mini-r2/output/html/provenance/blocks.jsonl`

## [2026-03-31-01] - Add dependency freshness gates for repo installs

### Added
- Added a repo-owned `scripts/install_with_age_gate.py` wrapper plus unit coverage so pip-style installs can reject package releases newer than 7 days

### Changed
- Added a project-level `tool.uv.exclude-newer = "7 days"` policy and updated the README/runbook to document the hardened install path
- Clarified the benchmark/npm setup docs so the global `promptfoo` install only claims cooldown protection when the user's npm actually supports `min-release-age`

### Tested
- `python -m pytest tests/test_install_with_age_gate.py -q`
- `python scripts/install_with_age_gate.py --dry-run .`
- `python scripts/install_with_age_gate.py --dry-run -r requirements.txt`

## [2026-03-30-02] - Harden DOCX runtime surface and contract signaling (Story 174)

### Added
- Added an explicit `.[docx]` optional dependency surface for the maintained DOCX recipe and published a machine-readable `compatibility_policy` in `doc-web contract --json`

### Changed
- Expanded the broader repo runtime surface in `requirements.txt` to install DOCX support and updated the README, runbook, contract docs, handoff docs, build map, and readiness note to describe the explicit DOCX install story and compatibility policy

### Fixed
- Fixed the maintained DOCX recipe so the repo-supported runtime surface no longer fails on missing DOCX dependencies
- Fixed the downstream contract guidance so pageless provenance remains valid and consumers do not overinterpret `contract_version` as the sole compatibility gate

### Tested
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`
- `python validate_artifact.py --schema doc_web_bundle_manifest_v1 --file output/runs/story174-docx-r1/output/html/manifest.json`
- `python validate_artifact.py --schema doc_web_provenance_block_v1 --file output/runs/story174-docx-r1/output/html/provenance/blocks.jsonl`
- `python validate_artifact.py --schema doc_web_bundle_manifest_v1 --file /tmp/story174-req-verify-6FWnFT/output/story174-req312-r1/output/html/manifest.json`
- `python validate_artifact.py --schema doc_web_provenance_block_v1 --file /tmp/story174-req-verify-6FWnFT/output/story174-req312-r1/output/html/provenance/blocks.jsonl`
- `python -m doc_web contract --json`

## [2026-03-30-01] - Harden Dossier `doc-web` adoption flow (Story 173)

### Added
- Added an explicit `.[driver]` optional dependency surface and clean-venv smoke coverage for the documented repo-owned `driver.py` fixture lane
- Added bounded Marker-lite substep progress events for the maintained non-TOC born-digital proof lane

### Changed
- Split the published consumer install story so `python -m pip install .` is contract-preflight only and `python -m pip install '.[driver]'` is the supported repo-owned smoke install shape
- Updated the README, runbook, downstream handoff doc, readiness note, and story records to match the hardened Dossier-facing runtime boundary

### Fixed
- Removed the maintained `driver.py` Pydantic stamping deprecations and timezone-naive UTC helpers exercised by the documented proof lanes
- Removed the maintained `schemas.py` class-config deprecations surfaced during Python 3.12 proof-lane reruns

### Tested
- `make test`
- `make lint`
- `python validate_artifact.py --schema doc_web_bundle_manifest_v1 --file output/runs/story173-docweb-smoke-r2/output/html/manifest.json`
- `python validate_artifact.py --schema doc_web_provenance_block_v1 --file output/runs/story173-docweb-smoke-r2/output/html/provenance/blocks.jsonl`
- `python validate_artifact.py --schema doc_web_bundle_manifest_v1 --file output/runs/story173-nontoc-r2/output/html/manifest.json`
- `python validate_artifact.py --schema doc_web_provenance_block_v1 --file output/runs/story173-nontoc-r2/output/html/provenance/blocks.jsonl`
- `python3.12 -m venv /tmp/story173-py312-1b6Olu/venv`
- `/tmp/story173-py312-1b6Olu/venv/bin/python -W default driver.py --recipe configs/recipes/doc-web-fixture-bundle-smoke.yaml --run-id validate173-py312-fixture --allow-run-id-reuse --force --output-dir /tmp/story173-py312-1b6Olu/runs`
- `/tmp/story173-py312-1b6Olu/venv/bin/python -W default driver.py --recipe configs/recipes/recipe-born-digital-pdf-non-toc-html-mvp.yaml --input-pdf testdata/flat-born-digital-mini.pdf --run-id validate173-py312-nontoc --allow-run-id-reuse --force --output-dir /tmp/story173-py312-1b6Olu/runs`

## [2026-03-29-03] - Close maintained DOCX intake lane (Story 172)

### Added
- Added the maintained DOCX recipe `configs/recipes/recipe-docx-html-mvp.yaml`, the new `unstructured_docx_intake_v1` and `docx_elements_to_bundle_v1` modules, the repo-owned `testdata/docx-mini.docx` fixture plus its source/generator, and focused DOCX recipe coverage in `tests/test_docx_intake_recipe.py`

### Changed
- Closed Story 172 on fresh `driver.py` proof that the maintained DOCX lane emits accepted `doc_web_bundle` output plus pageless block provenance for the checked-in heading/prose/list/table slice
- Updated the build map, runbook, coverage matrix, testdata docs, story records, and the public bundle contract so DOCX now honestly sits at `has fixture` with stable source-anchor provenance instead of the prior `untested` gap
- Clarified the `/validate` skill so close-out bookkeeping owned by `/mark-story-done` or `/finish-and-push` is reported separately from implementation completeness

### Fixed
- Corrected unstructured element serialization to preserve DOCX categories instead of flattening them to `Unknown`
- Allowed the `doc_web` provenance contract to represent pageless sources without fabricating page numbers while still requiring stable `source_element_ids`

### Tested
- `make lint`
- `make test`
- `make skills-check`
- `python -m pytest tests/test_docx_intake_recipe.py tests/test_doc_web_bundle_contract.py -q`
- `python driver.py --recipe configs/recipes/recipe-docx-html-mvp.yaml --input-docx testdata/docx-mini.docx --run-id story172-validate-r1 --force`
- `python validate_artifact.py --schema doc_web_bundle_manifest_v1 --file output/runs/story172-validate-r1/output/html/manifest.json`
- `python validate_artifact.py --schema doc_web_provenance_block_v1 --file output/runs/story172-validate-r1/output/html/provenance/blocks.jsonl`

## [2026-03-29-02] - Close maintained non-TOC born-digital lane (Story 171)

### Added
- Added the explicit maintained non-TOC born-digital recipe `configs/recipes/recipe-born-digital-pdf-non-toc-html-mvp.yaml`, the repo-owned flat fixture `testdata/flat-born-digital-mini.md` / `testdata/flat-born-digital-mini.pdf`, its generator `testdata/generate_flat_born_digital_fixture.py`, and focused non-TOC portionize/build regression coverage

### Changed
- Closed Story 171 on fresh `driver.py` proof that flat born-digital PDFs can now reach accepted `doc_web_bundle` output through the maintained non-TOC lane while keeping the book-like Marker-lite lane separate
- Updated the build map, eval registry, coverage matrix, story records, and locked intake benchmark corpus so the born-digital PDF truth surfaces reflect the widened maintained routing slice honestly

### Fixed
- Routed the proven short flat born-digital slice to the new maintained recipe instead of `no-recipe-needed`
- Corrected the final bundle/index output so unnumbered documents no longer mislabel source-page fallback as printed-page ranges

### Tested
- `python -m ruff check modules/ tests/`
- `python -m pytest tests/`
- `python driver.py --recipe configs/recipes/recipe-born-digital-pdf-non-toc-html-mvp.yaml --run-id finish-story171-flat-r1 --force`
- `python validate_artifact.py --schema doc_web_bundle_manifest_v1 --file output/runs/finish-story171-flat-r1/output/html/manifest.json`
- `python validate_artifact.py --schema doc_web_provenance_block_v1 --file output/runs/finish-story171-flat-r1/output/html/provenance/blocks.jsonl`

## [2026-03-29-01] - Close born-digital PDF routing narrowing on widened proof (Story 170)

### Added
- Added `tests/test_intake_plan_utils.py` to pin the maintained PDF recommendation boundary and refreshed the widened born-digital expectations in `benchmarks/golden/auto-book-type-detection/corpus.json`

### Changed
- Closed Story 170 on widened `driver.py` proof showing the `Marker`-lite path remains a bounded optional book-like lane while short flat PDFs now surface `no-recipe-needed`
- Updated `docs/build-map.md`, Scout 011, the eval registry, the coverage matrix, and the story records so the born-digital PDF truth surfaces reflect the widened negative result honestly

### Fixed
- Narrowed `modules/intake/intake_plan_utils.py` so flat and non-book PDFs no longer route into maintained full HTML recipes that later fail at `portionize_toc`

### Tested
- `python -m ruff check modules/ tests/`
- `python -m pytest tests/`
- `python -m pytest tests/test_extract_pdf_marker_lite_html_v1.py tests/test_pdf_intake_recipe.py tests/test_intake_plan_utils.py -q`
- `python benchmarks/scripts/run_auto_book_type_detection_eval.py --output benchmarks/results/auto-book-type-detection-story170.json`

## [2026-03-28-01] - Close maintained contact-sheet intake benchmark path (Story 169)

### Added
- Added the maintained recommendation-only intake recipe `configs/recipes/recipe-intake-contact-sheet.yaml`, the shared helper `modules/intake/intake_plan_utils.py`, and the repo-owned `auto-book-type-detection` benchmark harness under `benchmarks/`

### Changed
- Closed Story 169 on fresh `driver.py` proofs for image-directory, scanned-PDF, and born-digital-PDF intake plus a recorded first `auto-book-type-detection` score in `docs/evals/registry.yaml`
- Updated the build map, Story 027, the story index, and the legacy intake recipe so Category 1 now reflects the maintained recommendation-only intake lane rather than a legacy-only path

### Fixed
- Removed the stale legacy placeholder recipe recommendations from the overview/zoom intake chain and repaired the intake tests so they no longer depend on the missing repo-local `input/` tree

### Tested
- `make lint`
- `make test`
- `python driver.py --recipe configs/recipes/recipe-intake-contact-sheet.yaml --registry modules --run-id validate169-images --force`
- `python driver.py --recipe configs/recipes/recipe-intake-contact-sheet.yaml --registry modules --input-pdf testdata/scanned-prose-mini.pdf --run-id validate169-scanned --force`
- `python driver.py --recipe configs/recipes/recipe-intake-contact-sheet.yaml --registry modules --input-pdf testdata/tbotb-mini.pdf --run-id validate169-born --force`

## [2026-03-27-04] - Close maintained Marker-lite born-digital path (Story 168)

### Added
- Added the maintained born-digital Marker-lite extract module under `modules/extract/extract_pdf_marker_lite_html_v1/` plus shared runtime/normalization helpers in `modules/common/marker_lite_runtime.py` and `modules/common/marker_page_html.py`
- Added the explicit maintained native-text recipe `configs/recipes/recipe-born-digital-pdf-marker-lite-html-mvp.yaml` and focused regression coverage in `tests/test_extract_pdf_marker_lite_html_v1.py`

### Changed
- Closed Story 168 on fresh maintained `driver.py` proof that the bounded Marker-lite seam can run end-to-end on `testdata/tbotb-mini.pdf` while emitting accepted `doc_web_bundle` and provenance sidecars
- Updated the build map, Scout 011, and story records so `born-digital-pdf` now reflects a bounded maintained optional native-text lane rather than a prototype-only gap
- Reduced `scripts/spikes/marker_page_html_prototype.py` to a thin wrapper over the shared maintained normalization path

### Fixed
- Normalized the known Story 166 defects in the maintained Marker lane: page-2 section heading levels are now consistent and page 3's merged choice prompt is split into two blocks without text-loss signals
- Reworked the runtime transport so the maintained Marker path copies PDFs into container-local `/tmp/marker-lite-*` paths and copies outputs back out, avoiding stale cached-image `/work` bind contamination

### Tested
- `make lint`
- `make test`
- `python driver.py --recipe configs/recipes/recipe-born-digital-pdf-marker-lite-html-mvp.yaml --input-pdf testdata/tbotb-mini.pdf --run-id story168-marker-lite-proof-r4 --output-dir output/runs/story168-marker-lite-proof-r4 --allow-run-id-reuse --force`
- `python driver.py --recipe configs/recipes/recipe-pdf-ocr-html-mvp.yaml --input-pdf testdata/tbotb-mini.pdf --run-id story168-ocr-baseline-r1 --output-dir output/runs/story168-ocr-baseline-r1 --allow-run-id-reuse --force`

## [2026-03-27-03] - Close Marker internals born-digital substrate spike (Story 166)

### Added
- Added the Story 166 prototype normalizer `scripts/spikes/marker_page_html_prototype.py` plus focused regression coverage in `tests/test_marker_page_html_prototype.py`
- Added Story 168 (`docs/stories/story-168-marker-lite-maintained-born-digital-pdf-path.md`) as the exact maintained follow-on for the remaining heading and paragraph normalization work

### Changed
- Closed Story 166 on fresh repo-local proof that the Marker-lite seam can normalize into `page_html_v1` plus accepted `doc-web` bundle/provenance artifacts without crossing the maintained runtime boundary
- Updated Story 166, the story index, Scout 011, and the build map so the born-digital PDF gap now reflects the real state: bounded spike positive, maintained native-text path still pending

### Fixed
- Reworked the Marker benchmark bootstrap so the spike can rebuild from a repo-local cached image instead of depending on a stale worktree-bound Docker container
- Corrected the benchmark decision summary so the current pagelines baseline is treated as OCR-routed whenever it still falls back to OCR or escalation
- Ignored repo-local benchmark cache directories in `.gitignore` so the bootstrap does not leave untracked runtime noise

### Tested
- `python -m ruff check modules/ tests/`
- `python -m pytest tests/`
- `python scripts/spikes/marker_breadth_benchmark.py --container-name story165-marker-cpu-9f4f --bootstrap-from-container story165-marker-cpu-missing --bootstrap-image doc-web/story165-marker-cpu:9f4f --mode lite_api --formats json --out-root output/runs/story166-marker-probe-r2 --skip-run --docweb-baseline-root output/runs/story166-docweb-pagelines-baseline-r1`
- `python validate_artifact.py --schema page_html_v1 --file output/runs/story166-marker-page-html-r2/tbotb-mini/marker-v1102/lite-api/pages_html.jsonl`
- `python validate_artifact.py --schema doc_web_bundle_manifest_v1 --file output/runs/story166-marker-page-html-r2/tbotb-mini/marker-v1102/lite-api/doc_web_bundle/manifest.json`
- `python validate_artifact.py --schema doc_web_provenance_block_v1 --file output/runs/story166-marker-page-html-r2/tbotb-mini/marker-v1102/lite-api/doc_web_bundle/provenance/blocks.jsonl`

## [2026-03-27-02] - Add repo-owned scanned-prose PDF fixture proof (Story 167)

### Added
- Added the repo-owned scanned simple-prose fixture set: `testdata/scanned-prose-mini.md`, `testdata/scanned-prose-mini.pdf`, and `testdata/generate_scanned_prose_fixture.py`
- Added a maintained scanned-prose extract/provenance smoke alongside the born-digital PDF smoke in `tests/test_pdf_intake_recipe.py`

### Changed
- Updated the build map, coverage matrix, runbook, fixture docs, and story records so `scanned-pdf-prose` now has repo-owned passing evidence on the maintained generic PDF recipe
- Closed Story 167 with fresh validation evidence and synced the story index/workflow gates

### Tested
- `python -m pytest tests/test_pdf_intake_recipe.py -q`
- `python driver.py --recipe configs/recipes/recipe-pdf-ocr-html-mvp.yaml --input-pdf testdata/scanned-prose-mini.pdf --run-id story167-scanned-prose-proof --output-dir output/runs/story167-scanned-prose-proof --allow-run-id-reuse --force --end-at ocr_ai`
- `make lint`
- `make test`

## [2026-03-27-01] - Close maintained PDF intake parity and split scanned-prose fixture follow-up (Story 157)

### Added
- Added Story 167 (`docs/stories/story-167-repo-owned-scanned-prose-pdf-fixture.md`) to carry the repo-owned scanned-prose fixture gap without leaving Story 157 open-ended

### Changed
- Closed Story 157 on fresh maintained-PDF evidence, including explicit PDF recipes, PDF-aware run seeding, updated truth surfaces, and the story index/workflow-gate sync

### Fixed
- Cleared stale run-level `status_reason` after successful resume and verified the maintained Onward PDF proof run now ends cleanly
- Reduced the remaining Onward genealogy warning path to a story-scoped rerun recipe with fresh zero-warning validation output

### Tested
- `make lint`
- `make test`

## [2026-03-26-01] - Close Marker born-digital comparator and split thin-seam follow-up (Story 165)

### Added
- Added the Story 165 benchmark harness `scripts/spikes/marker_breadth_benchmark.py`, including the thinner Marker-internals `lite_api` path and the local `doc-web` baseline summary in the canonical benchmark artifact
- Added the follow-on Draft Story 166 (`docs/stories/story-166-marker-internals-born-digital-pdf-substrate.md`) to carry the narrower Marker-internals substrate question without leaving Story 165 open-ended

### Changed
- Closed Story 165 on fresh `tbotb-mini.pdf` evidence showing that stock `Marker` is too heavy for direct adoption, while the thinner Marker-internals path is promising enough to justify a scoped born-digital follow-on
- Updated Scout 011 and the build map so `Marker` is no longer tracked as a vague future comparator; it is now recorded as negative for stock adoption and positive enough for the narrow Story 166 substrate seam

### Tested
- `make lint`
- `make test`
- `make skills-check`
- `python scripts/spikes/marker_breadth_benchmark.py --mode lite_api --skip-run`
- `git diff --check`

## [2026-03-21-01] - Close Surya component benchmark on Onward seam (Story 164)

### Added
- Added the bounded Surya benchmark harness `scripts/spikes/surya_component_benchmark.py` to measure page-level layout/table detection on repo-local Onward artifacts using the pinned working Surya runtime

### Changed
- Closed Story 164 after the first honest local Surya benchmark came back negative for immediate adoption on the active Onward Marie-Louise seam
- Updated Scout 011 and the Onward build-map section so `Surya` is now tracked as benchmarked-negative on this seam instead of still queued
- Ignored story-local Surya virtualenvs via `.gitignore` so local benchmark environments no longer pollute the worktree change set

### Tested
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`
- `python scripts/spikes/surya_component_benchmark.py`
- `git diff --check`

## [2026-03-20-10] - Close Story 163 and sync external-tool tracking

### Changed
- Closed Story 163 after the widened official `Docling` plugin proof stayed negative on Leonidas and Marie-Louise, and synced the story index/workflow gates to reflect the final result
- Extended Scout 011 into the durable external-systems tracker so `Docling`, `OCRmyPDF`, `Surya`, `Marker`, and `GROBID` now carry explicit status, current read, and next-proof guidance in one place

### Tested
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`
- `git diff --check`

## [2026-03-20-09] - Widen coordinated Docling plugin reopen test (Story 163)

### Added
- Added the repo-owned `Docling` plugin packages `docling_plugins/onward_layout_plugin.py` and `docling_plugins/onward_table_structure_plugin.py` plus the widened kill-test harness `scripts/spikes/docling_onward_plugin_kill_test.py`
- Added focused plugin registration coverage in `tests/test_docling_plugin_registration.py`

### Changed
- Reopened Story 163 in-place and widened it from a single `table_structure` plugin to a coordinated `layout + table_structure` official plugin stack on current-pass evidence from `output/runs/story163-docling-plugin-killtest-r2/`
- Updated ADR-003, the Onward tuning findings, the build map, and the final synthesis so the repo now treats the broadened documented plugin path as explicitly tested and still negative on this lane

### Tested
- `make lint`
- `make test`
- `python -m pytest tests/test_docling_plugin_registration.py`
- `python -m ruff check docling_plugins scripts/spikes/docling_onward_plugin_kill_test.py tests/test_docling_plugin_registration.py`
- `.venv-story160-docling-arm64/bin/python scripts/spikes/docling_onward_plugin_kill_test.py`
- `git diff --check`

## [2026-03-20-08] - Close final Docling boundary decision on reviewed Onward slice (Story 162)

### Added
- Added the shared OpenAI vision OCR helper `modules/common/onward_openai_ocr.py` so the maintained `Docling` repair path, rerun lane, and incumbent rescue path no longer hide that ownership inside `table_rescue_onward_tables_v1`

### Changed
- Closed Story 162 on widened maintained-path evidence from `output/runs/story162-docling-maintained-r1/`, including Arthur and Pierre holding strong while Leonidas, Marie-Louise, and Antoine still miss the reviewed replacement bar in distinct ways
- Updated ADR-003, the Onward build-map candidate block, and the final synthesis so the repo now treats `doc-web` as the accepted boundary on this seam and demotes the maintained `Docling` recipe/module path to benchmark/reference status instead of a forward adoption path

### Tested
- `python -m ruff check modules/ tests/`
- `python -m pytest tests/`
- `python driver.py --recipe configs/recipes/onward-docling-hybrid-maintained.yaml --run-id story162-docling-maintained-r1 --force`
- `git diff --check`

## [2026-03-20-07] - Land maintained Docling hybrid path proof (Story 161)

### Added
- Added the maintained `Docling` hybrid recipe at `configs/recipes/onward-docling-hybrid-maintained.yaml` and the bounded repair module `modules/transform/repair_docling_onward_genealogy_v1/` so the generalized Tier 2 shape now runs through the normal `driver.py` path instead of a story-local spike script
- Added focused test coverage for the maintained repair seam in `tests/test_repair_docling_onward_genealogy_v1.py`

### Changed
- Closed Story 161 on fresh maintained-path evidence from `output/runs/story161-docling-maintained-r2/`, including Arthur parity held at `97.3 / 100` and Pierre restoration of the `JACQUELINE'S FAMILY` through `ANTONIO'S FAMILY` sequence plus descendants summary table
- Updated the Onward build-map candidate block and ADR-003 synthesis so the repo now treats `hybrid` as the measured next path on a maintained seam, while keeping `table_rescue_onward_tables_v1` and the planner/rerun stack as narrowing targets rather than claiming broad deletions yet

### Tested
- `make lint`
- `make test`
- `python driver.py --recipe configs/recipes/onward-docling-hybrid-maintained.yaml --run-id story161-docling-maintained-r2 --force`
- `python scripts/spikes/docling_onward_parity_score.py --outdir output/runs/story161-docling-arthur-parity-r1 --candidate maintained-r2=output/runs/story161-docling-maintained-r2/07_repair_docling_onward_genealogy_v1/full-candidate.html`
- `git diff --check`

## [2026-03-20-06] - Close Docling replacement evaluation and split maintained-path proof (Story 158)

### Added
- Added Story 161 to own the maintained `Docling` hybrid path proof on the Onward lane, including the simplification gate against the active workaround stack

### Changed
- Closed Story 158 on a formal `hybrid`-first recommendation backed by the pinned local pilot corpus, Story 159 tuning evidence, and Story 160 broader Tier 2 generalization results
- Updated ADR-003 and the replacement-evaluation synthesis so `doc-web` remains the incumbent boundary for now while the maintained-path proof moves into Story 161

### Tested
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`

## [2026-03-20-05] - Close Story 160 Tier 2 generalization spike (Story 160)

### Added
- Added the signal-driven `Docling` Tier 2 generalization harness in `scripts/spikes/docling_onward_hybrid_generalization.py` plus current-pass Arthur and Pierre spike evidence under `output/runs/story160-docling-generalization-r1/`

### Changed
- Closed Story 160 on fresh artifact evidence, including regenerated stock `baseline-images` baselines, Arthur parity improvement to `97.3 / 100`, and Pierre later-spill recovery to the incumbent chapter's coarse structure
- Updated ADR-003 research, synthesis, and decision notes plus the Onward build-map candidate block so the repo now treats Tier 2 generalization as proven enough to continue, with maintained-path integration as the next question

### Tested
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`

## [2026-03-20-04] - Add Docling evaluation package and close Onward tuning slice

### Added
- Added Scout 011 plus ADR-003 research scaffolding to evaluate `Docling` as a possible replacement or upstream substrate for the current `doc-web` handoff path
- Added Stories 158-160 and the supporting Docling spike scripts for local pilot runs, Onward tuning, Arthur-lane parity scoring, VLM probes, Tier 1 closure probing, and the explicit Tier 2 follow-up

### Changed
- Closed Story 159 with explicit spike-only acceptance criteria, checked workflow gates, and synced the ADR-003 and Onward tuning findings surfaces around the measured Tier 1 closure result
- Recorded that the measured next move is signal-driven Tier 2 generalization rather than more broad official-only `Docling` probing
- Corrected status drift for Stories 148 and 151, marked the `spec:7` story-coverage lane complete in the build map, indexed Scout 011, and cleared the processed inbox items

### Tested
- `python -m pytest tests/`
- `python -m ruff check modules/ tests/`

## [2026-03-20-03] - Add scanned-PDF intake parity story

### Added
- Added Story 157 to scope maintained scanned-PDF intake parity with the active image-directory runtime path, including durable PDF smoke coverage, Onward PDF validation, and documentation truth reconciliation

### Changed
- Updated the story index to track Story 157 as a pending follow-up in the active `doc-web` intake roadmap

## [2026-03-20-02] - Port Dossier and Storybook workflow upgrades

### Added
- Added the canonical `/setup-methodology` skill package, methodology reference, refresh checklist, and eval-surface docs so methodology bootstrap and refresh now live behind one documented public surface

### Changed
- Upgraded AGENTS and the story-planning skill chain to use build-map-first routing, substrate reality checks, explicit workflow gates, and fresh-verification language aligned with the current Dossier and Storybook patterns
- Upgraded `/scout` and the scout expedition template to capture auditable cross-repo pattern transfers with transfusion notes plus dedicated verification and evidence sections

### Fixed
- Rechecked the local ports against the Dossier and Storybook source repos and corrected the remaining fidelity gaps in `create-story`, `triage-stories`, `validate`, and `mark-story-done` before landing

## [2026-03-20-01] - Make doc-web consumable as a pinned Dossier component (Story 156)

### Added
- Added an installable `doc-web` package surface, runtime preflight CLI, and a repo-owned fixture-backed bundle smoke lane so Dossier can consume a narrow pinned component instead of a sibling checkout

### Changed
- Extended the live bundle builder to emit `manifest.json`, `provenance/blocks.jsonl`, stable `blk-*` anchors, and bundle reading order aligned with the published `doc-web` contract
- Updated README, runbook, handoff, readiness, and migration docs so Dossier consumers can start from the README, then follow the explicit contract and smoke instructions

### Fixed
- Tightened the clean-venv install smoke and ignored generated packaging residue so routine package validation no longer overstates dependency resolution or leave accidental build outputs in the landing set

### Tested
- `make lint`
- `make test`
- `python driver.py --recipe configs/recipes/doc-web-fixture-bundle-smoke.yaml --run-id story156-docweb-fixture-bundle-r2 --allow-run-id-reuse --force`
- `python validate_artifact.py --schema doc_web_bundle_manifest_v1 --file output/runs/story156-docweb-fixture-bundle-r2/output/html/manifest.json`
- `python validate_artifact.py --schema doc_web_provenance_block_v1 --file output/runs/story156-docweb-fixture-bundle-r2/output/html/provenance/blocks.jsonl`

## [2026-03-19-08] - Remove remaining legacy gamebook runtime seams (Story 155)

### Changed
- Removed the last live `gamebook`-specific driver branches and stale deleted-module compatibility paths so active stage wiring now follows the maintained generic intake/doc-web contract
- Generalized surviving numbered-section prompts, schema comments, and OCR helper wording away from Fighting Fantasy/gamebook framing
- Tightened the Story 155 closeout records so the cleanup inventory and retained codebase-improvement scan clearly distinguish final state from intentional historical references and superseded mid-story findings

### Removed
- Deleted dead legacy adapters `report_pipeline_issues_v1`, `context_aware_post_process_v1`, and `context_aware_t5_v1`, plus the last direct test and stale module-catalog entry that kept those surfaces looking active

### Tested
- `make lint`
- `make test`
- `python driver.py --recipe /tmp/story155-docweb-fixture/recipe.yaml --registry modules --allow-run-id-reuse --force`
- `python validate_artifact.py --schema chapter_html_manifest_v1 --file output/runs/story155-docweb-fixture-build-r2/04_build_chapter_html_v1/chapters_manifest_fixture.jsonl`

## [2026-03-19-07] - Remove legacy FF runtime and sample-book residue (Story 155)

### Changed
- Repointed `tools/run_manager.py`, current docs, the coverage matrix, and the pipeline visibility hinting logic to the maintained intake + `doc-web` path instead of retained FF defaults or sample-book references
- Rewrote `docs/requirements.md` and the live portions of `docs/document-ir.md` around the active structural HTML/runtime mission

### Removed
- Deleted the top-level and legacy FF/gamebook recipe family, the FF export/validator/edgecase module stack, and the dedicated scripts/tests/fixtures that only existed to support that retired runtime
- Deleted sample-book analysis/docs residue including `snapshot.md`, OCR bench assets, FF smoke settings, old prompts/examples, and robot/gamebook helper notes that no longer serve the repo mission

## [2026-03-19-06] - Align repo mission surfaces and quarantine legacy FF defaults (Story 155)

### Added
- Added `docs/notes/repo-mission-alignment-cleanup-inventory.md` with evidence-backed `keep` / `remove now` / `archive/reference only` / `blocked` classifications and explicit follow-up actions

### Changed
- Reframed mission and execution guidance across `README.md`, `docs/ideal.md`, `docs/stories.md`, `AGENTS.md`, `docs/RUNBOOK.md`, `docs/runbooks/check-in-worktree-landing.md`, `docs/notes/standalone-dossier-intake-runtime-plan.md`, `docs/pipeline/ff-specificity-audit.md`, `scripts/run_driver_monitored.sh`, and `tests/fixtures/formats/_coverage-matrix.json` around the active intake + `doc-web` direction
- Relabeled top-level FF recipes and `docs/examples/gamebook-example.json` as legacy/reference-only surfaces instead of active defaults

### Fixed
- Replaced the generic `make smoke` FF default with explicit guidance plus `make smoke-legacy-ff`, and removed broken `scripts/smoke-ff-engine.sh` so the repo no longer points to missing `recipe-ff-engine.yaml` surfaces

## [2026-03-19-05] - Publish Dossier doc-web semantic HTML handoff (Story 154)

### Added
- Added `docs/dossier-doc-web-handoff.md` as the Dossier-facing `doc-web` consumer contract and committed the first compatibility pack at `benchmarks/golden/onward/dossier-doc-web-handoff-v1/`

### Changed
- Extended `tests/test_doc_web_bundle_contract.py`, updated the standalone Dossier intake note, README, Story 154, and the story index so the downstream handoff and contract-test pack are explicit and discoverable

### Fixed
- Replaced machine-specific lineage text in the committed handoff-pack README with repo-portable source provenance

## [2026-03-19-04] - Close extracted doc-web bundle emitter seam (Story 153)

### Changed
- Marked Story 153 done after validation narrowed its claim to the proof actually achieved: the extracted seam enforces the frozen Story 152 bundle/provenance contract at the live `codex-forge` boundary and preserves the current maintained Onward reuse lane without new emitter-specific regression
- Updated Story 153 and the story index so the completion record now matches the maintained regression evidence instead of over-claiming broader structural health

## [2026-03-19-03] - Freeze doc-web bundle contract (Story 152)

### Added
- Added `docs/doc-web-bundle-contract.md` as the frozen v1 `doc-web` bundle and provenance contract, plus focused contract regression coverage in `tests/test_doc_web_bundle_contract.py`
- Added Story 155 to track the broader repo mission-alignment and legacy-surface cleanup follow-up discovered during Story 152 work

### Changed
- Formalized `chapter_html_manifest_v1` as a transitional validated surface and added `doc_web_bundle_manifest_v1` plus `doc_web_provenance_block_v1` to `schemas.py` and `validate_artifact.py`
- Updated the standalone extraction inventory note, README, Story 152, Story 153, Story 154, and the story index so the frozen contract is the explicit reference point for the next `doc-web` extraction and Dossier handoff work

### Fixed
- Tightened bundle-manifest validation so absolute paths, non-contiguous entry order, and navigation links that disagree with reading order now fail schema validation instead of passing silently
- Updated run-health fixture coverage to reference the actual `chapter_html_manifest_v1` schema name

## [2026-03-19-01] - Rename live project surfaces to doc-forge

### Changed
- Renamed the current project identity from `codex-forge` to `doc-forge` across live repo surfaces including core docs, agent guidance, runbooks, active stories, and helper metadata
- Normalized accepted ADR and active planning/story docs to the new name while preserving intentionally historical references in archived notes, changelog history, research artifacts, and provenance-bearing fixtures

## [2026-03-19-02] - Bootstrap doc-web runtime planning surface

### Added
- Added ADR-002 research materials, the standalone runtime extraction note, and Stories 151-154 so `doc-web` starts with the accepted boundary, contract, extraction, and Dossier-handoff planning context

### Changed
- Reframed the top-level README, spec, build map, and affected story references around `doc-web` as the structural website runtime instead of leaving those decisions implicit in copied codex-forge docs
- Marked the in-repo book website template story as out of scope and redirected downstream references toward semantic HTML plus the `doc-web` handoff contract

## [2026-03-18-05] - Reconcile fresh Onward audit lane with reviewed slice (Story 150)

### Added
- Added Story 150 investigation records for the fresh full-source Onward audit lane, including the issue log and story evidence tying Arthur genealogy drift and the chapter-003 seal crop to their actual owning seams
- Added focused regression coverage for chapter-safe genealogy merge normalization, rescue-candidate rejection on Arthur-style external-heading drift, partial-width caption trimming, and stale published-image overwrite behavior

### Changed
- Story 150 is now done after revalidating `onward-full-audit-20260318-r1` as a true source-image audit lane that preserves chapter-003 image health and keeps the reviewed genealogy slice stable without collapsing the documented trust split with the fast reuse lane

### Fixed
- `table_rescue_onward_tables_v1` no longer accepts Arthur-style rescue candidates that only improve score by exploding structured genealogy pages into more external family-heading tables
- Shared genealogy chapter merge now uses the chapter-safe rescue normalizer and drops repeated body-level genealogy header rows
- `crop_illustrations_guided_v1` no longer clips irregular mixed-width image blocks against partial-width caption boxes, and `build_chapter_html_v1` now refreshes published illustration assets on resume rebuilds so fixed crops actually reach final HTML

## [2026-03-18-03] - Land first Onward genealogy collapse and reviewed golden slice (Story 149)

### Added
- Added the shared Onward genealogy HTML stitching owner `modules/common/onward_genealogy_html.py`, the maintained regression recipe `configs/recipes/onward-genealogy-build-regression.yaml`, and a committed reviewed golden slice at `benchmarks/golden/onward/reviewed_html_slice/story149-onward-build-regression-r1/`

### Changed
- Narrowed `build_chapter_html_v1` and `rerun_onward_genealogy_consistency_v1` to reuse the shared genealogy HTML helper instead of build-private cross-imports
- Updated `docs/build-map.md`, `docs/runbooks/golden-build.md`, `docs/stories.md`, and Story 149 to record the scoped blessed run, the maintained regression path, and the run-backed golden workflow

### Fixed
- Marked the old Story 146 rerun validation recipe as historical-only now that the smaller Story 149 build/validate regression bundle is the maintained guardrail
- `load_artifact_v1` now resolves reused `output/runs/...` artifacts against the shared project output root, so the maintained Story 149 regression recipe and older reuse recipes run correctly from worktrees instead of only the main checkout

## [2026-03-18-04] - Add finish-and-push skill

### Added
- Added the `finish-and-push` skill and generated Gemini wrapper so agents can close a completed story and run the full check-in and push-to-main flow through the existing leaf skills
- Added Scout 009 documenting the cross-repo skill sync request and the dossier import decision

### Changed
- Updated `docs/scout.md` with the new cross-repo skill-sync expedition and recorded that the existing `discover-models` skill was already in sync with cine-forge

## [2026-03-18-02] - Add model discovery skill and GPT-5.4 screens

### Added
- Added the `discover-models` skill, generated Gemini wrapper, and `scripts/discover-models.py` so agents can query live OpenAI, Anthropic, and Google model inventories against the eval registry
- Added Scout 008 documenting the cine-forge import and the codex-forge-specific matcher adaptation
- Added focused GPT-5.4 Mini/Nano benchmark screen tasks for image crops and single-page Onward OCR follow-up work

### Changed
- Expanded the existing crop and single-page budget OCR benchmark configs to include GPT-5.4 Mini/Nano candidates and normalized the OpenAI provider IDs in the OCR budget task
- Updated Story 133 and Story 134 work logs with the March 18 GPT-5.4 screening evidence and the resulting non-adoption decisions
- Updated `docs/scout.md` with the new cine-forge model-skill expedition

### Fixed
- Tightened `discover-models` registry matching so human-readable eval labels resolve to canonical model families without falsely marking untested variants as already covered

## [2026-03-18-01] - Document quality-bar complexity-collapse roadmap (Story 147)

### Added
- Added a first-pass collapse-candidate inventory to `docs/build-map.md` for the stabilized Onward genealogy seam, including the evidence run, active workaround stack, candidate deletion or merge targets, proof needed before simplification, and the reusable mini-template to apply when another seam reaches the same bar

### Changed
- Marked Story 147 done in `docs/stories/story-147-quality-bar-then-complexity-collapse.md` and `docs/stories.md` after the required `/mark-story-done` validation rerun
- Replaced the stale build-map next action to "Build Story 147" with the real follow-up: create the Onward collapse implementation story from the new inventory

## [2026-03-17-01] - ADR-021 migration: dual-ideal, category spec, phase governance (Story 148)

### Added
- `docs/ideal.md` gains an Execution Ideal section describing the zero-limitation build process
- `docs/spec.md` reorganized into 9 categories (`spec:1`–`spec:9`) with hierarchical `spec:N.N` section IDs, per-category constraint blocks (C1-C7), and build-process compromise tables (B1-B10 in spec:8 and spec:9)
- `docs/build-map.md` reorganized into 9 matching categories with substrate status, phase governance (climb/hold/converge), product/tech need, and Absorbs traceability for all 8 old systems
- Triage skills (`triage-stories`, `triage-evals`, `triage`, `align`) now consume substrate readiness and phase coherence from the build map

### Changed
- 15 story files (131-148) updated with `spec:N.N` IDs in Spec Refs
- ADR-001 updated with Storybook ADR-021 cross-reference
- AGENTS.md Docs section updated with dual-ideal, unified spec, and phase governance descriptions
- Old Optimize/Eliminate dual-tracking in build-map replaced with phase governance
- Old Compromise-Level Preferences section in spec dissolved into per-category constraint blocks

## [2026-03-15-06] - Ship plan-aware genealogy reruns (Story 146)

### Added
- Added planner-aware target selection, decision reporting, and focused regression coverage to `rerun_onward_genealogy_consistency_v1`, plus the story-scoped validation recipe `configs/recipes/story-146-onward-plan-aware-genealogy-reruns-validate.yaml`
- Added the build-map operating rule to clear the quality bar first and then schedule an explicit complexity-collapse pass, with Story 147 as the first tracked follow-up for the stabilized Onward genealogy seam

### Changed
- Story 146 is now done after real reused-artifact validation run `story146-onward-plan-aware-genealogy-reruns-r1`, which consumed Story 144 planning sidecars inside the rerun loop, targeted `18` planner-selected pages across the `12` pure-format drift chapters, accepted `11/18`, and preserved `chapter-009.html` as mixed plus `chapter-023.html` as conformant
- Follow-up validation run `story146-onward-plan-aware-genealogy-reruns-r2-page112-fast` confirmed the same Story 146 seam can now repair the reviewed page-112 / `chapter-022.html` residual without OCR, leaving the deterministic validator focused on `chapter-010.html`, `chapter-016.html`, `chapter-017.html`, and `chapter-021.html`
- Focused rebuild/validate run `story146-onward-build-stitch-r3` confirmed the remaining `chapter-010.html` through `chapter-015.html` fragmentation was mostly page-break continuity, not new OCR drift: the reviewed chapters now collapse to one main genealogy table plus the totals table, and the deterministic genealogy validator reports no flagged chapters in that slice
- Follow-up focused rebuild/validate run `story146-onward-build-stitch-r5` confirmed the remaining reviewed defects were row-shape issues, not table continuity: the bad `Richard -> , 1956` death placement is corrected, the reviewed Sharon heading is no longer emitted as one concatenated row, and the reviewed subgroup rows in chapters `017/018/019/020/022` now span the full table width while the deterministic genealogy validator remains clean on the slice

### Fixed
- `rerun_onward_genealogy_consistency_v1` now consumes `pattern_inventory`, `consistency_plan`, and `conformance_report`, records pattern/rule/reason provenance in rerun reports, interleaves bounded planner targets by chapter before applying `max_pages`, and deterministically derives fallback page clusters for the old `chapter-013/014/015` empty-`relevant_pages` planner output
- The Story 146 validation loop lowered remaining pure-format issue-type count from `21` to `19`, removing `fragmented_multi_table_chapter` from `chapter-018.html` and `chapter-019.html` plus `missing_subgroup_rows` from `chapter-017.html` even though the pure-format chapter set itself did not shrink
- `table_rescue_onward_tables_v1` now rewrites malformed genealogy headers that embed family labels inside thead cells into canonical genealogy headers plus subgroup rows, which fixes the reviewed `SANDRA’S FAMILY` / page-112 header-shape defect and removes literal `BOY/GIRL` headers from the rebuilt `chapter-022.html`
- `build_chapter_html_v1` now treats direct-adjacent same-schema genealogy tables as page-break continuations when the next table still looks like genealogy content, converts heading-followed name-list tails into continuation tables before merge, keeps totals tables separate, and re-applies the merge at final write time so later carry-back stitching cannot reintroduce fragmentation
- `build_chapter_html_v1` now normalizes residual merged genealogy row defects after stitching: left-column-only heading rows become full-width subgroup rows, flattened multi-line generation-context rows are split into separate subgroup headings, and death-looking values are shifted out of the `GIRL` column into `DIED` when a padded canonical row would otherwise misplace them

## [2026-03-15-05] - Add external ingestion system eval candidates

### Added
- Added a codex-forge inbox item to evaluate promising external document-ingestion systems and components, prioritizing `Docling`, `OCRmyPDF`, `Surya`/`Marker`, and `GROBID` as potential sources of reusable intake, OCR, layout, and structured-output patterns.

## [2026-03-15-04] - Fix Onward image placement and caption fidelity (Story 135)

### Changed
- `build_chapter_html_v1` now expands OCR `data-count` image placeholders into multiple figure slots, matches crops to OCR image/caption blocks by descriptor text instead of raw order, and stitches paragraph continuations back together when figure runs interrupt a sentence within a page or across a page break
- Story 135 is now done after final validation artifacts in `story135-onward-image-placement-r2` confirmed the corrected page-12 certificate imagery alongside the earlier `r1` build-stage placement and pairing fixes

### Fixed
- Corrected the reviewed swapped image/caption pairs in the Leonidas and Pierre chapters, removed the reviewed mid-sentence figure insertions in the Leonidas, George, and Emilie chapters, and preserved the frontmatter certificate layout while keeping both page-21 and page-127 multi-image pages fully attached

## [2026-03-15-03] - Converge agent workflow around build-map tracking (Story 145)

### Added
- Added `docs/build-map.md` as the human-readable source of truth for system structure, compromise progress, input coverage, graduation criteria, and prioritized format gaps
- Added the new `align`, `triage`, and `triage-evals` skills plus their generated Gemini wrappers

### Changed
- Merged the standalone eval-verification workflow into `improve-eval` and updated AGENTS, runbooks, templates, and skill guidance to the converged command surface
- Refreshed `tests/fixtures/formats/_coverage-matrix.json` so the machine-readable coverage inventory matches current crop/provenance truth and the new build map

### Fixed
- Removed stale active references to `reflect`, standalone `verify-eval`, `docs/format-registry.md`, and missing build-map guidance from the live agent workflow surface

## [2026-03-15-02] - Accept ADR-001 consistency strategy

### Changed
- Accepted ADR-001 and finalized the project direction for document-wide consistency planning plus plan-aware selective reruns
- Settled direct HTML as the default near-term repair target, with structured intermediates reserved for evidence-driven escalation if plan-aware reruns prove insufficient
- Promoted the `25%` warning / `30%` redesign thresholds from discussion guidance to explicit operational heuristics in the ADR, and closed the remaining integration checklist items

## [2026-03-15-01] - Ship document-level genealogy consistency planning (Story 144)

### Added
- Added `plan_onward_document_consistency_v1`, a story-scoped reuse recipe, focused regression coverage, and a new runbook for document consistency planning with explicit `pattern_inventory`, `consistency_plan`, and `conformance_report` artifacts
- Added a new manual eval entry for document-level planning quality on Onward genealogy chapters

### Changed
- Story 144 is now done after corrected real-pipeline validation run `story144-onward-document-consistency-plan-r7`, which emitted inspectable planning artifacts, surfaced the previously missed manual format-failure chapters `011/012/013/014/018/019/020`, kept `chapter-009.html` out of the pure format-drift summary buckets, and restored `chapter-023.html` to conformant baseline status
- ADR-001, `docs/spec.md`, and `AGENTS.md` now treat document-local consistency artifacts as the preferred workflow boundary for adaptive normalization work instead of hidden prompt state

### Fixed
- The planner now uses a compact dossier rather than raw whole-document HTML, reads modern OpenAI `responses` output safely, lowers reasoning effort for `gpt-5`, and falls back to `gpt-4.1` when the primary planner returns empty or malformed structured output
- Row-semantic note detection no longer misclassifies ordinary death dates as note-placement problems, which keeps `chapter-009.html` in the intended row-semantic bucket without spraying false row-semantic warnings across the whole document
- Document-level conformance summaries now split pure format drift from mixed issue chapters, and the planner drops unsupported AI issue types that are not backed by dossier signals before stamping the final report

## [2026-03-14-05] - Ship Onward schema-frozen genealogy reruns (Story 143)

### Added
- Added `rerun_onward_genealogy_consistency_v1`, a story-scoped rerun validation recipe, and focused regression coverage for source-aware genealogy reruns with provenance-preserving decision reports and fallback behavior
- Added Story 144, later widened into document-level consistency planning, to track the remaining genealogy consistency follow-up after Story 143

### Changed
- Story 143 is now done after a real reused-artifact run targeted bounded coarse suspect pages `30,31,32,33,34,35,56,57,62,63,64,67,68,69`, accepted `13/14`, and reduced the final consistency report from `8` flagged chapters to `5`
- ADR-001 now records that direct HTML reruns are strong enough for most reviewed Onward genealogy pages, with mixed context/family-heading pages remaining the main representation-risk example

### Fixed
- The Onward rerun adapter now applies deterministic normalization before spending OCR budget, widens cleanly from strong pages to justified bounded adjacent pages, and rejects structurally worse candidates while preserving the original page HTML fallback

## [2026-03-14-04] - Ship Onward genealogy consistency gating (Story 142)

### Added
- Added `validate_onward_genealogy_consistency_v1`, a story-scoped validation recipe, and focused regression coverage to score chapter-level genealogy drift and narrow culprit source pages without rewriting HTML

### Changed
- Marked Story 142 Done as ADR-001's first implementation slice after a real-pipeline validation run confirmed the reviewed bad/good chapter split and measured `strong_rerun_candidate_page_coverage=0.1607`
- Updated `Makefile` to prefer the active environment Python interpreter with a `python3` fallback so `make test` and `make lint` run against the installed project environment by default

### Fixed
- Removed the stale hardcoded unreachable-section count from the FF Node-validator integration test so repo-wide pytest now checks wrapper parity against the current shared fixture instead of a drifting fixture total

## [2026-03-14-03] - Close Story 141 around consistency investigation handoff

### Added
- Drafted Story 142 as the first concrete Onward implementation slice under ADR-001, focused on consistency detection and rerun gating before any automated source-aware reruns

### Changed
- Rescoped and marked Story 141 Done around the work it actually delivered: artifact investigation, bounded AI-first baselines, and the ADR handoff into a broader source-aware consistency strategy
- Updated ADR-001 to point implementation follow-up at Story 142 instead of treating Story 141 as the future build target

## [2026-03-14-02] - Add ADR workflow support and document Story 141 direction

### Added
- Added a cross-CLI `create-adr` skill with templates, starter script, an ADR runbook, and `docs/decisions/` scaffolding so architectural decisions can be captured consistently inside codex-forge

### Changed
- Updated agent skills, generated Gemini wrappers, and `AGENTS.md` so stories, validation, inbox triage, and check-in flows explicitly consult ADRs and route decision-sized work into architecture records
- Rebuilt Story 141 as an in-progress planning artifact around a broader consistency-alignment direction instead of a narrow one-off genealogy table fix

## [2026-03-13-08] - Repair Onward chapter-level genealogy continuity after manual Alma review

### Changed
- `build_chapter_html_v1` now supports an explicit `merge_contiguous_genealogy_tables` mode so recipes can collapse contiguous same-schema genealogy tables into one final HTML table with internal subgroup rows
- The Onward recipe enables that build-stage merge, and Story 140 now records the downstream continuity fix alongside the earlier page-rescue work

### Fixed
- `chapter-009.html` in the validated run `story140-onward-targeted-rescue-r18` no longer fragments Alma genealogy data into dozens of orphaned subtables; the final output now preserves one main genealogy table plus the totals table, with subgroup labels such as `BERTHA'S FAMILY`, `NORBERT'S FAMILY`, `PAUL'S FAMILY`, and `GABRIELLE'S FAMILY` split correctly
- Alma chapter golden fidelity improved from `0.657` in `story140-onward-targeted-rescue-r13` to `0.934` in `story140-onward-targeted-rescue-r18` while preserving the previously reviewed Emilie subgroup structure in `chapter-020.html`

## [2026-03-14-01] - Restore image attachments after genealogy build merge

### Fixed
- `build_chapter_html_v1` now preserves existing `<figure>` and `<img>` attributes when applying the chapter-level genealogy merge, preventing `src` and crop metadata from being stripped out of final HTML
- Corrected validation run `story140-onward-targeted-rescue-r19` copies the illustration manifest's sibling `images/` directory, so `chapter-009.html` and `chapter-020.html` again reference real files under `output/html/images/`

## [2026-03-13-07] - Close Story 140 around targeted genealogy table rescue fidelity

### Added
- Focused rescue regression coverage for targeted Onward suspect pages and candidate-acceptance behavior
- Hand-validated Emilie/Roseanna page goldens for `089`, `097`, and `098`, plus guarded baseline-normalization coverage for split genealogy continuations

### Changed
- Story 140 marked Done around the shipped slice: recipe-scoped targeted rescue for reviewed suspect pages with bounded acceptance checks, guarded one-table normalization fallback, and real-pipeline validation
- Onward recipe now targets reviewed suspect pages `35,89,97,98` in `table_rescue_onward_tables_v1` with context-aware `gpt-4.1` retries

### Fixed
- `table_rescue_onward_tables_v1` now passes current extracted HTML/text into targeted retries and rejects structurally worse rescue candidates instead of blindly overwriting prior page HTML
- `table_rescue_onward_tables_v1` now applies deterministic same-page genealogy normalization only when it safely collapses fragmented continuation tables into a single clean table, which fixes Emilie page `98` without reopening Arthur page `35`
- Fresh validation run `story140-onward-targeted-rescue-r13` restores Arthur child rows, removes Roseanna's loose paragraph tail, and keeps Emilie's root heading plus canonical one-table continuation structure and summary counts without reopening Story 138 chapter-boundary regressions

## [2026-03-13-06] - Close Story 138 around whole-table genealogy ownership

### Changed
- Story 138 was rescoped and marked Done around the slice it actually shipped: keeping reviewed genealogy tables attached to the correct chapter as whole units, with remaining within-table rescue fidelity split to Story 140

### Fixed
- Generic stale-span chapter refinement now keeps reviewed genealogy table tails, headers, and summary rows with the owning family chapter instead of spilling them into adjacent chapters

## [2026-03-13-04] - Restore repo-wide test and lint baseline

### Changed
- Realigned driver integration and run-manager expectations with the current `output/runs/<run_id>/config.yaml` contract
- Cleared the repo-wide Ruff backlog across `modules/` and `tests/` so lint once again enforces a clean shared baseline
- Added a baseline cleanup issue log under `ai-work/issues/` to record the investigation, root causes, and verification results
- Repaired `make smoke` to run under the project Python with a stable `smoke-ff` run id and the canonical `output/` validation-report path

### Fixed
- Restored recipe `input.text_glob` handling in `driver.py` for text-ingest smoke workflows
- Allowed loader-root recipes to omit top-level input so artifact-seeded smoke and resume flows execute through `driver.py` again
- Reinstated Python fallback detection for no-choice gameplay sections in `validate_ff_engine_v2`
- Fixed relaxed choice extraction so repaired clean-text targets win over stale anchor variants during orphan repair
- Fixed combat extraction fallback inference so trigger-only loss targets no longer force an incorrect `continue` win target
- Aligned `clean_html_presentation_v1` with the FF builder's declared output schema so FF smoke recipes validate cleanly again

## [2026-03-13-03] - Triage inbox items into story and benchmark policy

### Changed
- Folded the Onward line-by-line OCR stepping-stone idea into Story 138 as a fallback experiment inside the existing genealogy-table regression work
- Added scoped fixture-variant guidance to the golden build runbook so masked or cleaned benchmark inputs stay explicit and do not redefine product requirements
- Cleared the inbox after routing both accumulated Onward items to their owning docs

## [2026-03-13-05] - Story 139 closure and shared run-registry resolution

### Added
- Shared run-registry health/assessment workflow coverage for git-worktree resolution and relative `--output-root output` CLI usage

### Changed
- Story 139 marked Done around the validated slice it actually shipped: generic chapter refinement, title ownership repair, and conservative page-break stitching
- Run-registry guidance now tells agents to rely on shared-output auto-detection from the current repo/worktree by default

### Fixed
- `tools/run_registry.py` now resolves the shared project `output/` root correctly from git worktrees instead of falling back to worktree-local registry files when the shared run already exists

## [2026-03-13-02] - Improve story closure and scope guidance

### Changed
- Updated `build-story`, `validate`, and `mark-story-done` so agents make a firm closure recommendation instead of ending in ambiguous "not done" states
- Added explicit guidance to absorb modest, tightly coupled scope deltas into the current story and present larger scope expansions for user approval
- Standardized effort guidance around relative sizing instead of human-style hour/day estimates

## [2026-03-13-01] - OCR empty-page recovery and TOC coarse boundaries (Story 137)

### Added
- Regression coverage for OCR empty-page recovery and TOC-derived coarse boundary selection

### Changed
- Story 137 rescoped and marked Done around the slice it actually shipped: generic OCR empty-page recovery plus TOC-first coarse chapter-boundary selection
- Onward recipe now prefers the existing TOC portionizer over heading-only coarse chapter splits for this TOC-bearing book

### Fixed
- Sparse nonblank OCR pages are no longer silently dropped in the reviewed Onward run
- The rebuilt Onward chapter map no longer emits a standalone `Sharon's Family` chapter from an internal heading

## [2026-03-12-04] - Layout linearization with captions and provenance (Story 009)

### Added
- Caption association: `<figure>/<figcaption>` wrapping with heuristic detection (names, dates, row labels) and OCR prompt enhancement for native `<figure>` output
- Placement provenance: `data-placement` (ocr-inline, ocr-figure) and `data-caption-source` (ocr, heuristic, crop-pipeline) on all `<figure>` elements
- Layout quality scorer (`benchmarks/scorers/layout_linearization_scorer.py`)
- 18 new unit tests for caption heuristic, caption absorption, figure handling, and sanitizer
- Stories 135 (multi-image crop detection) and 136 (pipeline stage parallelism) created from pipeline run findings

### Changed
- OCR system prompt now instructs `<figure>/<figcaption>` with semantic placement (92% caption rate on full Onward run)
- `build_chapter_html_v1` handles both old (bare `<img>`) and new (`<figure>`) OCR formats with dual-path `_attach_images`
- HTML sanitizer allows `<figure>` and `<figcaption>` tags
- Front matter pages now correctly ordered before chapters in prev/next navigation

### Fixed
- Navigation links between front matter pages and chapter 1 were broken (page-009 had no "next", chapter-001 had no "prev")

### Declined
- Stories 011, 038, 066, 111 marked Won't Do — product-level or FF-specific work that doesn't align with Ideal

## [2026-03-12-03] - Close Story 026 (Onward to the Unknown)

### Changed
- Story 026 marked Done — all 11 acceptance criteria met, 10 sub-stories spawned (9 Done, Story 130 continues independently)
- Removed stale dependency on Story 009 (layout-preserving extractor)
- Checked off sub-story tasks (Story 126 crop quality, Story 127 OCR model eval — both Done)

### Added
- Usage documentation in Story 026: run commands, output structure, key config, troubleshooting, sub-story table

## [2026-03-12-02] - Triage skills + Story 009 reframe (Scout 004)

### Added
- `/triage-inbox` skill — process inbox items against the Ideal into stories, spec updates, or discard
- `/triage-stories` skill — evaluate story backlog with mandatory Ideal alignment check, rank candidates
- Scout 004 expedition doc (`docs/scout/scout-004-dossier-triage-skills.md`)
- Gemini command wrappers for both triage skills

### Changed
- Story 009 reframed from vague "layout-preserving extractor" to "Spatial Layout Understanding for Content Linearization" — focuses on intelligent placement of images/tables/figures when linearizing complex multi-column layouts to single-column HTML
- Story 009 priority raised from Medium to High
- Scout index updated with expedition 004

## [2026-03-12-01] - OCR pipeline speed & cost optimization (Story 134)

### Added
- Image downsampling (`max_long_side` param) — Pillow LANCZOS resize before API call, 12x input token reduction
- Parallel execution (`concurrency` param) — ThreadPoolExecutor with rate limiting for concurrent API calls
- Blank page detection (`skip_blank_pages` param) — grayscale histogram skip, saved 25% of API calls on Onward
- Per-page golden references for single-page budget model eval (15 table pages)
- Two new eval configs: `onward-table-fidelity-downsampled.yaml`, `onward-table-fidelity-single-page-budget.yaml`

### Changed
- OCR module `ocr_ai_gpt51_v1`: refactored sequential loop into parallelizable `_process_one_page()` function
- Both OCR recipes: added `max_long_side: 2048`, `concurrency: 5`, `skip_blank_pages: true`
- Eval registry: added downsample validation (0.963 at 2048px) and budget model single-page results
- Pipeline performance: 3.9h → 18.3 min (12.8x), $23 → $0.69 (97% reduction), quality 0.963 (target ≥0.945)

## [2026-03-11-05] - OCR model eval refresh, new tooling, and Story 134

### Added
- `scripts/discover-models.ts` — model discovery across OpenAI/Anthropic/Google APIs with tier classification and eval registry cross-reference
- `benchmarks/scripts/enrich-eval-results.py` — cost/latency/quality enrichment for promptfoo results with MODEL_PRICING table
- Story 134 (OCR Pipeline Speed & Cost Optimization) — 7 optimization axes: downsampling, parallelism, multi-page context, batch API, model tiering, blank page skip, single-page budget model re-eval
- Gemini budget model eval configs for table fidelity testing

### Changed
- Onward recipe OCR model: `claude-sonnet-4-6` → `gemini-3.1-pro-preview` (quality winner, 0.969 score, $0.09/call vs $0.18)
- Onward recipe `max_output_tokens`: 16384 → 65536 (required for Gemini reasoning token budget)
- Eval registry: new quality winner Gemini 3.1 Pro (0.969), new value winner GPT-5.4 (0.952 at $0.11), 8 models scored with full cost/latency metrics
- `onward-table-fidelity.yaml` providers updated with GPT-5.4, Gemini 3.1 Pro, maxOutputTokens fix

### Fixed
- Gemini 3.1 Pro table fidelity: 0.115 → 0.969 after fixing maxOutputTokens (reasoning tokens were consuming output budget, truncating tables)

## [2026-03-11-04] - Begin Story 130: Book Website Template Module

### Added
- Story 130 plan with 13 tasks, exploration findings, and 8-pass browser visual testing strategy
- Extensive browser automation test plan (desktop, mobile, tablet viewports with GIF evidence)

## [2026-03-11-03] - HTML output polish and image integration (Story 129)

### Added
- HTML5 document wrapper (doctype, head, body) for all chapter and index output files
- Embedded CSS stylesheet — system font stack, responsive images, table borders/padding, max-width container, print media query
- `<nav>` with prev/next chapter links and index back-link (top + bottom of each page)
- `<figure>`/`<figcaption>` wrapping for all attached images with VLM-extracted caption text
- Rich alt text from VLM `image_description` (falls back to OCR `alt`)
- `scope="col"` and `scope="row"` on table header cells for accessibility
- Enhanced index page with book title, author, chapter list with page ranges
- `--book-title` and `--book-author` CLI params for generic book support
- `illustration_manifest` input wiring in `recipe-images-ocr-html-mvp.yaml`
- 32 pytest structural tests for HTML output quality (`tests/test_build_chapter_html.py`)

### Changed
- `_attach_img_src()` → `_attach_images()` with page-aware matching and count-mismatch warnings
- `module.yaml` updated with new params (`images_subdir`, `book_title`, `book_author`)

## [2026-03-11-02] - Gemini 3 Flash as cost-optimized crop detector (Story 133)

### Added
- `_parse_gemini_box()` and `_auto_fix_axis_swap()` in crop module — handle Gemini's native `[y,x,y,x]` coordinate format
- `benchmarks/prompts/crop-conservative-count.js` — prompt that reduces over-detection on cover/multi-element pages
- `benchmarks/tasks/image-crop-g3flash-prompts.yaml` — eval config for prompt comparison
- `tests/test_gemini_axis_swap.py` — 20 unit tests for Gemini coordinate handling
- Stylized text logos (decorative fonts, title graphics) now detected as extractable images

### Changed
- Default crop detector: `gemini-3-pro-preview` → `gemini-3-flash-preview` (5.7x cost reduction, $1.25→$0.22/book)
- `rescue_max_tokens`: 4096 → 8192 (prevents thinking token truncation on ambiguous pages)
- Eval scorer auto-normalizes Gemini native formats (scale + axis swap)

### Fixed
- Gemini array axis swap: `image_box` arrays now correctly interpreted as `[y0,x0,y1,x1]` for Gemini models
- Validator rejections on correct VLM boxes eliminated (was caused by swapped coordinates landing on wrong page regions)

## [2026-03-11-01] - Provenance envelope fixes and measurement tool (Story 132)

### Added
- `scripts/measure_provenance.py` — Measures provenance completeness across pipeline runs (4 sub-dimensions: envelope, page tracing, OCR confidence, gamebook section provenance)
- Provenance column in `docs/format-registry.md` coverage table
- Gap 2 (provenance envelope gaps) in format registry with root causes and fix plan

### Fixed
- `modules/extract/extract_pdf_images_fast_v1` — extraction_report.jsonl now carries envelope fields
- `modules/portionize/detect_boundaries_html_loop_v1` — boundary records now stamped with envelope fields
- `modules/build/build_chapter_html_v1` — manifest rows now carry all 4 envelope fields
- `modules/portionize/portionize_headings_html_v1` — portion hypothesis records now include run_id and created_at
- `modules/common/load_artifact_v1` — loaded JSONL records now stamped with current run's run_id and created_at

### Changed
- `tests/fixtures/formats/_coverage-matrix.json` — Added provenance_completeness scores for 3 passing formats
- `docs/format-registry.md` — Updated accuracy dimensions, known gaps renumbered, next actions reprioritized

## [2026-03-10-05] - Table structure fidelity 0.80→0.95, three-part model ranking, Anthropic pipeline support (Story 131)

### Added
- `benchmarks/lib/ranking.py` — Three-part model ranking (quality 60%, speed 25%, cost 15%) ported from Dossier
- `benchmarks/lib/pricing.py` — MODEL_PRICING table with cost estimation for Anthropic, OpenAI, and Google models
- `benchmarks/scripts/rank_eval_results.py` — CLI tool to extract cost/latency from promptfoo results and rank models
- `modules/common/anthropic_client.py` — AnthropicVisionClient for Claude vision API calls in pipeline modules
- `tests/test_ranking.py` — 8 tests for ranking logic
- `docs/evals/registry.yaml` — `onward-table-fidelity` eval with 5-model scores, cost/latency, and ranking

### Changed
- `benchmarks/scorers/html_table_diff.py` — Rewritten with LCS sequence alignment (eliminates cascading false errors)
- `benchmarks/prompts/onward_ocr.js` — Fixed column count, added continuation/section header rules, added Anthropic provider path
- `benchmarks/tasks/onward-table-fidelity.yaml` — 5-provider eval config (Claude Opus/Sonnet, GPT-5.1/4o, Gemini 2.5 Pro)
- `modules/extract/ocr_ai_gpt51_v1/main.py` — Added Claude model routing via AnthropicVisionClient
- `configs/recipes/recipe-onward-images-html-mvp.yaml` — OCR model switched from `gemini-3-pro-preview` to `claude-sonnet-4-6` (balanced winner)
- `docs/format-registry.md` — Structure preservation 0.80→0.95, Gap 1 resolved
- `tests/fixtures/formats/_coverage-matrix.json` — Updated scores for scanned-pdf-tables and image-directory

## [2026-03-10-04] - Format registry and gap analysis infrastructure

### Added
- `docs/format-registry.md` — Living status document tracking 16 formats, accuracy scores, gaps, graduation criteria
- `tests/fixtures/formats/_coverage-matrix.json` — Machine-readable format inventory (16 formats with scores, fixtures, pipelines)
- `tests/fixtures/golden/` — Directory for golden reference files
- `.agents/skills/format-gap-analysis/SKILL.md` — 5-phase diagnostic skill adapted from dossier's gap-analysis

### Changed
- `AGENTS.md` docs section updated with format registry references

## [2026-03-10-03] - Redefine mission as Dossier intake R&D lab

### Changed
- `docs/ideal.md` rewritten: mission is now "intake R&D lab for Dossier" — solve hard format conversion problems, graduate proven converters
- `docs/spec.md` restructured: FF-specific compromises retired, remaining compromises generalized for document processing
- `AGENTS.md` generalized (431→388 lines): removed FF-specific content, added mission statement, added "graduate don't accumulate" mandate
- Tenet T3 wording updated from "author's words" to "source content" across skills

## [2026-03-10-02] - Infrastructure cleanup and AGENTS.md tightening

### Changed
- AGENTS.md trimmed from 525 to 431 lines: removed redundant sections, tightened repo map
- AI Self-Improvement Log extracted to `docs/ai-learning-log.md`
- CHANGELOG.md normalized to CalVer `YYYY-MM-DD-NN` format across all 47 entries
- `/build-story` now sets status to In Progress in `docs/stories.md` when starting work
- `/create-story` updated to match actual `docs/stories.md` table format

### Removed
- Stale `.claude/commands/` directory (8 files) — replaced by `.agents/skills/`

## [2026-03-10-01] - Cross-project infrastructure modernization (Scout 001-003)

### Added
- `AGENTS.md` — Central Tenets (T0-T5), core mandates, subagent strategy, story lifecycle, docs index
- `CLAUDE.md` — One-liner redirect to AGENTS.md
- `docs/ideal.md` — Zero-limitation north star vision document
- `docs/spec.md` — 8 active compromises (C1-C8) with detection evals
- `docs/evals/registry.yaml` — Centralized eval registry with score history and attempt tracking (4 evals)
- 13 cross-CLI skills in `.agents/skills/`: create-story, build-story, check-in-diff, mark-story-done, improve-eval, verify-eval, scout, create-cross-cli-skill, validate, improve, fix-difficult-issue, advice-for-past-self, you-pick
- `scripts/sync-agent-skills.sh` — Cross-CLI skill sync (Claude, Cursor, Gemini)
- `.gemini/commands/*.toml` — Auto-generated Gemini CLI wrappers for all skills
- `docs/runbooks/crop-eval-workflow.md` and `docs/runbooks/golden-build.md`
- `docs/scout.md` and 3 scout expedition docs (dossier, cine-forge, storybook patterns)
- Story template with Central Tenet verification checklist (T0-T5)

### Changed
- `AGENTS.md` restructured with Ideal-First methodology, Central Tenets, and skill ecosystem
- `Makefile` expanded with test, lint, format, skills-sync, skills-check, check-size targets

## [2025-12-31-02] - Canonical sequence pipeline + Node validator alignment

### Added
- `sequence_order_v1` for deterministic sequence ordering.
- Portable Node validator bundle (`gamebook-validator.bundle.js`) and bundling script.
- Resume-build recipe and load adapter for reusing enriched portions.
- Tests covering sequence normalization, choice effects, inventory/stat/combat extraction, and stat-change dice patterns.

## [2026-01-02-02] - Combat vNext outcomes, schema updates, and special-case docs

### Added
- Combat vNext schema support (rules/modifiers/triggers/modes) with new triggers and terminal continuation outcomes.
- Resume recipes and export tools for combat section analysis.
- Integration and validator tests for combat outcomes, including section 143 split-target coverage.
- Story 111 special-case detection patterns for the edge-case scanner.

### Changed
- Combat extraction, sequence ordering, and export normalization to enforce `outcomes.win` and dedupe mechanic/choice overlaps.
- Stat changes now use `scope` instead of legacy `permanent`.
- Validator now honors `metadata.sectionCount` and enforces combat outcome presence.
- README updated with combat outcome conventions and examples.

### Fixed
- Synthetic example now matches schema (`choiceText` usage).

### Tested
- `pytest tests/test_extract_combat_v1.py tests/test_sequence_order_v1.py tests/test_build_ff_engine_sequence_normalize.py`
- `pytest tests/test_integration_combat_outcomes.py`
- `pytest tests/test_validate_combat_outcomes.py`

### Changed
- `sequence` replaces legacy navigation fields throughout build/validation outputs.
- Node validator is canonical in recipes; Python validator is forensics-only.
- Stat modification extraction handles dice-based reductions; smoke validator now checks sequence targets and STAMINA loss mentions.
- Documentation updated for validator shipping guidance and AI-assist policy.

### Tested
- `PYTHONPATH=. python -m pytest tests/test_extract_stat_modifications_v1.py`
- `python driver.py --recipe configs/recipes/recipe-ff-ai-ocr-gpt51.yaml --run-id ff-ai-ocr-gpt51-pristine-fast-full --allow-run-id-reuse --output-dir output/runs/ff-ai-ocr-gpt51-pristine-fast-full --start-from extract_stat_modifications`
- `PYTHONPATH=. python modules/validate/validate_ff_engine_node_v1/main.py --input output/runs/ff-ai-ocr-gpt51-pristine-fast-full/gamebook.json --out output/runs/ff-ai-ocr-gpt51-pristine-fast-full/gamebook_validation_node.json`
- `PYTHONPATH=. python modules/validate/validate_gamebook_smoke_v1/main.py --gamebook output/runs/ff-ai-ocr-gpt51-pristine-fast-full/gamebook.json --out output/runs/ff-ai-ocr-gpt51-pristine-fast-full/validation_report_smoke.json`

## [2025-12-30-01] - Unified navigation schema and validators

### Added
- Canonical `navigation` edges with typed kinds/outcomes in the gamebook schema.

### Changed
- Builders now emit unified `navigation` and strip mechanic target fields from items/combat/stat checks.
- Validators and smoke checks now read `navigation` only; node validator schema/types updated.
- Story 106 marked Done with work log updates and validation notes.

### Tested
- `PYTHONPATH=. python modules/validate/validate_ff_engine_v2/main.py --gamebook output/runs/ff-ai-ocr-gpt51-pristine-fast-full/gamebook.json --out output/runs/ff-ai-ocr-gpt51-pristine-fast-full/validation_report.navigation.json --expected-range-start 1 --expected-range-end 400`

## [2025-12-25-02] - Scope ARM64/MPS to legacy EasyOCR and split deps

### Added
- `requirements-legacy-easyocr.txt` for legacy EasyOCR/torch installs.

### Changed
- Default `requirements.txt` no longer includes EasyOCR/torch pins.
- ARM64/MPS guidance in `README.md` and `AGENTS.md` scoped to legacy OCR/Unstructured paths.
- `scripts/check_arm_mps.py` messaging now explicitly targets legacy EasyOCR runs.
- `constraints/metal.txt` updated to reference the legacy requirements file.
- Story 101 marked Done with work log and validation notes.

### Tested
- `python driver.py --recipe configs/recipes/recipe-ff-ai-ocr-gpt51.yaml --settings configs/settings.ff-ai-ocr-gpt51-smoke-20.yaml --run-id ff-ai-ocr-gpt51-smoke-20 --output-dir /tmp/cf-ff-ai-ocr-gpt51-smoke-20 --force`

## [2025-12-25-01] - Retired legacy OCR recipes and clarified smoke guidance

### Added
- Archived legacy OCR recipes under `configs/recipes/legacy/` with deprecation headers.
- Smoke test quick-reference sections in `README.md` and `AGENTS.md`.

### Changed
- Canonical recipe references now point to `recipe-ff-ai-ocr-gpt51.yaml` across docs/scripts/tests.
- GPT-5.1 smoke settings now drive page range via `extract_pdf_images_capped` and allow stubs for 20pp smoke.

### Fixed
- `recipe-ff-ai-ocr-gpt51.yaml` validation stage now depends on `detect_boundaries_html` (removed stale `load_boundaries`).
- Removed duplicate `params` block in `detect_endings`.

### Tested
- `python driver.py --recipe configs/recipes/recipe-ff-ai-ocr-gpt51.yaml --settings configs/settings.ff-ai-ocr-gpt51-smoke-20.yaml --run-id ff-ai-ocr-gpt51-smoke-20 --output-dir /tmp/cf-ff-ai-ocr-gpt51-smoke-20 --force`

## [2025-12-23-01] - Large-image OCR cost tuning + pristine parity scaffolding

### Added
- Line-height driven PDF render stage (`extract_pdf_images_capped_v1`) and manifest-based split stage (`split_pages_from_manifest_v1`).
- OCR x-height sweep utility (`scripts/ocr_bench_xheight_sweep.py`) and pristine DPI benchmark artifacts.
- New stories for pristine-book parity and run-summary UX (089, 090).

### Changed
- GPT‑5.1 recipe now renders via capped extractor + manifest split with `target_line_height: 24`.
- Table-rescue smoke settings updated to run through the new extractor stage.
- Story 082 marked Done; story index updated to include new parity/summary stories.

### Fixed
- `table_rescue_html_v1` now resolves output paths correctly when `--out` contains a path.

### Tested
- Deep smoke run through `html_repair_loop` on a single page.

## [2025-12-18-03] - Boundary ordering guard + targeted escalation

### Added
- Ordering/span guard and sidecar report for code-first boundary detection (`detect_boundaries_code_first_v1`).
- Targeted ordering-page escalation with cached vision overlays and repair path.
- Optional extraction overrides using escalation cache and sequence-based span ordering in `portionize_ai_extract_v1`.
- Regression tests for ordering conflicts and span issues (`tests/test_boundary_ordering_guard.py`).
- Story 078 closure and Story 080 (central escalation cache) documentation.
- Macro section tagging support across boundaries/portions and provenance (`macro_section` fields + helper).

### Changed
- Canonical FF recipe now includes ordering/span guard knobs and `span_order: sequence`.
- Story index updated to mark Story 078 done and insert Story 080 in recommended order.
- Canonical FF recipe now wires coarse segments into fallback boundary scan/merge for macro tagging.
- Story 035 marked done with recorded deferred items.

### Tested
- `pytest -q tests/test_boundary_ordering_guard.py`

## [2025-12-22-02] - HTML-first pipeline hardening and OCR bench artifacts

### Added
- GPT-5.1 HTML-first pipeline enhancements: background section support and HTML-only sections in final gamebook.
- OCR benchmark tooling for pristine downsampled comparisons and HTML/text diff artifacts.
- Stories 082–087 to track cost optimization, validation, and legacy recipe retirement.

### Changed
- Gamebook smoke validation now requires `metadata.startSection` and allows background sections.
- Build/export modules support dropping text and provenance text (HTML is source of truth).
- Choice repair and extraction now derive text from HTML where appropriate.

## [2025-12-22-01] - Table rescue OCR pipeline stage

### Added
- `table_rescue_html_v1` module to detect collapsed tables and re-read targeted crops with GPT-5.1.
- Table-rescue smoke settings (`configs/settings.ff-ai-ocr-gpt51-table-rescue-smoke.yaml`).
- Story 088 for choice parsing enhancements.

### Changed
- GPT-5.1 recipe now runs `table_rescue_html_v1` before HTML block extraction and boundary detection.
- Story 085 marked Done with detailed validation logs.

## [2025-12-12-01] - GPU “pit of success” for EasyOCR on Apple Silicon

### Added
- DocLayNet-style content tagging stage (`elements_content_type_v1`) and canonical FF recipe wiring to produce/use `elements_core_typed.jsonl` (Story 062).
- Content-type validation fixtures and tests (`tests/fixtures/elements_core_content_types_rubric_v1.jsonl`, `tests/test_elements_content_type_v1.py`) to prevent silent regressions.
- Metal-friendly constraints file (`constraints/metal.txt`) and GPU regression helper (`scripts/regression/check_easyocr_gpu.py`) plus one-shot smoke runner (`scripts/smoke_easyocr_gpu.sh`).
- EasyOCR coverage guard warning when MPS is unavailable, keeping runs explicit about CPU fallback.
- Canonical FF recipe now includes `easyocr_guard_v1` (min coverage 0.95) to fail fast if EasyOCR stops contributing.
- macOS Apple Vision OCR engine (`extract_ocr_apple_v1`) and optional `apple` engine support in the OCR ensemble, with graceful non‑macOS no‑op and error artifacts.
- OCR ensemble 3-engine fusion (tesseract/easyocr/apple) with majority voting and confidence-aware tie-breaking (Story 063).
- Tesseract word-data extraction helper for confidence auditing (`modules.common.ocr.run_ocr_with_word_data`).

### Changed
- OCR ensemble now emits/propagates per-line bboxes (tesseract best-effort; apple when available), preserving bbox/meta through merge + reconstruction for geometry-aware tagging.
- Story 062 marked Done; story 059 updated to treat content-type tags as a first-class section-detection signal.
- EasyOCR warmup and run defaults now force MPS when present; docs (README.md, AGENTS.md) updated to make `pip install ... -c constraints/metal.txt` the default bootstrap and to include GPU smoke + check commands.
- Story 067 marked done; README/AGENTS include MPS troubleshooting and smoke guidance.
- OCR ensemble now records Apple helper build/run failures in `apple_errors.jsonl` and continues without Apple rather than silently dropping pages.
- OCR ensemble histogram now reports spread-aware totals and engine coverage stats for EasyOCR/Apple presence.
- Story 052 evaluation checklist updated to reflect completed Apple OCR adoption (see Story 064).
- Story index and open stories consolidated/re‑sequenced: merged Story 036 → 035, Story 051 → 058, refreshed Story 063 checklist, clarified dependencies (066→035, 026→009), and rebuilt Recommended Order around “OCR‑first, FF‑first”.

### Fixed
- Content-type heuristics: avoid mislabeling page-range markers as titles; avoid mislabeling noisy `=` form lines as titles; whitelist `key_value` extraction by default.
- Progress event schema now supports status `warning` without overwriting stage lifecycle status in `pipeline_state.json`.
- Apple Vision OCR ROI clamp to avoid Vision Code=14 errors on column ROIs; spread-aware filtering prevents Apple text from being incorrectly excluded as an outlier.
- Inline vision escalation now records per-call usage and refuses to overwrite OCR output on refusal responses (provenance recorded instead).
- Test suite regression fixes: snapshot/manifest integration tests align with driver run-id reuse behavior; FF20 regression guards handle reused `output/` baseline dirs; `section_target_guard_v1` missing imports fixed.

### Tested
- `python -m pytest -q tests/test_elements_content_type_v1.py tests/test_reconstruct_text_bbox.py`
- `python driver.py --recipe configs/recipes/recipe-ff-canonical.yaml --settings configs/settings.story062-deathtrap-20-content-types.yaml --end-at content_types --force`
- 5-page EasyOCR-only GPU smoke via `scripts/smoke_easyocr_gpu.sh` (intake only, MPS gpu:true, timing summary).
- Apple Vision OCR smoke on `testdata/tbotb-mini.pdf` page 1; ensemble baseline vs Apple on Deathtrap Dungeon pages 1–40 with artifact inspection.
- `PYTHONPATH=. pytest -q modules/common/tests/test_progress_logger_warning.py`
- `python -m pytest -q` (96 passed, 3 skipped).

## [2025-12-10-01] - FF20 regression suite and quality guards

### Added
- 20-page Fighting Fantasy regression test suite (`tests/test_ff_20_page_regression.py`) with goldens in `testdata/ff-20-pages/`, covering counts, schemas, per-page hashes, fragmentation, column layouts, forbidden OCR tokens, choice counts, and long-line guards.
- Fast local runner `scripts/tests/run_ff20_regression_fast.sh` with a 300s runtime budget.

### Changed
- `validate_artifact.py` now validates `element_core_v1`.
- Removed obsolete portionization integration cases referencing deleted modules; legacy driver/plan tests now pass cleanly alongside the new regression suite.
- Regression drift diagnostics now surface the first differing line on mismatch for easier debugging.

### Tested
- `python -m unittest discover -s tests -p '*test.py' -v`
- `scripts/tests/run_ff20_regression_fast.sh`

## [2025-12-18-02] - Story 074: 100% section-id coverage + monitored runs

### Added
- Monitored driver run helpers (`scripts/run_driver_monitored.sh`, `scripts/monitor_run.sh`) to avoid “silent crash” long runs; docs updated to prefer these over manual tailing.
- Pytest bootstrap `conftest.py` so tests can import `modules.*` without requiring `PYTHONPATH=.`.
- `section_boundary_v1` schema mapping in `validate_artifact.py`.

### Changed
- Canonical FF recipe wires `coarse_segment` into boundary detection and raises `target_coverage` to 1.0.
- Story index + Story 074 marked Done; Story 074 docs updated with full-run evidence and sections-only scope.

### Fixed
- Boundary detection vision escalation now reliably runs and anchors missing sections (e.g., 48/80) by fixing image-dir resolution, gpt-5 API params, and duplicate/sequence validation.
- `portionize_ai_extract_v1` now uses split page ids (e.g., `080L/080R`) when available to avoid overlapping boundaries and to attach correct `source_images`.
- Driver/module compatibility: improved flag/path wiring for `coarse_segment_merge_v1`, `repair_candidates_v1`, `extract_choices_v1`, and `validate_choice_completeness_v1`.
- `build_ff_engine_v1` now filters stub targets to expected range and permits stubs only when explicitly allowlisted as missing-from-source.

### Tested
- `pytest -q` (171 passed, 3 skipped)

## [2025-12-01-01] - OCR ensemble retries, resolver, and fuzzy headers

### Added
- Pagelines-first recipes with GPT-4V escalation and missing-header resolver (`recipe-pagelines-two-pass.yaml`, `recipe-pagelines-to-gamebook.yaml`, `recipe-ocr-ensemble-gpt4v.yaml`).
- Missing-header resolver adapter with env-overridable params and logging; PageLines schema and validation support.
- Unit tests for fuzzy numeric headers and resolver dry-run; local smoke script to assert only 169–170 are missing.
- Pipeline doc for OCR/resolver env overrides (`docs/pipeline/ocr_ensemble.md`); Story 038 noted in stories index.

### Fixed/Changed
- Numeric header detector now defaults to fused/fuzzy matching; pagelines two-pass recipe rewrites headers after optional escalation.
- Module catalog expanded with OCR ensemble, resolver, and intake modules; Story 037 marked Done with source-integrity notes.

### Tested
- `python driver.py --recipe configs/recipes/recipe-pagelines-two-pass.yaml`
- `PYTHONPATH=. python tests/test_headers_numeric_fuzzy.py`
- `PYTHONPATH=. python tests/test_missing_header_resolver.py`

## [2025-11-27-01] - Intake dashboard fixes and reuse guidance

### Added
- AGENTS guide now reminds agents to reuse existing working patterns before inventing new solutions.

### Fixed/Changed
- Pipeline visibility Artifacts card now uses the same in-browser viewer as stage buttons for Final JSON and styles both input/final links as buttons; input link now adapts to pdf/images/text inputs instead of showing “Input PDF unknown.”

### Tested
- Manual dashboard reload and artifact open on intake runs (`intake-onward`, `intake-deathtrap`).

## [2025-11-26-02] - Dashboard stage help, metrics, and artifact links

### Added
- Pipeline visibility dashboard now shows per-stage help tooltips sourced from module notes and recipe descriptions; module notes rewritten verb-first for AI/human clarity.
- Artifacts summary card links directly to input PDF and detected final JSON output; stage ordering follows execution.
- New story 025 (module pruning & registry hygiene) added to track module audit.

### Fixed/Changed
- Load Metrics no longer errors; renders confidence stats with sample preview. Artifacts open with pretty-printed JSON in pane/new-tab, and anchor links render correctly.
- Run dropdown auto-sorts newest-first; dashboard filters to meaningful stage cards.

### Tested
- `python -m pytest tests/test_pipeline_visibility_path.py tests/progress_logger_test.py`
- `python driver.py --recipe /tmp/recipe-ocr-1-5.yaml --mock --instrument`
- `python driver.py --recipe /tmp/recipe-ocr-6-10.yaml --mock --instrument`

## [2025-11-25-01] - Stage elapsed UX and resumable long runs

### Added
- Pipeline visibility dashboard now shows per-stage elapsed time (live for running, final for done) using progress/event timestamps with `<1s` handling and fallbacks.
- Driver supports `--start-from/--end-at` to resume or bound runs while reusing cached artifacts.

### Fixed/Changed
- Removed remaining `sys.path` bootstraps and unused imports in module mains; all shared helpers imported from `modules.common.*`.
- Resume example and runtime note for long OCR runs added to README; story 020 marked done.

### Tested
- `python driver.py --recipe configs/recipes/recipe-text.yaml --mock --force`
- `python driver.py --recipe configs/recipes/recipe-ocr.yaml --skip-done --start-from portionize_fine --force`

## [2025-11-21-03] - Pluginized modules and validated pipelines

### Added
- Moved all pipeline modules into self-contained plugin folders under `modules/<stage>/<module_id>/` with `module.yaml` manifests.
- Updated driver to scan plugin folders, merge defaults, and run modules from their encapsulated paths.
- Added stories 016–018 to track DAG/schema, module UX, and enrichment/alt modules.

### Tested
- `python driver.py --recipe configs/recipes/recipe-text.yaml --force` (passes; stamps/validates).
- `python driver.py --recipe configs/recipes/recipe-ff-canonical.yaml --skip-done` (passes; stamps/validates) — replaces legacy 20-page OCR smoke.

## [2025-11-21-02] - Legacy cleanup and DAG-style recipes

### Changed
- Removed legacy `run_pipeline.py`, `llm_clean.py`, and `validate.py` now that plugins/driver supersede them.
- Converted core recipes to DAG-style ids/needs/inputs so driver runs without legacy assumptions.
- README now points to modular driver only (legacy quickstart removed).

### Tested
- `python driver.py --recipe configs/recipes/recipe-text.yaml --force`
- `python driver.py --recipe configs/recipes/recipe-ff-canonical.yaml --force`

## [2025-11-21-01] - Added modular pipeline story

### Added
- New story 015 document outlining modular pipeline and registry plan.
- Indexed story 015 in `docs/stories.md` to track status.
- Scaffolded `modules/registry.yaml`, sample recipes under `configs/recipes/`, `extract_text.py` stub, and `validate_artifact.py` validator CLI.
- Added pipeline driver with stamping/validation hooks and resume/skip toggles; added schemas for page/clean/resolved/enriched artifacts.
- Reorganized modules into per-module plugin folders with manifests; driver now scans `modules/` for entrypoints.
## [2025-11-22-05] - DAG driver, adapter merge, and CI tests

### Added
- DAG-capable driver plan/validation with schema-aware resume checks and adapter stage support.
- `merge_portion_hyp_v1` adapter module plus DAG recipes (`recipe-text-dag.yaml`) using coarse+fine portionize branches. (`recipe-ocr-dag.yaml` deprecated in favor of `recipe-ff-canonical.yaml`.)
- GitHub Actions workflow `tests.yml` running driver unit tests; README badge and DAG usage notes.

### Fixed/Changed
- Portionize fine params cleaned up (removed unsupported `min_conf`), OCR recipe simplified (no `images` flag, end page capped).
- Resume skips now verify artifact schema_version; multi-input consensus uses deduped merge helper.

## [2025-11-22-04] - Pipeline visibility dashboard & progress logging

### Added
- Progress event schema validation and append-only logger with tests; driver/module commands now inject `--state-file/--progress-file/--run-id` by default.
- Dashboard fixture run (`output/runs/dashboard-fixture`) plus README note on serving `docs/pipeline-visibility.html` via `python -m http.server`.
- New dashboard UI features: run selector, auto-refresh, stage cards, event timeline, artifact pane/new-tab viewer, metrics loader.

### Changed
- Story 019 marked complete; follow-on UI polish tracked in new Story 021 (highlighting/pane sizing).
- `docs/stories.md` updated with Story 021; story log entries added for work performed.

### Tested
- `python -m pytest tests/progress_logger_test.py`
- `python -m pytest tests/driver_plan_test.py`

### Tested
- `python -m unittest discover -s tests -p 'driver_*test.py'` (passes; 9 tests).
- `python driver.py --recipe configs/recipes/recipe-text-dag.yaml --force` (passes; artifacts stamped/validated).
- `python driver.py --recipe configs/recipes/recipe-ff-canonical.yaml --skip-done` (passes; OCR pages 1–20 end-to-end).

## [2025-11-22-03] - Shared common package and module import cleanup

### Added
- Introduced `modules/common` package consolidating shared helpers (utils, ocr) with explicit public surface.
- Driver now executes module entrypoints via `python -m modules.<...>.main`, enabling package-relative imports without sys.path tweaks.

### Fixed/Changed
- All module mains import from `modules.common.*` and no longer mutate `sys.path`.
- Driver skips None-valued params when building CLI flags to avoid invalid arguments.
- Documentation updated (AGENTS, README, story log) to reflect common package usage.

### Tested
- `python -m compileall modules/common driver.py validate_artifact.py`
- `python driver.py --recipe configs/recipes/recipe-text.yaml --mock --force`
- `python driver.py --recipe configs/recipes/recipe-ocr.yaml --mock --force`

## [2025-11-22-02] - Param schemas and stage output overrides

### Added
- JSON-Schema-lite `param_schema` support in `driver.py` with fail-fast validation (type/enum/range/pattern, required/unknown detection, schema defaults).
- Stage-level `out:` override for artifact filenames (higher precedence than recipe `outputs:`) wired through resume/skip-done.
- `param_schema` definitions added to key modules (OCR/text extract, clean, portionize, adapter merge, consensus vote).
- `param_schema` placeholders added for dedupe/normalize/resolve/build to block typos and allow future tunables.
- Added doc snippets for `out:` usage and a multi-stage custom-output smoke test verifying downstream propagation.

### Tested
- `python -m pytest tests/driver_plan_test.py tests/driver_integration_test.py` (13 total; includes param validation errors, out precedence, resume honors custom out, multi-stage custom outputs).

## [2025-11-22-01] - Enrichment stage + alternate modules

### Added
- Enrichment module `enrich_struct_v1` producing `enriched_portion_v1`; low-cost deterministic portionizer `portionize_page_v1`; greedy gap-fill consensus `consensus_spanfill_v1`.
- New recipes showcasing swapability and enrichment: `configs/recipes/recipe-text-enrich-alt.yaml` (text ingest) and `configs/recipes/recipe-ocr-enrich-alt.yaml` (OCR, pages 1–2).
- Driver enrich stage wiring (pages/portions inputs) and `cleanup_artifact` helper to remove stale outputs on `--force`.

### Fixed
- `stamp_artifact` now backfills `module_id`, `run_id`, and `created_at` when missing.

### Tested
- `python driver.py --recipe configs/recipes/recipe-text-enrich-alt.yaml --registry modules` (passes; enriched output with choices).
- `python driver.py --recipe configs/recipes/recipe-ocr-enrich-alt.yaml --registry modules` (passes; intro pages enriched with images).
- `python -m pytest tests/driver_plan_test.py` (11 tests, includes stamp backfill and cleanup helpers; existing pydantic warning).
## [2025-11-23-03] - Section target guard, portionizer fixes, doc cleanup

### Added
- Consolidated adapter `section_target_guard_v1` (maps targets, backfills, coverage report/exit) with module manifest and unit tests.
- Story 099 to track removal of the dev-only backcompat disclaimer when production-ready.

### Changed
- Updated section recipes to use the guard adapter and emit coverage reports; legacy map/backfill path marked obsolete in docs.
- Portionizer `portionize_sections_v1` now captures multi-number headers/inline ids and dedupes per page to reduce duplicate portions while keeping coverage.
- AGENTS and story logs refreshed to reflect guard as the canonical path; legacy mentions updated.

### Tested
- `python driver.py --recipe configs/recipes/recipe-ocr-enrich-sections-noconsensus.yaml --force` (0 missing targets; guard passes, 400 sections/384 targets).
- `python -m pytest` (all suites; existing pydantic deprecation warning only).

## [2025-11-23-02] - Section coverage pipeline and validator guard

### Added
- No-consensus section recipe `configs/recipes/recipe-ocr-enrich-sections-noconsensus.yaml` (full book) plus chunked variants; full run produced `portions_enriched_backfill.jsonl` with zero missing targets.
- Validation guard module `modules/validate/assert_section_targets_v1.py` and unit test `tests/assert_section_targets_test.py` covering pass/fail paths.
- Story 023 to consolidate section target adapters; Story 006 marked Done in story index.
- Story 007 marked Done (turn-to validation delivered via section target guard/reporting tools).

### Changed
- Pruned obsolete/failed recipe variants to reduce config clutter.
- AGENTS safe command updated with section target validation usage.
- Story index now marks pipeline visibility (019) and enrichment (006) as Done.

### Tested
- `python driver.py --recipe configs/recipes/recipe-ocr-enrich-sections-noconsensus.yaml --registry modules --force` (full run, 0 missing targets).
- `pytest tests/assert_section_targets_test.py`

## [2025-11-23-01] - Instrumentation & dashboard surfacing

### Added
- Instrumentation schemas (`instrumentation_call_v1`, `_stage_v1`, `_run_v1`) and validation hook in `validate_artifact.py`.
- Driver `--instrument`/`--price-table` flags with per-stage wall/CPU timing, sink-based LLM usage aggregation, cost estimation via `configs/pricing.default.yaml`, and reports (`instrumentation.json` + markdown).
- Module helper `log_llm_usage` for modules to append per-call token/model data to the driver-provided sink.
- Dashboard now shows instrumentation summaries (run totals, top models, per-stage cost/time chips) and newest-first run ordering/auto-select logic.

### Changed
- Story 022 marked Done; README updated with instrumentation enablement notes.

### Tested
- `python -m pytest -q tests/test_instrumentation_schema.py`
- `python driver.py --recipe configs/recipes/recipe-text.yaml --instrument --mock --force`

## [2025-11-24-04] - Coarse+fine merge, continuation propagation, and smoke/regression

### Added
- Coarse portionizer module `portionize_coarse_v1` and merge adapter `merge_coarse_fine_v1` with continuation-aware heuristics and duplicate-span collapse.
- Smoke recipe `configs/recipes/recipe-ocr-coarse-fine-smoke.yaml` for 10-page coarse+fine validation.
- Regression helper `scripts/regression/check_continuation_propagation.py` to ensure continuation metadata survives to locked/resolved outputs.
- Unit tests for merge heuristics `tests/test_merge_coarse_fine_v1.py`.

### Changed
- DAG recipes now use the new coarse/merge modules; uncovered threshold tightened to 0.5 to reduce noise.
- Schemas plus consensus/resolve/build stages now preserve `continuation_of`/`continuation_confidence` through final artifacts.
- README and story notes updated with merge rules, smoke recipe, and regression command.
## [2025-11-24-03] - Image cropper baseline & GT

### Added
- `image_crop_v1` schema and validation mapping; contour-based cropper module `modules/extract/image_crop_cv_v1` with tuned defaults (min_area_ratio=0.005, max_area_ratio=0.99, blur=3, topk=5).
- Sample recipe `configs/recipes/recipe-image-crop.yaml`; helper scripts `scripts/annotate_gt.py` (GT/overlays) and `scripts/build_ft_vision_boxes.py` (vision FT data prep).
- 12-page GT set with overlays in `configs/groundtruth/` and `output/overlays-ft/`; follow-up story doc `story-024-image-cropper-followup.md`.
- Manual validation script `scripts/tests/test_image_crop_cv.sh` and README section documenting how to run/validate the cropper.

### Changed
- Tuned CV detector parameters and documented manual validation results (Micro P=0.75 / R=0.95 / F1=0.84 on current GT); story-008 marked Done.

## [2025-11-24-02] - Driver snapshots & manifest links

### Added
- Driver now snapshots recipe, resolved plan, registry subset, optional settings/pricing, and instrumentation config into `snapshots/` per run, recording relative paths in `output/run_manifest.jsonl`.
- Integration tests cover snapshot creation, settings relpaths for out-of-repo runs, and pricing/instrumentation snapshot capture.
- README now documents snapshot bundle contents for reproducibility.

### Changed
- Snapshot/manifest side effects are skipped on `--dump-plan`; run directory creation deferred until execution.

### Tested
- `python -m pytest` (all suites; 34 passed, pre-existing pydantic warning).
## [2025-11-24-01] - Cost/perf benchmarks, presets, and instrumentation UX

### Added
- Bench harness writes per-session `bench_metrics.csv/jsonl` and `metadata.json` under `output/runs/bench-*`; presets in `configs/presets/` (speed text, cost OCR, balanced OCR, quality OCR) with usage examples in README.
- Story 013 completed with benchmark summary tables (OCR vs text, gpt-4.1-mini/4.1/5) and work log updates.
- Dashboard regression test for nested run paths (`tests/test_pipeline_visibility_path.py`); stage cards now always show cost chips (tooltip on zero-cost stages).

### Fixed
- Dashboard run loader honors manifest path for nested run dirs; zero-cost stages now display cost chips with explanatory tooltip.
- LLM modules (clean, portionize coarse/sliding, enrich) emit instrumentation events even when usage tokens missing (zero-fill), preventing missing stage cost data.

### Documentation
- README documents presets, benchmark artifact locations, and cost/perf usage examples.
## [2025-11-26-01] - Module registry prune (story 025)

### Removed
- Deleted unused modules: portionize_numbered_v1, merge_portion_hyp_v1, image_crop_cv_v1, portionize_page_v1, consensus_spanfill_v1, enrich_struct_v1, build_appdata_v1.
- Removed legacy/demo recipes relying on those modules: recipe-image-crop.yaml, recipe-ocr-enrich-{alt,app}.yaml, recipe-text-enrich-{alt,app}.yaml.

### Planned follow-ups
- Tag remaining experimental modules (section stack, coarse/merge) in manifests and rerun OCR/text smoke recipes.
## [2025-11-28-02] - FF output refinement paused, AI guardrails noted

### Added
- Issue 0 analysis updated with guidance to avoid overcoding and to use AI ensemble/arbiter patterns for high-stakes steps.
- Work log captured mock-free recomposition run findings (`deathtrap-ff-engine-nomock`) isolating remaining portionization/enrichment failures.

### Changed
- Story 031 status set to Paused pending planned intake/architecture overhaul (potential Unstructured adoption); guardrail implementation deferred until new direction is chosen.

### Tested
- Not run (story paused; analysis/documentation only).

## [2025-11-28-01] - Fighting Fantasy Engine export complete

### Added
- Official FF Engine validator bundled with Ajv and wrapped as `validate_ff_engine_node_v1`; recipe `recipe-ff-engine.yaml` builds and validates `gamebook.json`.
- Heuristic section typing/front-matter cues in `build_ff_engine_v1` plus provenance stub reporting; stub targets recorded in output metadata.
- Manual smoke script `scripts/smoke-ff-engine.sh` to run mock build+validate locally.

### Fixed/Changed
- Dashboard final-artifact selection now prefers `build_ff_engine` over validate stages and sorts cards by actual timestamps; stage meta display no longer shows placeholder counts.
- `section_enrich_v1` consumes `resolved_portion_v1` to align with the FF pipeline; recipe wires enrich → build → validate.

### Tested
- Mock smoke: `bash scripts/smoke-ff-engine.sh` (passes official validator).
- Full run: `python driver.py --recipe configs/recipes/recipe-ff-engine.yaml --instrument --start-from portionize_fine` (passes official validator; reachability warnings only due to stubbed targets).
## [2025-11-30-01] - FF cleanup/backfill modules and OCR recovery planning

### Added
- New cleaning module `strip_section_numbers_v1` to remove section/page numbers, gibberish lines, and null `created_at` while preserving paragraphs.
- Backfill adapters `backfill_missing_sections_v2` (digit/fuzzy hits) and `backfill_missing_sections_llm_v1` (gap-based LLM) plus registration in `module_catalog`.
- Story 036 (FF OCR Recovery & Text Repair) and story 037 (FF OCR Ensemble with BetterOCR) to track remaining OCR/header repair work; updated stories index accordingly.
- Recipe `recipe-ff-redesign-v2-clean.yaml` wiring cleanup stage after extraction (experimental baseline).

### Fixed/Changed
- `portionize_ai_extract_v1` now writes enriched portions with `exclude_none=True`, dropping null `created_at` fields.
- AGENTS guide reminds agents to ship new behavior as a separate module and baseline before merging.

### Tested
- Manual runs: backfill + LLM gap backfill + cleanup on `ff-redesign-v2-improved` artifacts; validation shows 382 sections (18 missing) as current best baseline.

## [2025-12-18-01] - Spell-weighted OCR voting + downstream choice tolerance

### Added
- Per-engine spell-quality metrics (`dictionary_score`, `char_confusion_score`, etc.) and spell-weighted voting plumbing in `extract_ocr_ensemble_v1`, including conservative tie-breaking + navigation-phrase repair telemetry.
- `tests/test_spell_weighted_voting.py` & `tests/test_extract_choices_tolerant.py` to guard the new behaviors.
- Canonical FF smoke settings (`settings.ff-canonical-smoke-choices-20*.yaml`) to run through `extract_choices_v1`.
- Documentation updates: AGENTS/README (reusability goal), FF-specificity audit, story 072 work log, new story 075 for downstream booktype cleanup.

### Changed
- `extract_choices_v1` now tolerates OCR variants (`tum`, `t0/tO`, digit confusions) so downstream extraction no longer depends on OCR rewrites.
- OCR navigation phrase repair is opt-in via `enable_navigation_phrase_repair` (default off) to keep the intake generic.
- `coarse_segment_merge_v1` now normalizes page identifiers like `012L` before merging.

### Testing
- `pytest -q tests/test_spell_weighted_voting.py tests/test_extract_choices_tolerant.py`
- 20-page smoke runs with/without navigation repair that reach `extract_choices_v1` and validate all “turn to” references; telemetry recorded per run.
## [2025-12-02-01] - Header/choice loops & pipeline hardening

### Added
- Header and choice loop runner modules to iterate detect→validate→escalate until clean; recipe `recipe-pagelines-repair-choices-r6.yaml` now runs the loops automatically.
- Presence-aware header coverage guard with per-ID debug bundles and hash guard in `missing_header_resolver_v1` to prevent stale OCR.
- BACKGROUND→1 rule in choice escalator and end_game propagation through build/validator; choice coverage emits text snippets for misses.
- New stories: 050 (ending verification), 051 (text-quality loop), 052 (Apple OCR evaluation), 053 (smoke test with mocked APIs).

### Fixed/Changed
- Numeric-only lines preserved in cleaning; header detector more tolerant; portion dedupe keeps best occurrence per section.
- Choice loop output normalized to JSONL for driver stamping; build/validate accept driver compatibility args.
- Story 036 marked Done; deferred text-quality/debug work consolidated into Story 051; smoke test work tracked in Story 053.

### Tested
- `python driver.py --recipe configs/recipes/recipe-pagelines-repair-choices-r6.yaml`
## [2025-12-13-01] - Story 058 post-OCR quality finalized

### Added
- `context_aware_post_process_v1` and `context_aware_t5_v1` adapters for post-OCR smoothing plus section-number/truncation validators to capture remaining warnings.
- Regression helper `scripts/regression/update_repair_table.py` that rebuilds `repair_table.md` and reruns `scripts/regression/check_suspicious_tokens.py` per smoke run; canonical 20-page run artifacts now include the regenerated table and validator outputs.
- AGENTS guidance about generality/impact reporting and the rebuild/verifications, plus new story log entries documenting the repair loop and validator rationale.

### Changed
- `configs/recipes/recipe-ff-canonical.yaml` now wires the context/T5 adapters, new validators, pick-best-engine, and repair loop before the build stage.
- `docs/stories/story-058-post-ocr-text-quality.md` updated with the repair/regression records, validator explanations, and final status now marked “Done”.
- Story index `docs/stories.md` now shows Story 058 status `Done`.

### Fixed
- Documented that the 20-page smoke is the verification target so we no longer require a full-book run; validators now capture source artifacts for traceability.
## [2025-12-19-01] - Smoke test tuning and validator compatibility

### Changed
- Smoke settings now align with 20-page slice expectations (boundary coverage thresholds and expected range set to sections 20–21).
- Choice completeness validator relaxed for smoke runs (`max_discrepancy`).
- Frontmatter fine segmentation accepts split page IDs in coarse segments.
- Module param schemas updated for new boundary/scan/extract flags.
## [2025-12-20-02] - AI OCR benchmark suite and GPT‑5.1 pipeline planning

### Added
- OCR benchmark harness + vendor runners (OpenAI, Anthropic, Gemini, Mistral, Azure DI, AWS Textract, HF/Qwen) with HTML/text diffing and cost aggregation.
- Benchmark dashboard (`docs/ocr-bench.html`) and data (`docs/ocr-bench-data.json`) with adjustable page counts and dropped‑page metrics.
- New GPT‑5.1 AI‑first pipeline story (`story-081`) and GPT‑5.1 recipe scaffold copy.

### Changed
- Story 077 marked Done; pipeline redesign work moved to Story 081.
- Story index updated with Story 081.

## [2025-12-20-01] - Dual-field page numbering completion and ordering guard improvements

### Added
- Logical page numbering propagation across OCR → elements → portions, with original-page provenance fields.
- Logical-page escalation mapping (split pages) with updated escalation cache behavior.
- Header span heuristic to prune empty between-header candidates during ordering/span conflicts.
- Sequential page-number validation helper and tests.
- Monitoring docs updates and story tracking for OCR quality regressions.

### Changed
- Element IDs and downstream range checks now use sequential `page_number`.
- Story 079 marked Done; Story 058 re-opened with split-page OCR contamination evidence.

### Fixed
- Ordering/span validation progress reporting and guard logic consistency across stages.
## [2025-12-21-01] - GPT‑5.1 HTML-first OCR pipeline and validation

### Added
- GPT‑5.1 HTML OCR pipeline modules (split-only intake, OCR HTML, HTML→blocks, coarse segmentation, boundary detection + repair loop, HTML portionizer).
- Relaxed choice extraction + targeted repair loop with issues reporting.
- Gamebook smoke validator and OCR HTML schema validator.
- New schemas for page images, HTML pages, HTML blocks, and pipeline issues.

### Changed
- GPT‑5.1 recipe wired to HTML-first pipeline with issue reporting and gamebook validation.
- Build stage now accepts extra inputs (issues report) and propagates manual-review notes into gamebook provenance.
- Story 081 marked Done with full-book validation evidence.

### Tested
- `PYTHONPATH=. pytest -q tests/test_ocr_ai_gpt51_schema.py`
- 20-page end-to-end run: `/tmp/cf-ff-ai-ocr-gpt51-smoke-20`
- Full-book run: `/tmp/cf-ff-ai-ocr-gpt51-full-`
## [2025-12-26-01] - Pipeline visibility cost/status and OpenAI usage centralization

### Added
- Central OpenAI client wrapper to log LLM usage across modules.
- Run status stamping for crashed/failed/done to persist in `pipeline_state.json`.
- Styled run selector with filtering, status pills, and external-runs toggle.
- Cost summary card and per-stage cost breakdown in pipeline visibility dashboard.

### Changed
- Dashboard run list now filters to existing on-disk runs and dedupes by path.
- Run status/percent handling prefers top-level `pipeline_state.status` when present.

### Fixed
- Dashboard now treats stale runs as crashed when status is stamped.
## [2025-12-28-01] - Game-ready validation consolidation and OCR robustness

### Added
- Consolidated game-ready validation report with attempt details for orphans and broken links.
- Choice/text alignment and orphan-trace validators wired into canonical recipes.
- OCR metadata fields preserved through schema stamping.

### Changed
- PDF extraction now falls back when embedded images are partial or multi-XObject.
- Splitter now groups by size/aspect and gates per-page spread splits.
- Pipeline visibility UI now shows running stage, URL-selected run, and improved progress handling.

### Fixed
- Choice repair no longer overrides explicit numeric references; HTML anchors are patched on repair.
- Ordering/duplicate header issues surfaced in issues report and game-ready validation.
## [2025-12-29-01] - Gamebook output cleanup, ending status, and validator guards

### Added
- Story 105 (choice text enrichment spec) and Story 107 (shared validator unification) scaffolds.
- `status` field propagation for ending sections (victory/death) via `ending_guard_v1` output.

### Changed
- `html_to_blocks_v1` now preserves inline `<a>` content within paragraphs to avoid choice-sentence truncation.
- `clean_html_presentation_v1` drops `html`, `text`, `raw_text`, and `clean_text` from final `gamebook.json`.
- `validate_choice_links_v1` adds a content-overlap guard to prevent over-aggressive orphan repairs.
- `enriched_portion_v1` schema now retains ending flags (`is_gameplay`, `end_game`, `ending`).

### Fixed
- Section 114 text loss after inline anchors (restored full choice sentence in final output).

### Tested
- `python driver.py --recipe configs/recipes/recipe-ff-ai-ocr-gpt51-pristine-fast.yaml --run-id ff-ai-ocr-gpt51-pristine-fast-full --output-dir output/runs/ff-ai-ocr-gpt51-pristine-fast-full --start-from detect_endings --allow-run-id-reuse`
## [2025-12-31-01] - Game-ready output package bundling

### Added
- `package_game_ready_v1` export module to bundle `gamebook.json` and validator into `output/` with README.

### Changed
- Canonical GPT‑5.1 FF recipes now append the game-ready package stage.
- Docs reference `output/runs/<run_id>/output/` as the ship-ready bundle location.

### Tested
- `python driver.py --recipe configs/recipes/recipe-ff-ai-ocr-gpt51.yaml --run-id ff-ai-ocr-gpt51-pristine-fast-full --allow-run-id-reuse --output-dir output/runs/ff-ai-ocr-gpt51-pristine-fast-full --start-from package_game_ready`
## [2026-01-02-01] - Edgecase scanner/patch workflow and link-claim tracking

### Added
- Edgecase scanner + AI verification + patch application modules with schemas and tests.
- Turn-to link tracking and claim reconciliation across extractors.
- Resume recipes for edgecase scanning and synthetic patch demo.

### Changed
- Recipes reorder choice extraction after combat/stat modules and apply edgecase patches before validation/packaging.
- Choice completeness validation now considers turn-to links and mechanic targets.
- README updated with edgecase workflow.

### Fixed
- Package game-ready now resolves recipe snapshots from stage directories.
- Turn-to claims serialization warnings in inventory/stat/combat modules.

### Tested
- `python -m pytest tests/test_extract_stat_modifications_v1.py`
