import socket
def deny(*args, **kwargs):
    raise RuntimeError('Offline literal proof forbids socket connections')
socket.socket.connect = deny
socket.socket.connect_ex = deny
socket.create_connection = deny
import sys
sys.path.insert(0,'/Users/cam/.codex/worktrees/scout092-docweb-literal-20261013')
from benchmarks.scripts.literal_qualification_offline import install_backend
install_backend()
