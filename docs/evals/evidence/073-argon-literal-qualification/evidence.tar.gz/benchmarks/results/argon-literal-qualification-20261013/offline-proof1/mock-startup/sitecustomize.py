import sys
sys.path.insert(0,'/Users/cam/.codex/worktrees/scout092-docweb-literal-20261013')
from benchmarks.scripts.literal_qualification_offline import install_backend
install_backend()
