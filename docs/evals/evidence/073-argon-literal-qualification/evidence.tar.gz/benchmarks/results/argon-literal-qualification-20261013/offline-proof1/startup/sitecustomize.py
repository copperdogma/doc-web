import sys
sys.path.insert(0,'/Users/cam/.codex/worktrees/scout092-docweb-literal-20261013')
from benchmarks.providers.literal_qualification_guard import install
install()
