from pathlib import Path
r=Path('/Users/cam/.codex/worktrees/scout097-docweb-20261017')
p=r/'benchmarks/scripts/scout096_reading.py'
s=p.read_text().replace('scout096','scout097').replace('SCOUT096','SCOUT097').replace('078-scout096','079-scout097').replace('nvidia/nemotron-3.5-super-vl','deepseek/deepseek-v4.1-flash-1017').replace('20261016','20261017').replace('Together','Cloudflare').replace('"reasoning": {"enabled": True}','"reasoning": {"effort": "high"}').replace('"prompt": 0.15, "completion": 0.5','"prompt": 0.30, "completion": 1.20').replace('model + "-20261015"','"deepseek/deepseek-v4.1-flash-20261017"')
s=s.replace('E = ROOT / "docs/evals/evidence/078-scout097"','E = ROOT / "docs/evals/evidence/079-scout097"')
s=s.replace('for case in ("ambiguity-negative", "image-positive", "native-positive"):', 'for case in ("image-positive", "ambiguity-negative", "native-positive"):')
s=s.replace('    for case in ("image-positive", "ambiguity-negative", "native-positive"):\n        initial =', '    for case in ([sys.argv[2]] if len(sys.argv)>2 else ("image-positive", "ambiguity-negative", "native-positive")):\n        initial =')
s=s.replace('keys = ["Image011"] + [','keys = [sys.argv[2]] if len(sys.argv)>2 else ["Image011"] + [')
s=s.replace('    if mode in ("screen", "recovery1"):\n        keys = ["Image011"]','    if mode in ("screen", "recovery1") and len(sys.argv)<=2:\n        keys = ["Image011"]')
s=s.replace('    for fixture in [sys.argv[2]] if len(sys.argv) > 2 else ["barney", "alverson"]:', '    for fixture in ["barney"]:')
s=s.replace('argon-ocr-', 'scout097-ocr-')
# always fail exact wrong Gemini identity before scoring (existing code does).
(r/'benchmarks/scripts/scout097_reading.py').write_text(s)
p=r/'benchmarks/providers/scout096_guard.py'
s=p.read_text().replace('scout096','scout097').replace('SCOUT096','SCOUT097').replace('078-scout097','079-scout097').replace('20261016','20261017')
a=s.index('        if model not in ['); b=s.index('    else:\n        prices =',a)
s=s[:a]+'''        if model != "deepseek/deepseek-v4.1-flash-1017":
            raise RuntimeError("unapproved model")
        maximum = b.get("max_tokens", 0)
        encoded = json.dumps(b)
        count = encoded.count('"image_url": {')
        bound = 20000 * count + 6000
        reserve = (bound * 0.30 + maximum * 1.20) / 1e6
''' +s[b:]
s=s.replace('reserve = (bound * max(prices[:3]) + maximum * prices[3]) / 1e6','reserve = max(1.5 if model == "gpt-6-astra" else 0, (bound * max(prices[:3]) + maximum * prices[3]) / 1e6)')
(r/'benchmarks/providers/scout097_guard.py').write_text(s)
