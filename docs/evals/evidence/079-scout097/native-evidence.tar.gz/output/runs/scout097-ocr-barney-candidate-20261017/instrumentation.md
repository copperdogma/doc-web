# Instrumentation Report — scout097-ocr-barney-candidate-20261017

- Run started: 2026-10-17T15:41:10.453129Z
- Run ended: 2026-10-17T15:46:45.670799Z
- Wall time: 335.216419 seconds
- Total cost: 0.000000 USD

## Per-model cost
_no LLM calls recorded_

## Stage timings
| stage | status | wall_s | user_s | sys_s | cost | calls |
|---|---|---:|---:|---:|---:|---:|
| images_to_manifest | done | 0.416 | 0.259 | 0.055 | 0.000000 | 0 |
| ocr_ai | done | 334.800 | 0.305 | 0.073 | 0.000000 | 0 |
