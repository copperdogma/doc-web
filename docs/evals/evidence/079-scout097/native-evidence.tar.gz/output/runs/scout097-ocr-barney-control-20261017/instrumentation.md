# Instrumentation Report — scout097-ocr-barney-control-20261017

- Run started: 2026-10-17T15:46:46.398793Z
- Run ended: None
- Wall time: 48.990426 seconds
- Total cost: 0.000000 USD

## Per-model cost
_no LLM calls recorded_

## Stage timings
| stage | status | wall_s | user_s | sys_s | cost | calls |
|---|---|---:|---:|---:|---:|---:|
| images_to_manifest | done | 0.413 | 0.258 | 0.059 | 0.000000 | 0 |
| ocr_ai | failed | 48.578 | 0.309 | 0.073 | 0.000000 | 0 |
