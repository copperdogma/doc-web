import sys;sys.path.insert(0,'/Users/cam/.codex/worktrees/scout097-docweb-20261017'); from benchmarks.scripts.scout097_reading import install_ocr; install_ocr()
