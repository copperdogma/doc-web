import os,sys
from pathlib import Path
ROOT=Path(os.environ["HAIKU55_ROOT"])
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/"benchmarks/providers"))
import haiku55_guard as guard
guard.install()
from modules.common.anthropic_client import AnthropicVisionClient
import httpx,base64

def generate(self, model, system_prompt,user_text,image_data,temperature=0,max_tokens=16384):
 arm=os.environ["HAIKU55_ARM"]
 header,data=image_data.split(",",1)
 body={"model":model,"max_tokens":max_tokens,"system":system_prompt,"messages":[{"role":"user","content":[{"type":"text","text":user_text},{"type":"image","source":{"type":"base64","media_type":header.split(":")[1].split(";")[0],"data":data}}]}],"thinking":{"type":"disabled" if arm=="low" else "adaptive"},"output_config":{"effort":arm}}
 r=httpx.post("https://api.anthropic.com/v1/messages",headers={"x-api-key":os.environ["ANTHROPIC_API_KEY"],"anthropic-version":"2023-06-01"},json=body,timeout=180);r.raise_for_status();d=r.json()
 if d.get("model")!=model or d.get("stop_reason")!="end_turn":raise RuntimeError("OCR identity/terminal invalid")
 out=[x["text"] for x in d["content"] if x["type"]=="text"]
 if len(out)!=1:raise RuntimeError("OCR final output invalid")
 return out[0],d["usage"],d["id"]
AnthropicVisionClient.generate_vision=generate
