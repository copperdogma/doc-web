# Instrumentation Report — haiku55-ocr-high-barney-20261007

- Run started: 2026-10-07T21:22:05.976202Z
- Run ended: 2026-10-07T21:22:18.243995Z
- Wall time: 12.26901 seconds
- Total cost: 0.000000 USD

## Per-model cost
_no LLM calls recorded_

## Stage timings
| stage | status | wall_s | user_s | sys_s | cost | calls |
|---|---|---:|---:|---:|---:|---:|
| images_to_manifest | done | 0.831 | 0.546 | 0.095 | 0.000000 | 0 |
| ocr_ai | done | 11.437 | 2.334 | 1.456 | 0.000000 | 0 |
