# Instrumentation Report — haiku55-ocr-medium-barney-20261007

- Run started: 2026-10-07T21:20:39.592762Z
- Run ended: None
- Wall time: 3.911231 seconds
- Total cost: 0.000000 USD

## Per-model cost
_no LLM calls recorded_

## Stage timings
| stage | status | wall_s | user_s | sys_s | cost | calls |
|---|---|---:|---:|---:|---:|---:|
| images_to_manifest | done | 0.843 | 0.544 | 0.094 | 0.000000 | 0 |
| ocr_ai | failed | 3.067 | 2.072 | 1.053 | 0.000000 | 0 |
