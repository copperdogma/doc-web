# Instrumentation Report — haiku55-ocr-control-barney-20261007

- Run started: 2026-10-07T21:22:19.276804Z
- Run ended: 2026-10-07T21:22:30.314281Z
- Wall time: 11.037627 seconds
- Total cost: 0.005652 USD

## Per-model cost
| model | prompt_tokens | completion_tokens | cost |
|---|---:|---:|---:|
| gemini-3.7-flash | 2030 | 398 | 0.005652 |

## Stage timings
| stage | status | wall_s | user_s | sys_s | cost | calls |
|---|---|---:|---:|---:|---:|---:|
| images_to_manifest | done | 0.820 | 0.539 | 0.094 | 0.000000 | 0 |
| ocr_ai | done | 10.216 | 2.266 | 1.168 | 0.005652 | 1 |
