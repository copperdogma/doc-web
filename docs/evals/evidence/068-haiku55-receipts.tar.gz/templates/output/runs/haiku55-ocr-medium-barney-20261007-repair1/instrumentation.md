# Instrumentation Report — haiku55-ocr-medium-barney-20261007-repair1

- Run started: 2026-10-07T21:21:37.493390Z
- Run ended: 2026-10-07T21:21:57.698622Z
- Wall time: 20.204744 seconds
- Total cost: 0.000000 USD

## Per-model cost
_no LLM calls recorded_

## Stage timings
| stage | status | wall_s | user_s | sys_s | cost | calls |
|---|---|---:|---:|---:|---:|---:|
| images_to_manifest | done | 0.829 | 0.550 | 0.098 | 0.000000 | 0 |
| ocr_ai | done | 19.375 | 2.463 | 1.283 | 0.000000 | 0 |
