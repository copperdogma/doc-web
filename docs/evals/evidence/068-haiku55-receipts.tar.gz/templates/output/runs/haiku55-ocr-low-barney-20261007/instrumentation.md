# Instrumentation Report — haiku55-ocr-low-barney-20261007

- Run started: 2026-10-07T21:21:58.758886Z
- Run ended: 2026-10-07T21:22:04.935234Z
- Wall time: 6.176076 seconds
- Total cost: 0.000000 USD

## Per-model cost
_no LLM calls recorded_

## Stage timings
| stage | status | wall_s | user_s | sys_s | cost | calls |
|---|---|---:|---:|---:|---:|---:|
| images_to_manifest | done | 0.836 | 0.554 | 0.100 | 0.000000 | 0 |
| ocr_ai | done | 5.329 | 2.353 | 1.091 | 0.000000 | 0 |
