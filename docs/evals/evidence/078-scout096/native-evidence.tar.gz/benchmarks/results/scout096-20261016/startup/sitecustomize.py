import sys;sys.path.insert(0,'/Users/cam/.codex/worktrees/scout096-docweb-20261016'); from benchmarks.scripts.scout096_reading import install_ocr; install_ocr()
