# Instrumentation Report — scout096-ocr-barney-control-20261016

- Run started: 2026-10-16T15:41:05.951168Z
- Run ended: None
- Wall time: 57.715847 seconds
- Total cost: 0.000000 USD

## Per-model cost
_no LLM calls recorded_

## Stage timings
| stage | status | wall_s | user_s | sys_s | cost | calls |
|---|---|---:|---:|---:|---:|---:|
| images_to_manifest | done | 0.414 | 0.268 | 0.057 | 0.000000 | 0 |
| ocr_ai | failed | 57.302 | 0.344 | 0.079 | 0.000000 | 0 |
