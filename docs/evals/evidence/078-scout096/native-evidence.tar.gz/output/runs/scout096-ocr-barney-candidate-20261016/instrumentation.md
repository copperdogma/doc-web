# Instrumentation Report — scout096-ocr-barney-candidate-20261016

- Run started: 2026-10-16T15:39:54.003473Z
- Run ended: 2026-10-16T15:41:05.334225Z
- Wall time: 71.330202 seconds
- Total cost: 0.000000 USD

## Per-model cost
_no LLM calls recorded_

## Stage timings
| stage | status | wall_s | user_s | sys_s | cost | calls |
|---|---|---:|---:|---:|---:|---:|
| images_to_manifest | done | 0.415 | 0.272 | 0.058 | 0.000000 | 0 |
| ocr_ai | done | 70.915 | 0.318 | 0.088 | 0.000000 | 0 |
