"""Serial frozen one-case Promptfoo calls; no retries or edits to evidence."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[2]
benchmarks = root / "benchmarks"
results = benchmarks / "results/gemini4-argon-20261023"
arm = sys.argv[1]
assert arm in {"candidate", "control"}
source_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
command_log = []
for task in sorted((results / "tasks").glob(arm + "-*.yaml")):
    key = task.stem.removeprefix(arm + "-")
    output = results / (task.stem + ".json")
    if output.exists():
        row = json.loads(output.read_text())["results"]["results"][0]
        assert row.get("success") and not row.get("response", {}).get("error"), "Prior case requires adjudication"
        continue
    ledger = json.loads((results / "ledger.json").read_text())
    assert not any(record["cost_usd"] is None for record in ledger["calls"]), "Unknown exposure; no further calls"
    command = [str(root / "scripts/run_with_doc_web_env.py"), "promptfoo", "eval", "-c", str(task.relative_to(benchmarks)),
               "--no-cache", "-j", "1", "--output", str(output.relative_to(benchmarks))]
    command_log.append(command)
    manifest = {"runner_sha256": source_sha, "commands": command_log,
                "campaign_sha256": ledger["campaign_sha256"], "arm": arm}
    Path(__file__).with_name(arm + "-commands.json").write_text(json.dumps(manifest, indent=2) + "\n")
    environment = dict(os.environ, MISTRAL_STAGE="detector")
    with Path(__file__).with_name(task.stem + ".log").open("w") as log:
        code = subprocess.run(command, cwd=benchmarks, env=environment, stdout=log, stderr=subprocess.STDOUT).returncode
    if not output.exists():
        raise SystemExit("Harness stopped without result: " + key)
    rows = json.loads(output.read_text())["results"]["results"]
    assert len(rows) == 1, "Unexpected matrix size"
    row = rows[0]
    print(json.dumps({"arm": arm, "key": key, "exit_code": code, "success": row.get("success"), "score": row.get("score")}), flush=True)
    if code not in (0, 100) or not row.get("success") or row.get("response", {}).get("error"):
        raise SystemExit("Stopped for source/contract adjudication: " + key)
assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == source_sha
print(arm + " frozen cases completed", flush=True)
