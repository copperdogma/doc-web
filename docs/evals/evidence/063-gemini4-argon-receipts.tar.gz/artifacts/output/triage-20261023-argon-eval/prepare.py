"""Freeze one public detector campaign before dispatch; never load credentials."""
import base64
import hashlib
import io
import json
import subprocess
import sys
from pathlib import Path

import yaml
from PIL import Image

root = Path(__file__).resolve().parents[2]
benchmarks = root / "benchmarks"
results = benchmarks / "results/gemini4-argon-20261023"
results.mkdir(mode=0o700, parents=True, exist_ok=False)
tasks = results / "tasks"
tasks.mkdir(mode=0o700)
base = yaml.safe_load((benchmarks / "tasks/image-crop-extraction.yaml").read_text())
provider_path = benchmarks / "providers/gemini4_argon.py"
providers = [
    {"id": "python:" + str(provider_path), "label": "Gemini 4 Argon (medium, strict integer crop schema)", "config": {"model": "gemini-4-argon"}},
    {"id": "python:" + str(provider_path), "label": "Gemini 3 Flash (fresh runtime control)", "config": {"model": "gemini-3-flash-preview"}},
]
sources = [
    Path(__file__), Path(__file__).with_name("native_probe.py"),
    provider_path, benchmarks / "providers/mistral4_guard.py",
    benchmarks / "providers/openrouter_vision_chat.py",
    benchmarks / "tasks/image-crop-extraction.yaml",
    benchmarks / "prompts/crop-conservative-count.js", benchmarks / "prompts/_image-helpers.js",
    benchmarks / "scorers/image_crop_scorer.py", benchmarks / "golden/image-crops.json",
    root / "scripts/run_with_doc_web_env.py", root / "doc_web/env.py",
    root / "tests/test_mistral4_guard.py", root / "tests/test_gemini4_argon.py",
]
fixtures = []
for test in base["tests"]:
    image_path = (benchmarks / "tasks" / test["vars"]["image"].removeprefix("file://")).resolve()
    uri = image_path.read_text().strip()
    pixel_bytes = base64.b64decode(uri.split(",", 1)[1], validate=True)
    image = Image.open(io.BytesIO(pixel_bytes))
    key = test["vars"]["golden_key"]
    fixtures.append({"key": key, "source": str(image_path.relative_to(root)), "image_sha256": hashlib.sha256(pixel_bytes).hexdigest(), "size": list(image.size)})
    sources.append(image_path)
    frozen_test = json.loads(json.dumps(test))
    frozen_test["vars"]["image"] = "file://" + str(image_path)
    for assertion in frozen_test["assert"]:
        assertion["value"] = "file://" + str((benchmarks / "tasks" / assertion["value"].removeprefix("file://")).resolve())
    for arm, provider in zip(["candidate", "control"], providers):
        config = {"description": f"Frozen Argon detector {arm} {key}",
            "prompts": [{"id": "file://" + str(benchmarks / "prompts/crop-conservative-count.js"), "label": "conservative-count"}],
            "providers": [provider], "tests": [frozen_test]}
        task = tasks / f"{arm}-{key}.yaml"
        task.write_text(yaml.safe_dump(config, sort_keys=False))
        sources.append(task)
profile = {
    "results_dir": str(results), "cap_usd": 5, "max_calls": 36,
    "prices": {"gemini-4-argon": [2, .1, 2, 10], "gemini-3-flash-preview": [.5, .05, .5, 3]},
    "output_limits": {"gemini-4-argon": 32768, "gemini-3-flash-preview": 16384},
    "endpoints": {model: f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent" for model in ["gemini-4-argon", "gemini-3-flash-preview"]},
    "sources": {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources},
}
profile_path = results / "profile.json"
profile_path.write_text(json.dumps(profile, indent=2) + "\n")
profile_path.chmod(0o600)
ledger = {"cap_usd": 5, "spent_usd": 0, "calls": [], "closed": False,
    "campaign_sha256": hashlib.sha256(profile_path.read_bytes()).hexdigest()}
ledger_path = results / "ledger.json"
ledger_path.write_text(json.dumps(ledger, indent=2) + "\n")
ledger_path.chmod(0o600)
sys.path.insert(0, str(benchmarks / "providers"))
import mistral4_guard as guard
guard.configure_campaign(profile_path)
proof = {"head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "dirty_paths": subprocess.check_output(["git", "status", "--short"], text=True).splitlines(),
    "python": sys.version, "campaign_sha256": ledger["campaign_sha256"],
    "source_count": len(sources), "fixtures": fixtures, "paid_requests": 0}
Path(__file__).with_name("preflight.json").write_text(json.dumps(proof, indent=2) + "\n")
print(json.dumps({"source_bindings": len(sources), "fixture_count": len(fixtures), "paid_requests": 0, "profile": str(profile_path)}, indent=2))
