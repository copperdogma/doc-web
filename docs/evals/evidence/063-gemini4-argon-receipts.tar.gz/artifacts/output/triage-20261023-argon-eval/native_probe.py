"""One public synthetic native image probe through the frozen campaign adapter."""
import base64
import io
import json
import os
import sys
from pathlib import Path

from PIL import Image, ImageDraw

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root / "benchmarks/providers"))
import gemini4_argon as adapter

image = Image.new("RGB", (64, 64), "white")
ImageDraw.Draw(image).rectangle((16, 16, 47, 47), fill="black")
buffer = io.BytesIO()
image.save(buffer, format="PNG")
uri = "data:image/png;base64," + base64.b64encode(buffer.getvalue()).decode()
prompt = json.dumps([{"role": "user", "content": [
    {"type": "text", "text": 'Locate the central black square as one illustration. Return JSON {"images":[{"description":"black square","bbox":[x0,y0,x1,y1]}]} with integer 0-1000 coordinates.'},
    {"type": "image_url", "image_url": {"url": uri}},
]}])
os.environ["MISTRAL_STAGE"] = "native-image"
result = adapter.call_api(prompt, {"config": {"model": adapter.CANDIDATE}}, {"vars": {"golden_key": "synthetic-black-square"}})
destination = adapter.guard.RESULTS / "native-image-result.json"
adapter.guard.write(destination, result)
if result.get("error"):
    raise SystemExit(result["error"])
assert len(json.loads(result["output"])["images"]) == 1, "Synthetic image content not established"
print(json.dumps(result, indent=2))
