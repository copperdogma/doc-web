"""Package Attempt 063's scoped public receipts for exact offline restoration."""
from __future__ import annotations

import hashlib
import json
import re
import subprocess
import tarfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
RESULTS_REL = Path("benchmarks/results/gemini4-argon-20261023")
OUTPUT_REL = Path("output/triage-20261023-argon-eval")
EVIDENCE_REL = Path("docs/evals/evidence")
MANIFEST_REL = EVIDENCE_REL / "063-gemini4-argon-manifest.json"
ARCHIVE_REL = EVIDENCE_REL / "063-gemini4-argon-receipts.tar.gz"
RECON_REL = EVIDENCE_REL / "063-reconstruct.py"
IMAGE_REVIEW_REL = {
    OUTPUT_REL / "source-review/Image000-comparison.png",
    OUTPUT_REL / "source-review/Image011-comparison.png",
    OUTPUT_REL / "source-review/Image124-comparison.png",
}
POST_FREEZE_EXCLUDED = {
}
MARKER_PREFIX = b"@DOCWEB063_IMAGE:"


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def safe_rel(name: str) -> Path:
    path = Path(name)
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise ValueError(f"Unsafe artifact path: {name!r}")
    return path


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object in {path}")
    return value


def image_data_strings(value: Any):
    if isinstance(value, dict):
        for key, child in value.items():
            if key in {"inlineData", "inline_data"} and isinstance(child, dict):
                data = child.get("data")
                if isinstance(data, str):
                    yield data.encode("ascii")
            yield from image_data_strings(child)
    elif isinstance(value, list):
        for child in value:
            yield from image_data_strings(child)


def sha_sources(profile: dict[str, Any], ledger: dict[str, Any]) -> dict[str, dict[str, str]]:
    records: dict[str, dict[str, str]] = {}
    for name, digest in profile.get("sources", {}).items():
        rel = safe_rel(name).as_posix()
        records.setdefault(rel, {})["profile.sources"] = digest
    for call in ledger["calls"]:
        for name, digest in call.get("code_sha256", {}).items():
            rel = safe_rel(name).as_posix()
            old = records.setdefault(rel, {}).get("profile.sources")
            if old is not None and old != digest:
                raise ValueError(f"Conflicting frozen source hashes for {rel}")
            records[rel]["ledger.call.code_sha256"] = digest
    for rel, provenance in records.items():
        actual = sha((ROOT / rel).read_bytes())
        expected = set(provenance.values())
        if expected != {actual}:
            raise ValueError(f"Frozen source hash mismatch for {rel}")
    return records


def scoped_paths(profile: dict[str, Any], ledger: dict[str, Any]) -> tuple[list[str], dict[str, str]]:
    names: set[str] = set()
    source_records = sha_sources(profile, ledger)
    names.update(source_records)

    result_root = ROOT / RESULTS_REL
    for path in result_root.rglob("*"):
        if path.is_file() and path.suffix.lower() in {".json", ".yaml", ".yml"}:
            names.add(path.relative_to(ROOT).as_posix())

    output_root = ROOT / OUTPUT_REL
    for path in output_root.iterdir():
        rel = path.relative_to(ROOT).as_posix()
        if (
            path.is_file()
            and path.suffix.lower() in {".py", ".json", ".log"}
            and rel not in POST_FREEZE_EXCLUDED
            and not (path.parent == output_root and path.name.startswith("reconstruction-proof"))
        ):
            names.add(rel)
    names.update(path.as_posix() for path in IMAGE_REVIEW_REL)
    names.add((OUTPUT_REL / "pack_evidence.py").as_posix())

    for name in names:
        safe_rel(name)
        path = ROOT / name
        if not path.is_file():
            raise FileNotFoundError(name)
        if path.name == ".env" or path.name.lower() in {"credentials.json", "secrets.json"}:
            raise ValueError(f"Credential-like path refused: {name}")
    return sorted(names), source_records


def main() -> None:
    results_root = ROOT / RESULTS_REL
    profile = load_json(results_root / "profile.json")
    ledger = load_json(results_root / "ledger.json")
    if ledger.get("closed") is not True:
        raise ValueError("Refusing to package an open spend ledger")
    calls = ledger.get("calls", [])
    if len(calls) != 27:
        raise ValueError(f"Expected 27 campaign calls, got {len(calls)}")
    unknown = [call for call in calls if call.get("cost_usd") is None]
    settled = sum(float(call["cost_usd"]) for call in calls if call.get("cost_usd") is not None)
    if unknown or abs(settled - float(ledger["spent_usd"])) > 1e-9:
        raise ValueError("Ledger has unknown or unreconciled spend")

    # Only request-001..027 contain provider request payloads; do not inspect or
    # print them. The exact inline ASCII payload is the deduplicated blob value.
    request_blobs: dict[str, bytes] = {}
    request_count = 0
    for sequence in range(1, 28):
        req_path = results_root / f"request-{sequence:03d}.json"
        if not req_path.is_file():
            raise FileNotFoundError(req_path)
        request_count += 1
        request = load_json(req_path)
        payloads = list(image_data_strings(request))
        if len(payloads) != 1:
            raise ValueError(f"Expected one inline image in request {sequence:03d}")
        payload = payloads[0]
        request_blobs[sha(payload)] = payload
    if request_count != len(calls):
        raise ValueError("Request receipt count differs from ledger call count")

    # The frozen profile also names checked-in public page fixtures that were
    # not dispatched. Preserve those scoped source files with the same exact
    # payload templating, without implying that they were sent to the provider.
    blobs = dict(request_blobs)
    for name in profile.get("sources", {}):
        if name.startswith("benchmarks/input/source-pages-b64/") and name.endswith(".b64.txt"):
            source_uri = (ROOT / safe_rel(name)).read_bytes()
            try:
                header, encoded = source_uri.split(b",", 1)
            except ValueError as exc:
                raise ValueError(f"Malformed checked-in image fixture: {name}") from exc
            if not header.startswith(b"data:image/") or not encoded:
                raise ValueError(f"Unexpected checked-in image fixture: {name}")
            blobs[sha(encoded)] = encoded

    paths, source_records = scoped_paths(profile, ledger)
    artifacts: list[dict[str, Any]] = []
    templated: dict[str, bytes] = {}
    for name in paths:
        original = (ROOT / name).read_bytes()
        raw_hash = sha(original)
        template = original
        for digest, payload in blobs.items():
            marker = MARKER_PREFIX + digest.encode("ascii") + b"@"
            template = template.replace(payload, marker)
        template_hash = sha(template)
        templated[name] = template
        item: dict[str, Any] = {
            "path": name,
            "bytes": len(original),
            "sha256": raw_hash,
            "template_sha256": template_hash,
        }
        if name in source_records:
            item["source_hash_provenance"] = source_records[name]
        artifacts.append(item)

    # Ensure every source fixture payload and every request payload can be
    # reconstructed from the same exact byte strings; the marker survives in
    # each relevant artifact and no marker references a missing blob.
    referenced = set()
    marker_re = re.compile(rb"@DOCWEB063_IMAGE:([0-9a-f]{64})@")
    for template in templated.values():
        referenced.update(match.group(1).decode("ascii") for match in marker_re.finditer(template))
    if referenced != set(blobs) or not set(request_blobs).issubset(referenced):
        raise ValueError("Image payload blob references do not match scoped images")

    EVIDENCE = ROOT / EVIDENCE_REL
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    archive_path = ROOT / ARCHIVE_REL
    with tarfile.open(archive_path, "w:gz", compresslevel=6) as tar:
        for name in paths:
            info = tarfile.TarInfo("artifacts/" + name)
            info.size = len(templated[name])
            info.mode = 0o600
            info.mtime = 0
            import io
            tar.addfile(info, io.BytesIO(templated[name]))
        for digest, payload in sorted(blobs.items()):
            info = tarfile.TarInfo("blobs/" + digest)
            info.size = len(payload)
            info.mode = 0o600
            info.mtime = 0
            import io
            tar.addfile(info, io.BytesIO(payload))
    archive_raw = archive_path.read_bytes()

    try:
        root_head = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
        ).strip()
    except Exception:
        root_head = None

    manifest = {
        "attempt": "063",
        "name": "Gemini 4 Argon crop qualification evidence package",
        "root_head": root_head,
        "scope": {
            "result_files": "benchmarks/results/gemini4-argon-20261023/**/*.json and tasks/**/*.yaml",
            "source_files": "union of profile.sources and ledger call.code_sha256",
            "operator_files": sorted(
                name for name in paths
                if name.startswith(OUTPUT_REL.as_posix() + "/")
                and Path(name).parent == OUTPUT_REL
                and (Path(name).suffix.lower() in {".py", ".json", ".log"})
            ),
            "source_review_images": sorted(p.as_posix() for p in IMAGE_REVIEW_REL),
            "excluded": [
                "environment files/credentials",
                "output/triage-20261023-argon-eval/reconstruction-proof*.log (created after frozen scope; generated only to verify this package)",
                "other source-review images and non-review comparison images",
                "unlisted output files",
            ],
        },
        "ledger": {
            "path": (RESULTS_REL / "ledger.json").as_posix(),
            "closed": ledger["closed"],
            "call_count": len(calls),
            "cap_usd": ledger["cap_usd"],
            "settled_usd": round(settled, 10),
            "unknown_calls": len(unknown),
            "close_reason": ledger.get("close_reason"),
        },
        "source_hashes": [
            {"path": path, "sha256": next(iter(set(record.values()))), "provenance": record}
            for path, record in sorted(source_records.items())
        ],
        "commands_references": [
            (OUTPUT_REL / "native-probe.log").as_posix(),
            (OUTPUT_REL / "candidate-commands.json").as_posix(),
            (OUTPUT_REL / "control-commands.json").as_posix(),
            (OUTPUT_REL / "prepare.py").as_posix(),
            (OUTPUT_REL / "run_detector.py").as_posix(),
        ],
        "reconstruction_command": "python docs/evals/evidence/063-reconstruct.py <fresh-destination>",
        "artifacts": artifacts,
        "archive": {
            "path": ARCHIVE_REL.as_posix(),
            "sha256": sha(archive_raw),
            "bytes": len(archive_raw),
            "artifact_count": len(artifacts),
            "blob_count": len(blobs),
            "blob_hashes": sorted(blobs),
        },
    }
    (ROOT / MANIFEST_REL).write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

    reconstruct = '''"""Restore exact Attempt063 public receipts offline; no credentials/provider calls."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile

base = Path(__file__).resolve().parent
manifest = json.loads((base / "063-gemini4-argon-manifest.json").read_text())
archive = base / Path(manifest["archive"]["path"]).name
raw_archive = archive.read_bytes()
assert hashlib.sha256(raw_archive).hexdigest() == manifest["archive"]["sha256"]
destination = Path(sys.argv[1]).resolve()
if destination.exists() and any(destination.iterdir()):
    raise SystemExit(f"Destination must be absent or empty: {destination}")
destination.mkdir(parents=True, exist_ok=True)
with tarfile.open(archive) as source:
    blobs = {
        digest: source.extractfile("blobs/" + digest).read()
        for digest in manifest["archive"]["blob_hashes"]
    }
    assert all(hashlib.sha256(value).hexdigest() == digest for digest, value in blobs.items())
    for item in manifest["artifacts"]:
        name = item["path"]
        path = Path(name)
        assert not path.is_absolute() and ".." not in path.parts
        template = source.extractfile("artifacts/" + name).read()
        assert hashlib.sha256(template).hexdigest() == item["template_sha256"]
        raw = template
        for digest, value in blobs.items():
            raw = raw.replace(("@DOCWEB063_IMAGE:" + digest + "@").encode(), value)
        assert len(raw) == item["bytes"]
        assert hashlib.sha256(raw).hexdigest() == item["sha256"]
        out = destination / name
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(raw)
        out.chmod(0o600)
print("Restored and verified", len(manifest["artifacts"]), "exact files; no provider calls")
'''
    (ROOT / RECON_REL).write_text(reconstruct, encoding="utf-8")
    print(
        f"Packaged {len(artifacts)} exact files; {len(blobs)} deduplicated image payload blobs; "
        f"archive {len(archive_raw)} bytes; settled ${settled:.7f}; no unknown calls."
    )


if __name__ == "__main__":
    main()
