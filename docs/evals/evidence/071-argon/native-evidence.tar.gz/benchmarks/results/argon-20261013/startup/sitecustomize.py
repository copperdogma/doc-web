import sys;sys.path.insert(0,'/Users/cam/.codex/worktrees/scout092-argon-docweb-20261013'); from benchmarks.scripts.argon_campaign import install_ocr; install_ocr()
