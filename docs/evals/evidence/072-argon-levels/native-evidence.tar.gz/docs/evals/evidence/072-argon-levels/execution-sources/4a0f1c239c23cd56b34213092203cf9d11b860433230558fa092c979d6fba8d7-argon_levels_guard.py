"""Serial campaign guard, below adapters and SDKs, with durable intent receipts."""

import hashlib
import json
import os
import time
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "benchmarks/results/argon-levels-20261013"
EVIDENCE = ROOT / "docs/evals/evidence/072-argon-levels"
OLD_LEDGER = ROOT / "benchmarks/results/argon-20261013/ledger.json"
PRICES = {
    "gemini-4-argon": (2, 0.1, 2, 10),
    "gpt-6-astra": (10, 1, 10, 50),
    "gemini-3.7-flash": (0.75, 0.075, 0.75, 3.75),
    "gpt-6.1-sol": (2, 0.1, 2.5, 10),
    "gpt-5.5": (5, 0.5, 5, 30),
    "gemini-3-flash-preview": (0.5, 0.05, 0.5, 3),
}


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(data, indent=2) + "\n")
    temp.chmod(0o600)
    temp.replace(path)


def _guarded_send_unlocked(original, client, request, **kwargs):
    if request.method != "POST":
        return original(client, request, **kwargs)
    body = json.loads(request.content)
    google = request.url.host == "generativelanguage.googleapis.com"
    if google:
        model = request.url.path.split("/models/")[1].split(":")[0]
        maximum = body["generationConfig"]["maxOutputTokens"]
        content = body.get("contents", [])
    elif request.url.host == "api.openai.com" and request.url.path == "/v1/responses":
        model = body["model"]
        maximum = body["max_output_tokens"]
        content = body["input"]
        if body.get("tools") or body.get("store") is not False:
            raise RuntimeError("Unapproved tool or storage contract")
    else:
        raise RuntimeError("Unmetered POST denied by image campaign")
    if not google or model != "gemini-4-argon":
        raise RuntimeError("Only selected native Argon calibration calls allowed")
    if maximum != 32768:
        raise RuntimeError("Frozen 32768 allowance required")
    frozen = json.loads((EVIDENCE / "freeze.json").read_text())
    if (
        hashlib.sha256(OLD_LEDGER.read_bytes()).hexdigest()
        != frozen["old_ledger_sha256"]
    ):
        raise RuntimeError(
            "Original ledger changed; cumulative exposure must be reconciled"
        )
    stage = os.environ.get("ARGON_STAGE")
    selected = next((x for x in frozen["matrix"] if x["stage"] == stage), None)
    if (
        not selected
        or hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()
        != selected["request_sha256"]
    ):
        raise RuntimeError("Request not in frozen effort-only matrix")
    if stage.startswith("crop-confirmation-"):
        for key in ("Image037", "Image001", "Image011"):
            verdict = json.loads((EVIDENCE / f"source-{key}.json").read_text())
            if verdict.get("high_source_complete") is not True:
                raise RuntimeError(
                    "Conditional confirmation requires all high source checks"
                )
    if (EVIDENCE / f"stop-{selected['lane']}-{selected['level']}.json").exists():
        raise RuntimeError("Source-backed arm stop denies further dispatch")
    prices = PRICES[model]
    if maximum > (32768 if model == "gemini-4-argon" else 16384):
        raise RuntimeError("Output allowance exceeded")
    encoded = json.dumps(content)
    images = (
        encoded.count('"image"')
        + encoded.count('"input_image"')
        + encoded.count('"inlineData"')
        + encoded.count('"inline_data"')
    )
    if images < 1 or images > 2:
        raise RuntimeError("Campaign requires one or two image inputs")
    # Fixed benchmark envelope: 20k/image plus 6k for text, instructions and schema.
    bound = images * 20000 + 6000
    reserve = (bound * max(prices[:3]) + maximum * prices[3]) / 1e6
    path = RESULTS / "ledger.json"
    ledger = json.loads(path.read_text())
    exposure = ledger["spent_usd"] + sum(
        c["reserved_usd"] for c in ledger["calls"] if c.get("cost_usd") is None
    )
    if (
        ledger.get("closed")
        or exposure + reserve > ledger["cap_usd"]
        or frozen["old_maximum_exposure_usd"] + exposure + reserve > 15
    ):
        raise RuntimeError(
            "Image campaign admission denied: reserve exceeds remaining cap"
        )
    if any(
        c.get("stage") == os.environ.get("ARGON_STAGE") and c["model"] == model
        for c in ledger["calls"]
    ):
        raise RuntimeError("Duplicate dispatch denied; declare a recovery stage")
    if len(ledger["calls"]) >= 16:
        raise RuntimeError("Finite request ceiling exhausted")
    seq = len(ledger["calls"]) + 1
    raw_request = json.dumps(body, sort_keys=True).encode()
    request_path = RESULTS / f"request-{seq:03d}.json"
    response_path = RESULTS / f"response-{seq:03d}.json"
    if request_path.exists() or response_path.exists():
        raise RuntimeError("Existing receipt identity collision; dispatch denied")
    with request_path.open("xb") as receipt:
        receipt.write(raw_request)
    (RESULTS / f"request-{seq:03d}.json").chmod(0o600)
    record = dict(
        level=body["generationConfig"]["thinkingConfig"]["thinkingLevel"],
        sequence=seq,
        model=model,
        reserved_usd=reserve,
        cost_usd=None,
        request_sha256=hashlib.sha256(raw_request).hexdigest(),
        stage=os.environ.get("ARGON_STAGE"),
        code_sha256={
            str(f.relative_to(ROOT)): hashlib.sha256(f.read_bytes()).hexdigest()
            for f in [
                Path(__file__),
                ROOT / "benchmarks/scripts/argon_levels.py",
                ROOT / "modules/common/openai_client.py",
                ROOT / "modules/common/google_client.py",
                ROOT / "modules/extract/ocr_ai_gpt51_v1/main.py",
            ]
        },
    )
    snapshots = EVIDENCE / "execution-sources"
    snapshots.mkdir(parents=True, exist_ok=True)
    for relative, digest in record["code_sha256"].items():
        source = ROOT / relative
        target = snapshots / (digest + "-" + source.name)
        if not target.exists():
            target.write_bytes(source.read_bytes())
    ledger["calls"].append(record)
    write(path, ledger)
    started = time.monotonic()
    try:
        response = original(client, request, **kwargs)
    except Exception as exc:
        record["transport_exception"] = type(exc).__name__
        write(path, ledger)
        raise
    response.read()
    raw = response.content
    destination = RESULTS / f"response-{seq:03d}.json"
    with destination.open("xb") as receipt:
        receipt.write(raw)
    destination.chmod(0o600)
    record.update(
        response_sha256=hashlib.sha256(raw).hexdigest(),
        response_bytes=len(raw),
        status_code=response.status_code,
        latency_ms=round((time.monotonic() - started) * 1000),
    )
    try:
        data = json.loads(raw)
        usage = data.get("usageMetadata", {}) if google else data.get("usage", {})
        if google:
            inp = usage["promptTokenCount"]
            out = usage.get("candidatesTokenCount", 0) + usage.get(
                "thoughtsTokenCount", 0
            )
            cache = usage.get("cachedContentTokenCount", 0)
            writes = 0
        else:
            inp, out = usage["input_tokens"], usage["output_tokens"]
            details = usage.get("input_tokens_details", {})
            cache, writes = (
                details.get("cached_tokens", 0),
                details.get("cache_write_tokens", 0),
            )
        if (
            any(type(x) is not int or x < 0 for x in (inp, out, cache, writes))
            or cache + writes > inp
        ):
            raise ValueError("invalid usage")
        cost = (
            (inp - cache - writes) * prices[0]
            + cache * prices[1]
            + writes * prices[2]
            + out * prices[3]
        ) / 1e6
        record.update(
            cost_usd=cost,
            usage=usage,
            served_model=data.get("modelVersion", data.get("model")),
            response_id=data.get("responseId", data.get("id")),
        )
        ledger["spent_usd"] += cost
        if inp > bound or out > maximum or cost > reserve:
            ledger["closed"] = True
            record["bound_violation"] = True
    except (KeyError, ValueError, TypeError):
        record["billing_unresolved"] = True
    ledger["calls"][-1] = record
    write(path, ledger)
    return response


def guarded_send(original, client, request, **kwargs):
    import fcntl

    RESULTS.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (RESULTS / "dispatch.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        return _guarded_send_unlocked(original, client, request, **kwargs)


def install():
    libraries = [httpx]
    try:
        import httpx2

        libraries.append(httpx2)
    except ImportError:
        pass
    for library in libraries:
        if getattr(library.Client.send, "_image_guard", False):
            continue
        original = library.Client.send

        def send(client, request, _original=original, **kwargs):
            return guarded_send(_original, client, request, **kwargs)

        send._image_guard = True
        library.Client.send = send
