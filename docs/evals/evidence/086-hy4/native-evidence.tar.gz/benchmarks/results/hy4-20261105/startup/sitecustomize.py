import sys;sys.path.insert(0,'/Users/cam/.codex/worktrees/hy4-ripple-20261105/doc-web'); from benchmarks.scripts.hy4_reading import install_ocr; install_ocr()
