# Instrumentation Report — hy4-ocr-barney-control-20261105

- Invocation started: 2026-11-05T14:54:33.177181Z
- Invocation ended: None
- Wall time: 191.52343 seconds
- Recorded run cost: 0.000000 USD
- Usage scope: cumulative recorded run history; wall/CPU time: current invocation.
- Cost basis: explicit event costs, otherwise estimates under the displayed price sheet.

## Per-model cost
_no LLM calls recorded_

## Latest recorded stage timings and cumulative usage
Unknown timing is not reconstructed from usage events; status reflects current pipeline state.
| stage | status | wall_s | user_s | sys_s | cost | calls |
|---|---|---:|---:|---:|---:|---:|
| images_to_manifest | done | 0.423 | 0.244 | 0.058 | 0.000000 | 0 |
| ocr_ai | failed | 191.100 | 0.281 | 0.060 | 0.000000 | 0 |
