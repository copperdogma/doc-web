# Instrumentation Report — hy4-ocr-barney-candidate-20261105

- Invocation started: 2026-11-05T14:49:02.428677Z
- Invocation ended: 2026-11-05T14:54:32.494306Z
- Wall time: 330.06444 seconds
- Recorded run cost: 0.000000 USD
- Usage scope: cumulative recorded run history; wall/CPU time: current invocation.
- Cost basis: explicit event costs, otherwise estimates under the displayed price sheet.

## Per-model cost
_no LLM calls recorded_

## Latest recorded stage timings and cumulative usage
Unknown timing is not reconstructed from usage events; status reflects current pipeline state.
| stage | status | wall_s | user_s | sys_s | cost | calls |
|---|---|---:|---:|---:|---:|---:|
| images_to_manifest | done | 0.415 | 0.259 | 0.055 | 0.000000 | 0 |
| ocr_ai | done | 329.648 | 0.304 | 0.073 | 0.000000 | 0 |
