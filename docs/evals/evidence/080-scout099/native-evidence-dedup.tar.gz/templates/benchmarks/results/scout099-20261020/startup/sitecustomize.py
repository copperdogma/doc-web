import sys;sys.path.insert(0,'/Users/cam/.codex/worktrees/scout099-docweb-20261020'); from benchmarks.scripts.scout099_reading import install_ocr; install_ocr()
