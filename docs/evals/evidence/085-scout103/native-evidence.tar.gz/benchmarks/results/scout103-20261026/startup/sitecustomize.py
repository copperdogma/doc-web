import sys;sys.path.insert(0,'/Users/cam/.codex/worktrees/scout103-terra-20261026/doc-web'); from benchmarks.scripts.scout103_reading import install_ocr; install_ocr()
