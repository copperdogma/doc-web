# Instrumentation Report — scout103-ocr-barney-control-20261026

- Invocation started: 2026-10-26T18:29:33.926996Z
- Invocation ended: None
- Wall time: 56.115748 seconds
- Recorded run cost: 0.000000 USD
- Usage scope: cumulative recorded run history; wall/CPU time: current invocation.
- Cost basis: explicit event costs, otherwise estimates under the displayed price sheet.

## Per-model cost
_no LLM calls recorded_

## Latest recorded stage timings and cumulative usage
Unknown timing is not reconstructed from usage events; status reflects current pipeline state.
| stage | status | wall_s | user_s | sys_s | cost | calls |
|---|---|---:|---:|---:|---:|---:|
| images_to_manifest | done | 0.416 | 0.294 | 0.057 | 0.000000 | 0 |
| ocr_ai | failed | 55.699 | 0.308 | 0.061 | 0.000000 | 0 |
