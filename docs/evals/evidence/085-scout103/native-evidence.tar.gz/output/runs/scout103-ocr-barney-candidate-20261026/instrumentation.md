# Instrumentation Report — scout103-ocr-barney-candidate-20261026

- Invocation started: 2026-10-26T18:28:43.126616Z
- Invocation ended: 2026-10-26T18:29:33.384034Z
- Wall time: 50.25713 seconds
- Recorded run cost: 0.000000 USD
- Usage scope: cumulative recorded run history; wall/CPU time: current invocation.
- Cost basis: explicit event costs, otherwise estimates under the displayed price sheet.

## Per-model cost
_no LLM calls recorded_

## Latest recorded stage timings and cumulative usage
Unknown timing is not reconstructed from usage events; status reflects current pipeline state.
| stage | status | wall_s | user_s | sys_s | cost | calls |
|---|---|---:|---:|---:|---:|---:|
| images_to_manifest | done | 0.418 | 0.235 | 0.050 | 0.000000 | 0 |
| ocr_ai | done | 49.838 | 0.279 | 0.056 | 0.000000 | 0 |
